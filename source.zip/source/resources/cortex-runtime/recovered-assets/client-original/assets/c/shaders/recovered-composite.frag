#version 330 core

uniform sampler2D uTexture;
uniform vec2 uTexelSize;
uniform float uOffset;
uniform vec2 uDirection;
uniform int uCompositeMode;
uniform vec3 uCompositeColor;

in vec2 vUv;

out vec4 FragColor;

void main() {
    if (uCompositeMode == 1) {
        float alpha = texture(uTexture, vUv).r;
        FragColor = vec4(uCompositeColor, alpha);
        return;
    }

    if (uCompositeMode == 2) {
        if (uOffset <= 1.001) {
            FragColor = texture(uTexture, vUv);
            return;
        }

        vec2 offset = uTexelSize * max(0.5, uOffset * 0.25);
        vec4 color = texture(uTexture, vUv + offset);
        color += texture(uTexture, vUv - offset);
        color += texture(uTexture, vUv + vec2(offset.x, -offset.y));
        color += texture(uTexture, vUv + vec2(-offset.x, offset.y));
        FragColor = color * 0.25;
        return;
    }

    vec2 direction = uTexelSize * uDirection * max(uOffset, 0.0);
    if (dot(direction, direction) <= 0.000000000001) {
        if (uOffset <= 0.0) {
            FragColor = texture(uTexture, vUv);
            return;
        }

        vec2 legacyOffset = uTexelSize * uOffset;
        vec4 legacyColor = texture(uTexture, vUv) * 4.0;
        legacyColor += texture(uTexture, vUv + vec2(legacyOffset.x, legacyOffset.y));
        legacyColor += texture(uTexture, vUv + vec2(-legacyOffset.x, legacyOffset.y));
        legacyColor += texture(uTexture, vUv + vec2(legacyOffset.x, -legacyOffset.y));
        legacyColor += texture(uTexture, vUv - legacyOffset);
        legacyColor += texture(uTexture, vUv + vec2(legacyOffset.x * 2.0, 0.0));
        legacyColor += texture(uTexture, vUv - vec2(legacyOffset.x * 2.0, 0.0));
        legacyColor += texture(uTexture, vUv + vec2(0.0, legacyOffset.y * 2.0));
        legacyColor += texture(uTexture, vUv - vec2(0.0, legacyOffset.y * 2.0));
        FragColor = legacyColor / 12.0;
        return;
    }

    vec4 color = texture(uTexture, vUv) * 0.2270270270;
    color += texture(uTexture, vUv + direction * 1.3846153846) * 0.3162162162;
    color += texture(uTexture, vUv - direction * 1.3846153846) * 0.3162162162;
    color += texture(uTexture, vUv + direction * 3.2307692308) * 0.0702702703;
    color += texture(uTexture, vUv - direction * 3.2307692308) * 0.0702702703;
    FragColor = color;
}
