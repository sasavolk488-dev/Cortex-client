#version 330
out vec2 texCoord;void main(){vec2 bp=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(bp*2.0-1.0,0.0,1.0);texCoord=bp;}