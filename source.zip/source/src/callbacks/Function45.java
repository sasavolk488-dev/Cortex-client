package callbacks;

import java.util.function.Function;
import net.minecraft.util.Identifier;
import util.ClientUtils196;

public class Function45 implements Function {
   @Override
   public Object apply(Object object) {
      return ClientUtils196.resolveRenderLayer2((Identifier)object);
   }

   public static Function45 getFunction45() {
      return new Function45();
   }
}
