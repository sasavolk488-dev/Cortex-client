package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier7 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier7(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState10();
   }

   public static AimAssistBooleanSupplier7 resolveAimAssistBooleanSupplier7(AimAssist var0) {
      return new AimAssistBooleanSupplier7(var0);
   }
}
