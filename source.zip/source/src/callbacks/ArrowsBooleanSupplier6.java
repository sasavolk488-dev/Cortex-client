package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier6 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier6(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState15();
   }

   public static ArrowsBooleanSupplier6 resolveArrowsBooleanSupplier6(Arrows var0) {
      return new ArrowsBooleanSupplier6(var0);
   }
}
