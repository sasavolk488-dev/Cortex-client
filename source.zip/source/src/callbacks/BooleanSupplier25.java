package callbacks;

import java.util.function.BooleanSupplier;
import model.ClientState478;

public class BooleanSupplier25 implements BooleanSupplier {
   public ClientState478 clientState478;

   public BooleanSupplier25(ClientState478 clientState478) {
      this.clientState478 = clientState478;
   }

   @Override
   public boolean getAsBoolean() {
      return this.clientState478.testState();
   }

   public static BooleanSupplier25 resolveBooleanSupplier25(ClientState478 var0) {
      return new BooleanSupplier25(var0);
   }
}
