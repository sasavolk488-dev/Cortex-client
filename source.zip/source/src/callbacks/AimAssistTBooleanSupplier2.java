package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssistT;

public class AimAssistTBooleanSupplier2 implements BooleanSupplier {
   public AimAssistT aimAssistT;

   public AimAssistTBooleanSupplier2(AimAssistT aimAssistT) {
      this.aimAssistT = aimAssistT;
   }

   static {
      Class<AimAssistTBooleanSupplier2> var10000 = AimAssistTBooleanSupplier2.class;
      int var0 = -16750360;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssistT.testState();
   }

   public static AimAssistTBooleanSupplier2 resolveAimAssistTBooleanSupplier2(AimAssistT var0) {
      return new AimAssistTBooleanSupplier2(var0);
   }
}
