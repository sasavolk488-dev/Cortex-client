package callbacks;

import java.util.function.Supplier;
import model.ClientState550;

public class Supplier41 implements Supplier {
   @Override
   public Object get() {
      return new ClientState550();
   }

   public static Supplier41 getSupplier41() {
      return new Supplier41();
   }
}
