package callbacks;

import java.util.function.Function;
import model.ClientState150;

public class Function51 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState150)object).getIntValue();
   }

   public static Function51 getFunction51() {
      return new Function51();
   }
}
