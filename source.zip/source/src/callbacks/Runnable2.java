package callbacks;

import client.Cortex;

public class Runnable2 implements Runnable {
   public Cortex cortex;

   public Runnable2(Cortex cortex) {
      this.cortex = cortex;
   }

   @Override
   public void run() {
      this.cortex.updateState2();
   }

   public static Runnable2 resolveRunnable2(Cortex var0) {
      return new Runnable2(var0);
   }
}
