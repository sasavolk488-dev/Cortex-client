package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.NoPush;

public class Consumer21 implements Consumer {
   @Override
   public void accept(Object object) {
      NoPush.handleEnumMap((EnumMap)object);
   }

   public static Consumer21 getConsumer21() {
      return new Consumer21();
   }
}
