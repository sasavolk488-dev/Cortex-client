package callbacks;

import java.util.function.Function;
import model.ClientState408;

public class Function14 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState408)object).getText2();
   }

   public static Function14 getFunction14() {
      return new Function14();
   }
}
