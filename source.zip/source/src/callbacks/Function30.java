package callbacks;

import java.util.concurrent.Executor;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import model.ClientState95;
import util.ClientUtils173;

public class Function30 implements Function {
   public ClientState95 clientState95;
   public Consumer consumer;
   public Executor executor;
   public Supplier supplier;

   public Function30(ClientState95 clientState95, Consumer consumer, Executor executor, Supplier supplier) {
      this.clientState95 = clientState95;
      this.consumer = consumer;
      this.executor = executor;
      this.supplier = supplier;
   }

   @Override
   public Object apply(Object object) {
      return ClientUtils173.resolveCompletionStage(this.clientState95, this.consumer, this.executor, this.supplier, (Void)object);
   }

   public static Function30 resolveFunction30(ClientState95 var0, Consumer var1, Executor var2, Supplier var3) {
      return new Function30(var0, var1, var2, var3);
   }
}
