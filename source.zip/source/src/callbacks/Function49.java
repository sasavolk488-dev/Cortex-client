package callbacks;

import java.util.function.Function;
import model.ClientState505;

public class Function49 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState505)object).getByteArrayArray();
   }

   public static Function49 getFunction49() {
      return new Function49();
   }
}
