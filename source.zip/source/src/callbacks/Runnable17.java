package callbacks;

import model.ClientState137;
import model.ClientState222;

public class Runnable17 implements Runnable {
   public ClientState137 clientState137;
   public ClientState222 clientState222;

   public Runnable17(ClientState137 clientState137, ClientState222 clientState222) {
      this.clientState137 = clientState137;
      this.clientState222 = clientState222;
   }

   @Override
   public void run() {
      this.clientState137.handleClientState222(this.clientState222);
   }

   public static Runnable17 resolveRunnable17(ClientState137 var0, ClientState222 var1) {
      return new Runnable17(var0, var1);
   }
}
