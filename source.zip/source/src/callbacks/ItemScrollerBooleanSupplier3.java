package callbacks;

import java.util.function.BooleanSupplier;
import modules.ItemScroller;

public class ItemScrollerBooleanSupplier3 implements BooleanSupplier {
   public ItemScroller itemScroller;

   public ItemScrollerBooleanSupplier3(ItemScroller itemScroller) {
      this.itemScroller = itemScroller;
   }

   @Override
   public boolean getAsBoolean() {
      return this.itemScroller.testState4();
   }

   public static ItemScrollerBooleanSupplier3 resolveItemScrollerBooleanSupplier3(ItemScroller var0) {
      return new ItemScrollerBooleanSupplier3(var0);
   }
}
