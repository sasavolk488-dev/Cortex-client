package callbacks;

import java.util.function.Function;
import model.ClientState179;

public class Function13 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState179)object).getByteArray();
   }

   public static Function13 getFunction13() {
      return new Function13();
   }
}
