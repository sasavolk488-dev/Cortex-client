package callbacks;

import java.util.function.IntFunction;
import util.ClientUtils174;

public class IntFunction1 implements IntFunction {
   @Override
   public Object apply(int index) {
      return ClientUtils174.resolveTextArray(index);
   }

   public static IntFunction1 getIntFunction1() {
      return new IntFunction1();
   }
}
