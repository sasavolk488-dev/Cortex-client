package callbacks;

import java.util.function.BooleanSupplier;
import modules.MaceHelper;

public class MaceHelperBooleanSupplier1 implements BooleanSupplier {
   public MaceHelper maceHelper;

   public MaceHelperBooleanSupplier1(MaceHelper maceHelper) {
      this.maceHelper = maceHelper;
   }

   @Override
   public boolean getAsBoolean() {
      return this.maceHelper.testState4();
   }

   public static MaceHelperBooleanSupplier1 resolveMaceHelperBooleanSupplier1(MaceHelper var0) {
      return new MaceHelperBooleanSupplier1(var0);
   }
}
