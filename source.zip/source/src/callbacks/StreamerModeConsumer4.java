package callbacks;

import java.util.function.Consumer;
import modules.StreamerMode;
import settings.StringSetting;

public class StreamerModeConsumer4 implements Consumer {
   public StreamerMode streamerMode;

   public StreamerModeConsumer4(StreamerMode streamerMode) {
      this.streamerMode = streamerMode;
   }

   @Override
   public void accept(Object object) {
      this.streamerMode.handleStringSetting3((StringSetting)object);
   }

   public static StreamerModeConsumer4 resolveStreamerModeConsumer4(StreamerMode var0) {
      return new StreamerModeConsumer4(var0);
   }
}
