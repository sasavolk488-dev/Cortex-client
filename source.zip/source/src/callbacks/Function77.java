package callbacks;

import java.util.function.Function;
import model.ClientState284;

public class Function77 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState284)object).getByteArray();
   }

   public static Function77 getFunction77() {
      return new Function77();
   }
}
