package callbacks;

import api.ClientContract18;
import java.util.Comparator;

public class Comparator2 implements Comparator {
   @Override
   public int compare(Object object, Object object2) {
      return ClientContract18.calculateInt((ClientContract18)object, (ClientContract18)object2);
   }

   public static Comparator2 getComparator2() {
      return new Comparator2();
   }
}
