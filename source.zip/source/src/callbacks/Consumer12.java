package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.Arrows;

public class Consumer12 implements Consumer {
   @Override
   public void accept(Object object) {
      Arrows.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer12 getConsumer12() {
      return new Consumer12();
   }
}
