package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier10 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier10(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState20();
   }

   public static AimAssistBooleanSupplier10 resolveAimAssistBooleanSupplier10(AimAssist var0) {
      return new AimAssistBooleanSupplier10(var0);
   }
}
