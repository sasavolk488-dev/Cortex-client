package callbacks;

import java.util.function.Function;
import model.ClientState393;

public class Function68 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState393)object).getLongValue();
   }

   public static Function68 getFunction68() {
      return new Function68();
   }
}
