package callbacks;

import java.util.function.Function;
import model.NumericState188;

public class Function38 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState188)object).getLongValue();
   }

   public static Function38 getFunction38() {
      return new Function38();
   }
}
