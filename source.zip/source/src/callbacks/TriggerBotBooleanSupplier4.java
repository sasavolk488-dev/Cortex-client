package callbacks;

import java.util.function.BooleanSupplier;
import modules.TriggerBot;

public class TriggerBotBooleanSupplier4 implements BooleanSupplier {
   public TriggerBot triggerBot;

   public TriggerBotBooleanSupplier4(TriggerBot triggerBot) {
      this.triggerBot = triggerBot;
   }

   @Override
   public boolean getAsBoolean() {
      return this.triggerBot.testState();
   }

   public static TriggerBotBooleanSupplier4 resolveTriggerBotBooleanSupplier4(TriggerBot var0) {
      return new TriggerBotBooleanSupplier4(var0);
   }
}
