package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.DragonFly;

public class Consumer24 implements Consumer {
   static {
      Class<Consumer24> var10000 = Consumer24.class;
      int var0 = -1593969311;
   }

   @Override
   public void accept(Object object) {
      DragonFly.handleEnumMap((EnumMap)object);
   }

   public static Consumer24 getConsumer24() {
      return new Consumer24();
   }
}
