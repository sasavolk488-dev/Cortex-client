package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier7 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier7(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier7 resolveSupplier7(OptionGroup132 var0) {
      return new Supplier7(var0);
   }
}
