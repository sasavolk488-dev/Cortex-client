package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.DebugModule;

public class Consumer31 implements Consumer {
   static {
      Class<Consumer31> var10000 = Consumer31.class;
      int var0 = 739387629;
   }

   @Override
   public void accept(Object object) {
      DebugModule.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer31 getConsumer31() {
      return new Consumer31();
   }
}
