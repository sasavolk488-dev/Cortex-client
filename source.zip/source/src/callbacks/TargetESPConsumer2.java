package callbacks;

import java.util.function.Consumer;
import modules.TargetESP;
import settings.Setting;

public class TargetESPConsumer2 implements Consumer {
   public TargetESP targetESP;

   public TargetESPConsumer2(TargetESP targetESP) {
      this.targetESP = targetESP;
   }

   @Override
   public void accept(Object object) {
      this.targetESP.handleSetting((Setting)object);
   }

   public static TargetESPConsumer2 resolveTargetESPConsumer2(TargetESP var0) {
      return new TargetESPConsumer2(var0);
   }
}
