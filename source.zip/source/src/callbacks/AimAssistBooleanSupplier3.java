package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier3 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier3(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState16();
   }

   public static AimAssistBooleanSupplier3 resolveAimAssistBooleanSupplier3(AimAssist var0) {
      return new AimAssistBooleanSupplier3(var0);
   }
}
