package callbacks;

import java.util.Comparator;
import model.BlockState1;
import modules.BlockESP;

public class BlockESPCallback1 implements Comparator {
   public BlockESP blockESP;

   public BlockESPCallback1(BlockESP blockESP) {
      this.blockESP = blockESP;
   }

   @Override
   public int compare(Object object, Object object2) {
      return this.blockESP.calculateInt((BlockState1)object, (BlockState1)object2);
   }

   public static BlockESPCallback1 resolveBlockESPCallback1(BlockESP var0) {
      return new BlockESPCallback1(var0);
   }
}
