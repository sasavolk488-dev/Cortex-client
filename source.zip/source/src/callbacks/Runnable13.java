package callbacks;

import api.ClientContract27;
import api.ClientContract28;
import api.ClientContract67;
import api.ClientContract99;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import model.ClientState205;
import model.ClientState253;
import model.ClientState55;
import model.ClientState557;
import model.ClientState560;
import settings.options.OptionGroup149;
import util.ClientUtils312;

public abstract class Runnable13 extends ClientState205 implements Runnable, ClientContract99 {
   public static final long LONG_CONSTANT = 1000L;
   public static final long LONG_CONSTANT2 = 1000L;
   public URI uRI = null;
   public volatile ClientState560 clientState560 = null;
   public volatile ClientState560 clientState5602;
   public volatile Socket socket = null;
   public volatile OutputStream outputStream;
   public volatile Thread thread;
   public volatile Thread thread2;
   public ClientState55 clientState55;
   public Map map;
   public CountDownLatch countDownLatch = new CountDownLatch(1);
   public CountDownLatch countDownLatch2 = new CountDownLatch(1);
   public int intValue = 0;

   public Runnable13(URI uRI, ClientState55 clientState55, Map entries, int intValue) {
      if (uRI == null) {
         throw new IllegalArgumentException();
      }

      if (clientState55 == null) {
         throw new IllegalArgumentException("E610");
      }

      this.uRI = uRI;
      this.clientState55 = clientState55;
      if (entries != null) {
         this.map = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
         this.map.putAll(entries);
      }

      this.intValue = intValue;
      this.setBooleanValue2(false);
      this.setBooleanValue3(false);
      this.clientState560 = new ClientState560(this, clientState55);
   }

   public Runnable13(URI var1, ClientState55 var2, Map entries) {
      this(var1, var2, entries, 0);
   }

   public Runnable13(URI var1, Map entries) {
      this(var1, new ClientState557(), entries);
   }

   public Runnable13(URI var1, ClientState55 var2) {
      this(var1, var2, null, 0);
   }

   public Runnable13(URI var1) {
      this(var1, new ClientState557());
   }

   @Override
   public void run() {
      ClientState560 var1 = this.clientState560;
      Socket var4 = null;

      InputStream var2;
      OutputStream outputStream;
      try {
         var4 = this.getSocket2();
         var4.setTcpNoDelay(this.isBooleanValue2());
         var4.setReuseAddress(this.isBooleanValue3());
         int index = this.getIntValue();
         if (index > 0) {
            var4.setReceiveBufferSize(index);
         }

         if (!var4.isConnected()) {
            this.connectSocket(var4, this.uRI.getHost(), this.getInt2(), this.intValue);
         }

         var2 = var4.getInputStream();
         outputStream = var4.getOutputStream();
         this.outputStream = outputStream;
         this.handleClientState560(var1);
      } catch (Exception var13) {
         this.handleSocket(var4);
         this.handleClientContract99(var1, var13);
         var1.handleInt2(-1, "E613");
         return;
      }

      Thread var14 = this.thread;
      if (var14 != null) {
         try {
            if (!interruptAndJoin(var14, 1000L)) {
               this.handleSocket(var4);
               var1.handleInt2(1006, "E682");
               return;
            }
         } catch (InterruptedException var10) {
            this.handleSocket(var4);
            var1.handleInt2(1006, "E680");
            Thread.currentThread().interrupt();
            return;
         }
      }

      if (var1 != this.clientState560) {
         this.handleSocket(var4);
      } else {
         this.thread = new Thread(new Runnable23(this, var1, outputStream, var4));
         this.thread.setDaemon(this.isBooleanValue5());
         this.thread.setName("n-w-" + this.thread.getId());
         this.thread.start();
         int index2 = this.getIntValue();
         byte[] var7 = new byte[index2 > 0 ? index2 : 65536];

         try {
            int index3;
            while (!var1.testState() && !var1.testState4() && (index3 = var2.read(var7)) != -1) {
               var1.handleByteBuffer5(ByteBuffer.wrap(var7, 0, index3));
            }

            var1.updateState3();
         } catch (IOException var11) {
            this.handleClientState560(var1, var11);
         } catch (RuntimeException var12) {
            this.onError(var12);
            var1.handleInt2(1006, "E614");
         }
      }
   }

   public void connect() {
      if (this.thread2 != null) {
         throw new IllegalStateException("E612");
      }

      this.thread2 = new Thread(this);
      this.thread2.setDaemon(this.isBooleanValue5());
      this.thread2.setName("n-c-" + this.thread2.getId());
      this.thread2.start();
   }

   public abstract void onClose(int index, String text, boolean flag);

   public URI getURI() {
      return this.uRI;
   }

   public ClientContract99 getConnection() {
      return this.clientState560;
   }

   public abstract void onError(Exception var1);

   @Override
   public final void handleClientContract99(ClientContract99 var1, int index, String text, boolean flag) {
      boolean flag2 = this.testClientContract99(var1);
      if (var1 == this.clientState560 || flag2) {
         this.updateState4();
         if (this.thread != null) {
            this.thread.interrupt();
         }

         this.clientState560.updateState4();
         this.handleSocket(this.socket);
         if (!flag2) {
            this.onClose(index, text, flag);
         }

         this.countDownLatch.countDown();
         this.countDownLatch2.countDown();
      }
   }

   @Override
   public void handleClientContract99(ClientContract99 var1, int index, String text) {
      this.onCloseInitiated(index, text);
   }

   @Override
   public void handleClientContract992(ClientContract99 var1, int index, String text, boolean flag) {
      this.onClosing(index, text, flag);
   }

   @Override
   public void handleInt(int index, String text) {
      this.clientState560.handleInt(index, text);
   }

   @Override
   public void updateState5() {
      if (this.thread != null) {
         this.clientState560.handleInt3(1000);
      }
   }

   @Override
   public void handleInt3(int index) {
      this.clientState560.handleInt3(index);
   }

   @Override
   public void updateState6() {
      this.clientState560.updateState6();
   }

   public Socket getSocket() {
      return this.socket;
   }

   public Socket getSocket2() throws IOException {
      if (!"ws".equals(this.uRI.getScheme())) {
         throw new IOException("E615");
      }

      if (this.socket == null) {
         this.socket = new Socket();
      } else if (this.socket.isClosed()) {
         throw new IOException();
      }

      return this.socket;
   }

   @Override
   public final void handleClientContract99(ClientContract99 var1) {
   }

   @Override
   public final void handleClientContract99(ClientContract99 var1, Exception var2) {
      if (!this.testClientContract99(var1) && var1 == this.clientState560) {
         this.onError(var2);
      }
   }

   @Override
   public InetSocketAddress resolveInetSocketAddress(ClientContract99 var1) {
      return this.socket != null ? (InetSocketAddress)this.socket.getLocalSocketAddress() : null;
   }

   @Override
   public final void handleClientContract99(ClientContract99 var1, ClientContract67 var2) {
      if (!this.testClientContract99(var1) && var1 == this.clientState560) {
         this.updateState();
         this.onOpen((ClientContract27)var2);
         this.countDownLatch.countDown();
      } else {
         this.countDownLatch.countDown();
      }
   }

   @Override
   public final void handleClientContract99(ClientContract99 var1, ByteBuffer var2) {
      if (!this.testClientContract99(var1) && var1 == this.clientState560) {
         this.onMessage(var2);
      }
   }

   @Override
   public final void handleClientContract99(ClientContract99 var1, long value, long value2) {
      if (!this.testClientContract99(var1) && var1 == this.clientState560) {
         this.onWsProgress(value, value2);
      }
   }

   @Override
   public InetSocketAddress resolveInetSocketAddress2(ClientContract99 var1) {
      return this.socket != null ? (InetSocketAddress)this.socket.getRemoteSocketAddress() : null;
   }

   @Override
   public boolean testState() {
      return this.clientState560.testState();
   }

   @Override
   public boolean testState2() {
      return this.clientState560.testState2();
   }

   @Override
   public void handleCollection(Collection values) {
      this.clientState560.handleCollection(values);
   }

   @Override
   public void handleClientContract28(ClientContract28 var1) {
      this.clientState560.handleClientContract28(var1);
   }

   @Override
   public InetSocketAddress getInetSocketAddress() {
      return this.clientState560.getInetSocketAddress();
   }

   @Override
   public boolean testState3() {
      return this.clientState560.testState3();
   }

   @Override
   public ClientState55 getClientState55() {
      return this.clientState55;
   }

   @Override
   public void handleInt2(int index, String text) {
      this.clientState560.handleInt2(index, text);
   }

   @Override
   public InetSocketAddress getInetSocketAddress2() {
      return this.clientState560.getInetSocketAddress2();
   }

   @Override
   public OptionGroup149 getOptionGroup149() {
      return this.clientState560.getOptionGroup149();
   }

   @Override
   public boolean testState4() {
      return this.clientState560.testState4();
   }

   @Override
   public String getText() {
      return this.uRI.getPath();
   }

   @Override
   public void handleValue(Object object) {
      this.clientState560.handleValue(object);
   }

   @Override
   public void handleByteBuffer(ByteBuffer var1) {
      this.clientState560.handleByteBuffer(var1);
   }

   @Override
   public void handleByteArray(byte[] var1) {
      this.clientState560.handleByteArray(var1);
   }

   @Override
   public boolean testState5() {
      return this.clientState560.testState5();
   }

   @Override
   public Object getValue() {
      return this.clientState560.getValue();
   }

   @Override
   public Collection getCollection() {
      return Collections.singletonList(this.clientState560);
   }

   public void handleSocket(Socket var1) {
      if (var1 != null) {
         try {
            var1.close();
         } catch (IOException var3) {
            this.handleClientContract99(this.clientState560, var3);
         }
      }
   }

   public int getInt2() {
      int index = this.uRI.getPort();
      String text = this.uRI.getScheme();
      if ("ws".equals(text)) {
         return index == -1 ? 80 : index;
      } else {
         throw new IllegalArgumentException("E615");
      }
   }

   public boolean testClientContract99(ClientContract99 var1) {
      return var1 != null && var1 == this.clientState5602;
   }

   public void addHeader(String text, String text2) {
      if (this.map == null) {
         this.map = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
      }

      this.map.put(text, text2);
   }

   public void handleClientState560(ClientState560 var1) throws ClientUtils312 {
      String text = this.uRI.getRawPath();
      String text2 = this.uRI.getRawQuery();
      String text3;
      if (text != null && text.length() != 0) {
         text3 = text;
      } else {
         text3 = "/";
      }

      if (text2 != null) {
         text3 = text3 + '?' + text2;
      }

      int index = this.getInt2();
      String text4 = this.uRI.getHost() + (index != 80 ? ":" + index : "");
      ClientState253 var7 = new ClientState253();
      var7.handleText(text3);
      var7.handleText("Host", text4);
      if (this.map != null) {
         for (Entry var9 : (java.lang.Iterable<Entry>) (java.lang.Iterable<?>) (this.map.entrySet())) {
            var7.handleText((String)var9.getKey(), (String)var9.getValue());
         }
      }

      var1.handleClientContract9(var7);
   }

   public void onMessage(ByteBuffer var1) {
   }

   public void onClosing(int index, String text, boolean flag) {
   }

   public void handleClientState560(ClientState560 var1, IOException var2) {
      var1.updateState3();
   }

   public abstract void onOpen(ClientContract27 var1);

   public void reconnect() {
      try {
         this.updateState7();
      } catch (InterruptedException var2) {
         Thread.currentThread().interrupt();
         throw new IllegalStateException("E680", var2);
      }

      this.connect();
   }

   public void updateState7() throws InterruptedException {
      Thread var1 = Thread.currentThread();
      if (var1 != this.thread && var1 != this.thread2) {
         ClientState560 clientState5602 = this.clientState560;
         Socket var3 = this.socket;
         Thread var4 = this.thread;
         Thread var5 = this.thread2;
         InterruptedException var6 = null;
         this.clientState5602 = clientState5602;

         try {
            if (!clientState5602.testState4()) {
               boolean flag = false;
               if (clientState5602.getOptionGroup149() != OptionGroup149.VALUE_1 && var4 != null) {
                  try {
                     clientState5602.handleInt3(1000);
                     flag = this.countDownLatch2.await(1000L, TimeUnit.MILLISECONDS);
                  } catch (InterruptedException var14) {
                     var6 = var14;
                  } catch (RuntimeException var15) {
                     flag = false;
                  }
               }

               if (!flag && !clientState5602.testState4()) {
                  this.handleSocket(var3);
                  clientState5602.handleInt2(1006, "E681");
               }
            }

            this.handleSocket(var3);
            clientState5602.updateState4();
            if (var4 != null) {
               var4.interrupt();
            }

            if (var5 != null) {
               var5.interrupt();
            }

            if (var6 != null) {
               throw var6;
            }

            boolean flag2 = interruptAndJoin(var4, 1000L);
            boolean flag3 = interruptAndJoin(var5, 1000L);
            if (!flag2 || !flag3) {
               IllegalStateException var9 = new IllegalStateException("E682");
               this.onError(var9);
               throw var9;
            }

            this.clientState55.updateState();
            if (this.thread == var4) {
               this.thread = null;
            }

            if (this.thread2 == var5) {
               this.thread2 = null;
            }

            if (this.socket == var3) {
               this.socket = null;
               this.outputStream = null;
            }

            this.countDownLatch = new CountDownLatch(1);
            this.countDownLatch2 = new CountDownLatch(1);
            this.clientState560 = new ClientState560(this, this.clientState55);
         } finally {
            if (this.clientState5602 == clientState5602) {
               this.clientState5602 = null;
            }
         }
      } else {
         throw new IllegalStateException("E611");
      }
   }

   public void connectSocket(Socket var1, String text, int index, int index2) throws IOException {
      InetSocketAddress var5 = new InetSocketAddress(InetAddress.getByName(text), index);
      var1.connect(var5, index2);
   }

   public void closeBlocking() throws InterruptedException {
      this.updateState5();
      this.countDownLatch2.await();
   }

   public void onCloseInitiated(int index, String text) {
   }

   public void onWsProgress(long value, long value2) {
   }

   public void clearHeaders() {
      this.map = null;
   }

   public String removeHeader(String text) {
      return this.map == null ? null : (String)this.map.remove(text);
   }

   public static boolean interruptAndJoin(Thread var0, long value) throws InterruptedException {
      if (var0 == null || !var0.isAlive()) {
         return true;
      } else if (var0 != Thread.currentThread() && value >= 1L) {
         var0.interrupt();
         var0.join(value);
         return !var0.isAlive();
      } else {
         throw new IllegalArgumentException("E683");
      }
   }

   public boolean connectBlocking(long value, TimeUnit var3) throws InterruptedException {
      this.connect();
      boolean flag = this.countDownLatch.await(value, var3);
      if (!flag) {
         this.updateState7();
      }

      return flag && this.clientState560.testState5();
   }

   public boolean connectBlocking() throws InterruptedException {
      this.connect();
      this.countDownLatch.await();
      return this.clientState560.testState5();
   }

   public boolean reconnectBlocking() throws InterruptedException {
      this.updateState7();
      return this.connectBlocking();
   }

   public boolean reconnectBlocking(long value, TimeUnit var3) throws InterruptedException {
      this.updateState7();
      return this.connectBlocking(value, var3);
   }
}
