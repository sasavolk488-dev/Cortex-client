package callbacks;

import java.util.function.Supplier;
import model.ClientState532;

public class Supplier1 implements Supplier {
   @Override
   public Object get() {
      return new ClientState532();
   }

   public static Supplier1 getSupplier1() {
      return new Supplier1();
   }
}
