package callbacks;

import util.ClientUtils171;

public class Runnable4 implements Runnable {
   static {
      Class<Runnable4> var10000 = Runnable4.class;
      int var0 = 311575326;
   }

   @Override
   public void run() {
      ClientUtils171.updateState3();
   }

   public static Runnable4 getRunnable4() {
      return new Runnable4();
   }
}
