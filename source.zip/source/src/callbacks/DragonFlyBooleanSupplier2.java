package callbacks;

import java.util.function.BooleanSupplier;
import modules.DragonFly;

public class DragonFlyBooleanSupplier2 implements BooleanSupplier {
   public DragonFly dragonFly;

   public DragonFlyBooleanSupplier2(DragonFly dragonFly) {
      this.dragonFly = dragonFly;
   }

   static {
      Class<DragonFlyBooleanSupplier2> var10000 = DragonFlyBooleanSupplier2.class;
      int var0 = -846441234;
   }

   @Override
   public boolean getAsBoolean() {
      return this.dragonFly.testState2();
   }

   public static DragonFlyBooleanSupplier2 resolveDragonFlyBooleanSupplier2(DragonFly var0) {
      return new DragonFlyBooleanSupplier2(var0);
   }
}
