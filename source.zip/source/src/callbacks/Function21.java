package callbacks;

import java.util.function.Function;
import model.NumericState111;

public class Function21 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState111)object).getLongValue();
   }

   public static Function21 getFunction21() {
      return new Function21();
   }
}
