package callbacks;

import java.util.function.Consumer;
import modules.AutoSwap;
import net.minecraft.item.ItemStack;

public class AutoSwapConsumer2 implements Consumer {
   public AutoSwap autoSwap;

   public AutoSwapConsumer2(AutoSwap autoSwap) {
      this.autoSwap = autoSwap;
   }

   @Override
   public void accept(Object object) {
      this.autoSwap.handleItemStack4((ItemStack)object);
   }

   public static AutoSwapConsumer2 resolveAutoSwapConsumer2(AutoSwap var0) {
      return new AutoSwapConsumer2(var0);
   }
}
