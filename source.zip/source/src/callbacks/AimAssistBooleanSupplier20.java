package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier20 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier20(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState9();
   }

   public static AimAssistBooleanSupplier20 resolveAimAssistBooleanSupplier20(AimAssist var0) {
      return new AimAssistBooleanSupplier20(var0);
   }
}
