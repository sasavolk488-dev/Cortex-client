package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier20 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier20(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   static {
      Class<BooleanSupplier20> var10000 = BooleanSupplier20.class;
      int var0 = -732343177;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier20 resolveBooleanSupplier20(BooleanSetting setting) {
      return new BooleanSupplier20(setting);
   }
}
