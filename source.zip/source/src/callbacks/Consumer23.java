package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.TriggerBot;

public class Consumer23 implements Consumer {
   @Override
   public void accept(Object object) {
      TriggerBot.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer23 getConsumer23() {
      return new Consumer23();
   }
}
