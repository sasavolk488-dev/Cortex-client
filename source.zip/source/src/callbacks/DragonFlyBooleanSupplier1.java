package callbacks;

import java.util.function.BooleanSupplier;
import modules.DragonFly;

public class DragonFlyBooleanSupplier1 implements BooleanSupplier {
   public DragonFly dragonFly;

   public DragonFlyBooleanSupplier1(DragonFly dragonFly) {
      this.dragonFly = dragonFly;
   }

   static {
      Class<DragonFlyBooleanSupplier1> var10000 = DragonFlyBooleanSupplier1.class;
      int var0 = 121219003;
   }

   @Override
   public boolean getAsBoolean() {
      return this.dragonFly.testState();
   }

   public static DragonFlyBooleanSupplier1 resolveDragonFlyBooleanSupplier1(DragonFly var0) {
      return new DragonFlyBooleanSupplier1(var0);
   }
}
