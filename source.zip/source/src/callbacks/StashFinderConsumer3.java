package callbacks;

import java.util.function.Consumer;
import modules.StashFinder;
import settings.Setting;

public class StashFinderConsumer3 implements Consumer {
   public StashFinder stashFinder;

   public StashFinderConsumer3(StashFinder stashFinder) {
      this.stashFinder = stashFinder;
   }

   static {
      Class<StashFinderConsumer3> var10000 = StashFinderConsumer3.class;
      int var0 = 434030462;
   }

   @Override
   public void accept(Object object) {
      this.stashFinder.handleSetting((Setting)object);
   }

   public static StashFinderConsumer3 resolveStashFinderConsumer3(StashFinder var0) {
      return new StashFinderConsumer3(var0);
   }
}
