package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.DebugModule;

public class Consumer26 implements Consumer {
   static {
      Class<Consumer26> var10000 = Consumer26.class;
      int var0 = -1917064055;
   }

   @Override
   public void accept(Object object) {
      DebugModule.handleEnumMap2((EnumMap)object);
   }

   public static Consumer26 getConsumer26() {
      return new Consumer26();
   }
}
