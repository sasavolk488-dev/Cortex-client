package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier9 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier9(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState20();
   }

   public static ArrowsBooleanSupplier9 resolveArrowsBooleanSupplier9(Arrows var0) {
      return new ArrowsBooleanSupplier9(var0);
   }
}
