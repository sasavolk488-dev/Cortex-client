package callbacks;

import java.util.function.Consumer;
import modules.BlockESP;
import settings.Setting;

public class BlockESPConsumer1 implements Consumer {
   public BlockESP blockESP;

   public BlockESPConsumer1(BlockESP blockESP) {
      this.blockESP = blockESP;
   }

   @Override
   public void accept(Object object) {
      this.blockESP.handleSetting((Setting)object);
   }

   public static BlockESPConsumer1 resolveBlockESPConsumer1(BlockESP var0) {
      return new BlockESPConsumer1(var0);
   }
}
