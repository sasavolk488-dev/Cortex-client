package callbacks;

import java.util.function.BooleanSupplier;
import modules.ItemScroller;

public class ItemScrollerBooleanSupplier1 implements BooleanSupplier {
   public ItemScroller itemScroller;

   public ItemScrollerBooleanSupplier1(ItemScroller itemScroller) {
      this.itemScroller = itemScroller;
   }

   @Override
   public boolean getAsBoolean() {
      return this.itemScroller.testState3();
   }

   public static ItemScrollerBooleanSupplier1 resolveItemScrollerBooleanSupplier1(ItemScroller var0) {
      return new ItemScrollerBooleanSupplier1(var0);
   }
}
