package callbacks;

import client.Cortex;
import java.util.function.BiConsumer;
import model.ClientState404;

public class BiConsumer2 implements BiConsumer {
   public Cortex cortex;
   public Runnable runnable;
   public ClientState404 clientState404;

   public BiConsumer2(Cortex cortex, Runnable runnable, ClientState404 clientState404) {
      this.cortex = cortex;
      this.runnable = runnable;
      this.clientState404 = clientState404;
   }

   @Override
   public void accept(Object object, Object object2) {
      this.cortex.handleRunnable(this.runnable, this.clientState404, (Void)object, (Throwable)object2);
   }

   public static BiConsumer2 resolveBiConsumer2(Cortex var0, Runnable var1, ClientState404 var2) {
      return new BiConsumer2(var0, var1, var2);
   }
}
