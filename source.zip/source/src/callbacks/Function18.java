package callbacks;

import java.util.function.Function;
import model.ClientState505;

public class Function18 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState505)object).getLongValue();
   }

   public static Function18 getFunction18() {
      return new Function18();
   }
}
