package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier31 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier31(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState18();
   }

   public static AimAssistBooleanSupplier31 resolveAimAssistBooleanSupplier31(AimAssist var0) {
      return new AimAssistBooleanSupplier31(var0);
   }
}
