package callbacks;

import java.util.function.Supplier;
import util.ClientUtils173;

public class Supplier35 implements Supplier {
   public Class classValue;

   public Supplier35(Class classValue) {
      this.classValue = classValue;
   }

   @Override
   public Object get() {
      return ClientUtils173.resolveByteArray(this.classValue);
   }

   public static Supplier35 resolveSupplier35(Class type) {
      return new Supplier35(type);
   }
}
