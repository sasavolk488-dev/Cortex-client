package callbacks;

import java.util.function.Consumer;
import modules.Hud;
import settings.Setting;

public class HudConsumer1 implements Consumer {
   public Hud hud;

   public HudConsumer1(Hud hud) {
      this.hud = hud;
   }

   @Override
   public void accept(Object object) {
      this.hud.handleSetting2((Setting)object);
   }

   public static HudConsumer1 resolveHudConsumer1(Hud var0) {
      return new HudConsumer1(var0);
   }
}
