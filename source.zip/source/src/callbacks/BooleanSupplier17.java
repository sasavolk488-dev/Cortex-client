package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier17 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier17(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   static {
      Class<BooleanSupplier17> var10000 = BooleanSupplier17.class;
      int var0 = -1352393567;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier17 resolveBooleanSupplier17(BooleanSetting setting) {
      return new BooleanSupplier17(setting);
   }
}
