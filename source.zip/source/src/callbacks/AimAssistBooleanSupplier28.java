package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier28 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier28(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier28 resolveAimAssistBooleanSupplier28(AimAssist var0) {
      return new AimAssistBooleanSupplier28(var0);
   }
}
