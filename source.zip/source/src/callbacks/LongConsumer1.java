package callbacks;

import java.util.function.LongConsumer;
import model.ClientState328;

public class LongConsumer1 implements LongConsumer {
   public ClientState328 clientState328;

   public LongConsumer1(ClientState328 clientState328) {
      this.clientState328 = clientState328;
   }

   @Override
   public void accept(long value) {
      this.clientState328.handleLong2(value);
   }

   public static LongConsumer1 resolveLongConsumer1(ClientState328 var0) {
      return new LongConsumer1(var0);
   }
}
