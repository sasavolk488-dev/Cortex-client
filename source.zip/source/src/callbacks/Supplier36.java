package callbacks;

import java.util.function.Supplier;
import model.ClientState367;

public class Supplier36 implements Supplier {
   public ClientState367 clientState367;

   public Supplier36(ClientState367 clientState367) {
      this.clientState367 = clientState367;
   }

   @Override
   public Object get() {
      return this.clientState367.getText2();
   }

   public static Supplier36 resolveSupplier36(ClientState367 var0) {
      return new Supplier36(var0);
   }
}
