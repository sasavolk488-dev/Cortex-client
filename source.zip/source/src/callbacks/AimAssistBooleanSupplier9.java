package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier9 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier9(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier9 resolveAimAssistBooleanSupplier9(AimAssist var0) {
      return new AimAssistBooleanSupplier9(var0);
   }
}
