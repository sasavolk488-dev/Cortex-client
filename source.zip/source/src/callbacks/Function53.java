package callbacks;

import java.util.function.Function;
import java.util.function.Supplier;
import util.ClientUtils173;

public class Function53 implements Function {
   public Supplier supplier;

   public Function53(Supplier supplier) {
      this.supplier = supplier;
   }

   static {
      Class<Function53> var10000 = Function53.class;
      int var0 = 703528849;
   }

   @Override
   public Object apply(Object object) {
      return ClientUtils173.resolveCompletionStage(this.supplier, (byte[][])object);
   }

   public static Function53 resolveFunction53(Supplier var0) {
      return new Function53(var0);
   }
}
