package callbacks;

import java.util.function.ToIntFunction;
import settings.options.OptionGroup93;

public class ToIntFunction1 implements ToIntFunction {
   @Override
   public int applyAsInt(Object object) {
      return OptionGroup93.calculateInt((OptionGroup93)object);
   }

   public static ToIntFunction1 getToIntFunction1() {
      return new ToIntFunction1();
   }
}
