package callbacks;

import java.util.function.Function;
import model.ClientState284;

public class Function28 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState284)object).isBooleanValue();
   }

   public static Function28 getFunction28() {
      return new Function28();
   }
}
