package callbacks;

import java.util.function.IntFunction;
import util.ClientUtils174;

public class IntFunction3 implements IntFunction {
   @Override
   public Object apply(int index) {
      return ClientUtils174.resolveTextArray2(index);
   }

   public static IntFunction3 getIntFunction3() {
      return new IntFunction3();
   }
}
