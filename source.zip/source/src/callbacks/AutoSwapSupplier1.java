package callbacks;

import java.util.function.Supplier;
import modules.AutoSwap;

public class AutoSwapSupplier1 implements Supplier {
   public AutoSwap autoSwap;

   public AutoSwapSupplier1(AutoSwap autoSwap) {
      this.autoSwap = autoSwap;
   }

   @Override
   public Object get() {
      return this.autoSwap.getItemStack();
   }

   public static AutoSwapSupplier1 resolveAutoSwapSupplier1(AutoSwap var0) {
      return new AutoSwapSupplier1(var0);
   }
}
