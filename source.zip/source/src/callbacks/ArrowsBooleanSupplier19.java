package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier19 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier19(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState21();
   }

   public static ArrowsBooleanSupplier19 resolveArrowsBooleanSupplier19(Arrows var0) {
      return new ArrowsBooleanSupplier19(var0);
   }
}
