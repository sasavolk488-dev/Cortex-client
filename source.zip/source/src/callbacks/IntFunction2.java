package callbacks;

import java.util.function.IntFunction;
import model.NumericState166;

public class IntFunction2 implements IntFunction {
   @Override
   public Object apply(int index) {
      return new NumericState166(index);
   }

   public static IntFunction2 getIntFunction2() {
      return new IntFunction2();
   }
}
