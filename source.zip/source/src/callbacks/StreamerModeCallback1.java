package callbacks;

import modules.StreamerMode;

public class StreamerModeCallback1 implements Runnable {
   public StreamerMode streamerMode;

   public StreamerModeCallback1(StreamerMode streamerMode) {
      this.streamerMode = streamerMode;
   }

   @Override
   public void run() {
      this.streamerMode.updateState2();
   }

   public static StreamerModeCallback1 resolveStreamerModeCallback1(StreamerMode var0) {
      return new StreamerModeCallback1(var0);
   }
}
