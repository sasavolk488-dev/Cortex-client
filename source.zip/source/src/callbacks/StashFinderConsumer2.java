package callbacks;

import java.util.function.Consumer;
import modules.StashFinder;
import settings.Setting;

public class StashFinderConsumer2 implements Consumer {
   public StashFinder stashFinder;

   public StashFinderConsumer2(StashFinder stashFinder) {
      this.stashFinder = stashFinder;
   }

   static {
      Class<StashFinderConsumer2> var10000 = StashFinderConsumer2.class;
      int var0 = -1553237992;
   }

   @Override
   public void accept(Object object) {
      this.stashFinder.handleSetting3((Setting)object);
   }

   public static StashFinderConsumer2 resolveStashFinderConsumer2(StashFinder var0) {
      return new StashFinderConsumer2(var0);
   }
}
