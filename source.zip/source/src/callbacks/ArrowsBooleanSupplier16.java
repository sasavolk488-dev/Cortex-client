package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier16 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier16(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState22();
   }

   public static ArrowsBooleanSupplier16 resolveArrowsBooleanSupplier16(Arrows var0) {
      return new ArrowsBooleanSupplier16(var0);
   }
}
