package callbacks;

import java.util.function.Function;
import model.ClientState119;

public class Function41 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState119)object).getByteArray2();
   }

   public static Function41 getFunction41() {
      return new Function41();
   }
}
