package callbacks;

import java.util.function.Function;
import util.ClientUtils173;

public class Function17 implements Function {
   static {
      Class<Function17> var10000 = Function17.class;
      int var0 = -1722492066;
   }

   @Override
   public Object apply(Object object) {
      return ClientUtils173.resolveByteArrayArray((Throwable)object);
   }

   public static Function17 getFunction17() {
      return new Function17();
   }
}
