package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier16 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier16(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier16 resolveBooleanSupplier16(BooleanSetting setting) {
      return new BooleanSupplier16(setting);
   }
}
