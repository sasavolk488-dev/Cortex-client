package callbacks;

import java.util.function.Consumer;
import modules.TargetESP;
import settings.Setting;

public class TargetESPConsumer1 implements Consumer {
   public TargetESP targetESP;

   public TargetESPConsumer1(TargetESP targetESP) {
      this.targetESP = targetESP;
   }

   @Override
   public void accept(Object object) {
      this.targetESP.handleSetting2((Setting)object);
   }

   public static TargetESPConsumer1 resolveTargetESPConsumer1(TargetESP var0) {
      return new TargetESPConsumer1(var0);
   }
}
