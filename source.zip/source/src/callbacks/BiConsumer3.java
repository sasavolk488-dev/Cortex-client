package callbacks;

import api.ClientContract43;
import java.util.function.BiConsumer;

public class BiConsumer3 implements BiConsumer {
   public ClientContract43 clientContract43;

   public BiConsumer3(ClientContract43 clientContract43) {
      this.clientContract43 = clientContract43;
   }

   @Override
   public void accept(Object object, Object object2) {
      this.clientContract43.handleText((String)object, (String)object2);
   }

   public static BiConsumer3 resolveBiConsumer3(ClientContract43 var0) {
      return new BiConsumer3(var0);
   }
}
