package callbacks;

import java.util.function.Function;
import model.ClientState408;

public class Function44 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState408)object).getText();
   }

   public static Function44 getFunction44() {
      return new Function44();
   }
}
