package callbacks;

import util.ClientUtils70;

public class Runnable15 implements Runnable {
   @Override
   public void run() {
      ClientUtils70.updateState4();
   }

   public static Runnable15 getRunnable15() {
      return new Runnable15();
   }
}
