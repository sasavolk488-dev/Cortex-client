package callbacks;

import java.util.function.Function;
import model.ClientState393;

public class Function36 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState393)object).getUUID();
   }

   public static Function36 getFunction36() {
      return new Function36();
   }
}
