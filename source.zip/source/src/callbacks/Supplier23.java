package callbacks;

import java.util.function.Supplier;
import model.ClientState95;
import util.ClientUtils173;

public class Supplier23 implements Supplier {
   public byte[][] byteArrayArray;
   public int intValue;
   public byte[][] byteArrayArray2;
   public ClientState95 clientState95;

   public Supplier23(byte[][] byteArrayArray, int intValue, byte[][] byteArrayArray2, ClientState95 clientState95) {
      this.byteArrayArray = byteArrayArray;
      this.intValue = intValue;
      this.byteArrayArray2 = byteArrayArray2;
      this.clientState95 = clientState95;
   }

   @Override
   public Object get() {
      return ClientUtils173.resolveByteArray(this.byteArrayArray, this.intValue, this.byteArrayArray2, this.clientState95);
   }

   public static Supplier23 resolveSupplier23(byte[][] var0, int index, byte[][] var2, ClientState95 var3) {
      return new Supplier23(var0, index, var2, var3);
   }
}
