package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier4 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier4(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState9();
   }

   public static ArrowsBooleanSupplier4 resolveArrowsBooleanSupplier4(Arrows var0) {
      return new ArrowsBooleanSupplier4(var0);
   }
}
