package callbacks;

import util.ClientUtils271;

public class Runnable11 implements Runnable {
   static {
      Class<Runnable11> var10000 = Runnable11.class;
      int var0 = 946572339;
   }

   @Override
   public void run() {
      ClientUtils271.updateState();
   }

   public static Runnable11 getRunnable11() {
      return new Runnable11();
   }
}
