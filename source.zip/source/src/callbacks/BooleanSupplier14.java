package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier14 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier14(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   static {
      Class<BooleanSupplier14> var10000 = BooleanSupplier14.class;
      int var0 = -2037860507;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier14 resolveBooleanSupplier14(BooleanSetting setting) {
      return new BooleanSupplier14(setting);
   }
}
