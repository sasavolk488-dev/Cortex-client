package callbacks;

import java.util.function.Supplier;
import util.ClientUtils168;

public class Supplier22 implements Supplier {
   @Override
   public Object get() {
      return ClientUtils168.getInteger();
   }

   public static Supplier22 getSupplier22() {
      return new Supplier22();
   }
}
