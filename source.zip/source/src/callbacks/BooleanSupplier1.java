package callbacks;

import java.util.function.BooleanSupplier;
import model.PlayerState6;

public class BooleanSupplier1 implements BooleanSupplier {
   @Override
   public boolean getAsBoolean() {
      return PlayerState6.testState11();
   }

   public static BooleanSupplier1 getBooleanSupplier1() {
      return new BooleanSupplier1();
   }
}
