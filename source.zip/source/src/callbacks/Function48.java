package callbacks;

import java.util.function.Function;
import model.NumericState12;

public class Function48 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState12)object).getIntValue();
   }

   public static Function48 getFunction48() {
      return new Function48();
   }
}
