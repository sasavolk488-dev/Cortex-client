package callbacks;

import java.util.function.Function;
import model.ClientState393;

public class Function62 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState393)object).getByteArray();
   }

   public static Function62 getFunction62() {
      return new Function62();
   }
}
