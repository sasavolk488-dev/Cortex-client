package callbacks;

import java.util.function.Function;
import model.ClientState150;

public class Function8 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState150)object).getByteArray();
   }

   public static Function8 getFunction8() {
      return new Function8();
   }
}
