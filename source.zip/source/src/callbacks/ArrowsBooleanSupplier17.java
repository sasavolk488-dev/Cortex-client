package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier17 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier17(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState17();
   }

   public static ArrowsBooleanSupplier17 resolveArrowsBooleanSupplier17(Arrows var0) {
      return new ArrowsBooleanSupplier17(var0);
   }
}
