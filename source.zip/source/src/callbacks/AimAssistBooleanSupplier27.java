package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier27 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier27(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier27 resolveAimAssistBooleanSupplier27(AimAssist var0) {
      return new AimAssistBooleanSupplier27(var0);
   }
}
