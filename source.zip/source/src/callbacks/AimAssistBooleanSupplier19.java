package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier19 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier19(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState2();
   }

   public static AimAssistBooleanSupplier19 resolveAimAssistBooleanSupplier19(AimAssist var0) {
      return new AimAssistBooleanSupplier19(var0);
   }
}
