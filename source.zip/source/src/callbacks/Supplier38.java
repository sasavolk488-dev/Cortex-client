package callbacks;

import java.util.function.Supplier;
import modules.FakeLag;

public class Supplier38 implements Supplier {
   @Override
   public Object get() {
      return FakeLag.getInteger();
   }

   public static Supplier38 getSupplier38() {
      return new Supplier38();
   }
}
