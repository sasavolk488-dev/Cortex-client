package callbacks;

import java.util.function.Function;
import model.ClientState119;

public class Function37 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState119)object).getByteArray();
   }

   public static Function37 getFunction37() {
      return new Function37();
   }
}
