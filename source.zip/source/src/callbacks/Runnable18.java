package callbacks;

import api.ClientContract99;
import java.util.ArrayList;
import model.ClientState205;


public class Runnable18 implements Runnable {
   public ArrayList arrayList;

   public Runnable18(ClientState205 clientState205) {
      this.clientState205 = clientState205;
      this.arrayList = new ArrayList();
   }

   @Override
   public void run() {
      this.arrayList.clear();

      try {
         this.arrayList.addAll(this.clientState205.getCollection());
         long value;
         synchronized (this.clientState205.value) {
            value = (long)(System.nanoTime() - this.clientState205.longValue * 1.5);
         }

         for (ClientContract99 var4 : (java.lang.Iterable<ClientContract99>) (java.lang.Iterable<?>) (this.arrayList)) {
            this.clientState205.handleClientContract99(var4, value);
         }
      } catch (Exception var6) {
      }

      this.arrayList.clear();
   }

   public final ClientState205 clientState205;
}
