package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier14 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier14(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState14();
   }

   public static ArrowsBooleanSupplier14 resolveArrowsBooleanSupplier14(Arrows var0) {
      return new ArrowsBooleanSupplier14(var0);
   }
}
