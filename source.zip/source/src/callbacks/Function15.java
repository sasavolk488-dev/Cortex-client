package callbacks;

import java.util.function.Function;
import model.ClientState115;

public class Function15 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState115)object).getByteArray();
   }

   public static Function15 getFunction15() {
      return new Function15();
   }
}
