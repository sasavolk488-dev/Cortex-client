package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier5 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier5(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState13();
   }

   public static ArrowsBooleanSupplier5 resolveArrowsBooleanSupplier5(Arrows var0) {
      return new ArrowsBooleanSupplier5(var0);
   }
}
