package callbacks;

import java.util.function.Consumer;
import modules.AirStuck;
import settings.EnumSetting;

public class AirStuckConsumer1 implements Consumer {
   public AirStuck airStuck;

   public AirStuckConsumer1(AirStuck airStuck) {
      this.airStuck = airStuck;
   }

   @Override
   public void accept(Object object) {
      this.airStuck.handleEnumSetting((EnumSetting)object);
   }

   public static AirStuckConsumer1 resolveAirStuckConsumer1(AirStuck var0) {
      return new AirStuckConsumer1(var0);
   }
}
