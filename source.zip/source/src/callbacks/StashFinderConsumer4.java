package callbacks;

import java.util.function.Consumer;
import modules.StashFinder;
import settings.Setting;

public class StashFinderConsumer4 implements Consumer {
   public StashFinder stashFinder;

   public StashFinderConsumer4(StashFinder stashFinder) {
      this.stashFinder = stashFinder;
   }

   static {
      Class<StashFinderConsumer4> var10000 = StashFinderConsumer4.class;
      int var0 = -987708410;
   }

   @Override
   public void accept(Object object) {
      this.stashFinder.handleSetting5((Setting)object);
   }

   public static StashFinderConsumer4 resolveStashFinderConsumer4(StashFinder var0) {
      return new StashFinderConsumer4(var0);
   }
}
