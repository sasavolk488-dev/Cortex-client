package callbacks;

import java.util.function.Function;
import model.ClientState393;

public class Function27 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState393)object).getByteArray4();
   }

   public static Function27 getFunction27() {
      return new Function27();
   }
}
