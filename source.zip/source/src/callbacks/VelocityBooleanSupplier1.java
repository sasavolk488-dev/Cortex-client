package callbacks;

import java.util.function.BooleanSupplier;
import modules.Velocity;

public class VelocityBooleanSupplier1 implements BooleanSupplier {
   public Velocity velocity;

   public VelocityBooleanSupplier1(Velocity velocity) {
      this.velocity = velocity;
   }

   @Override
   public boolean getAsBoolean() {
      return this.velocity.testState2();
   }

   public static VelocityBooleanSupplier1 resolveVelocityBooleanSupplier1(Velocity var0) {
      return new VelocityBooleanSupplier1(var0);
   }
}
