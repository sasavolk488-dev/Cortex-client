package callbacks;

import java.util.function.Supplier;
import modules.UseTracker;

public class UseTrackerSupplier2 implements Supplier {
   public UseTracker useTracker;

   public UseTrackerSupplier2(UseTracker useTracker) {
      this.useTracker = useTracker;
   }

   @Override
   public Object get() {
      return this.useTracker.testState2();
   }

   public static UseTrackerSupplier2 resolveUseTrackerSupplier2(UseTracker var0) {
      return new UseTrackerSupplier2(var0);
   }
}
