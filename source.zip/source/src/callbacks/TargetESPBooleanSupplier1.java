package callbacks;

import java.util.function.BooleanSupplier;
import modules.TargetESP;

public class TargetESPBooleanSupplier1 implements BooleanSupplier {
   public TargetESP targetESP;

   public TargetESPBooleanSupplier1(TargetESP targetESP) {
      this.targetESP = targetESP;
   }

   @Override
   public boolean getAsBoolean() {
      return this.targetESP.testState();
   }

   public static TargetESPBooleanSupplier1 resolveTargetESPBooleanSupplier1(TargetESP var0) {
      return new TargetESPBooleanSupplier1(var0);
   }
}
