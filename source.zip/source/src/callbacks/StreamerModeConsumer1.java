package callbacks;

import java.util.function.Consumer;
import modules.StreamerMode;
import settings.BooleanSetting;

public class StreamerModeConsumer1 implements Consumer {
   public StreamerMode streamerMode;

   public StreamerModeConsumer1(StreamerMode streamerMode) {
      this.streamerMode = streamerMode;
   }

   @Override
   public void accept(Object object) {
      this.streamerMode.handleBooleanSetting((BooleanSetting)object);
   }

   public static StreamerModeConsumer1 resolveStreamerModeConsumer1(StreamerMode var0) {
      return new StreamerModeConsumer1(var0);
   }
}
