package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.PopupDebug;

public class Consumer2 implements Consumer {
   static {
      Class<Consumer2> var10000 = Consumer2.class;
      int var0 = -1918830260;
   }

   @Override
   public void accept(Object object) {
      PopupDebug.handleEnumMap((EnumMap)object);
   }

   public static Consumer2 getConsumer2() {
      return new Consumer2();
   }
}
