package callbacks;

import model.ClientState137;

public class Runnable19 implements Runnable {
   public byte[] byteArray;

   public Runnable19(byte[] byteArray) {
      this.byteArray = byteArray;
   }

   @Override
   public void run() {
      ClientState137.handleByteArray(this.byteArray);
   }

   public static Runnable19 resolveRunnable19(byte[] var0) {
      return new Runnable19(var0);
   }
}
