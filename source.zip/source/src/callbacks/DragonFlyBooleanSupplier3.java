package callbacks;

import java.util.function.BooleanSupplier;
import modules.DragonFly;

public class DragonFlyBooleanSupplier3 implements BooleanSupplier {
   public DragonFly dragonFly;

   public DragonFlyBooleanSupplier3(DragonFly dragonFly) {
      this.dragonFly = dragonFly;
   }

   static {
      Class<DragonFlyBooleanSupplier3> var10000 = DragonFlyBooleanSupplier3.class;
      int var0 = -1425821865;
   }

   @Override
   public boolean getAsBoolean() {
      return this.dragonFly.testState3();
   }

   public static DragonFlyBooleanSupplier3 resolveDragonFlyBooleanSupplier3(DragonFly var0) {
      return new DragonFlyBooleanSupplier3(var0);
   }
}
