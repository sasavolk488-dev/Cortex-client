package callbacks;

import java.util.function.Function;
import model.ClientState197;

public class Function5 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState197)object).text2;
   }

   public static Function5 getFunction5() {
      return new Function5();
   }
}
