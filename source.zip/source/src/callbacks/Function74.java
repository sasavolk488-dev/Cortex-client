package callbacks;

import java.util.function.Function;
import model.NumericState127;

public class Function74 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState127)object).getIntValue();
   }

   public static Function74 getFunction74() {
      return new Function74();
   }
}
