package callbacks;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import model.ClientState560;


public class Runnable23 implements Runnable {
   public final ClientState560 clientState560;
   public final OutputStream outputStream;
   public final Socket socket;

   public Runnable23(Runnable13 runnable13, ClientState560 clientState560, OutputStream outputStream, Socket socket) {
      this.runnable13 = runnable13;
      this.clientState560 = clientState560;
      this.outputStream = outputStream;
      this.socket = socket;
   }

   @Override
   public void run() {
      try {
         this.updateState();
      } catch (IOException var5) {
         this.runnable13.handleClientState560(this.clientState560, var5);
      } finally {
         this.clientState560.updateState4();
         this.runnable13.handleSocket(this.socket);
      }
   }

   public void updateState() throws IOException {
      try {
         while (!Thread.currentThread().isInterrupted()) {
            ByteBuffer var1 = this.clientState560.getByteBuffer();
            if (Thread.currentThread().isInterrupted()) {
               return;
            }

            this.outputStream.write(var1.array(), var1.arrayOffset() + var1.position(), var1.remaining());
            this.outputStream.flush();
         }
      } catch (InterruptedException var2) {
         Thread.currentThread().interrupt();
      }
   }

   public final Runnable13 runnable13;
}
