package callbacks;

import java.util.function.Function;
import model.ClientState439;

public class Function55 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState439)object).getText2();
   }

   public static Function55 getFunction55() {
      return new Function55();
   }
}
