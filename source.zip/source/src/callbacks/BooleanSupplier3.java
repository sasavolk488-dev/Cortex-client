package callbacks;

import java.util.function.BooleanSupplier;
import modules.CheckBoxDebug;

public class BooleanSupplier3 implements BooleanSupplier {
   static {
      Class<BooleanSupplier3> var10000 = BooleanSupplier3.class;
      int var0 = -18139628;
   }

   @Override
   public boolean getAsBoolean() {
      return CheckBoxDebug.testState();
   }

   public static BooleanSupplier3 getBooleanSupplier3() {
      return new BooleanSupplier3();
   }
}
