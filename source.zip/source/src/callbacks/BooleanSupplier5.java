package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier5 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier5(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier5 resolveBooleanSupplier5(BooleanSetting setting) {
      return new BooleanSupplier5(setting);
   }
}
