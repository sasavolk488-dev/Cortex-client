package callbacks;

import java.util.function.BooleanSupplier;
import modules.CheckBoxDebug;

public class BooleanSupplier12 implements BooleanSupplier {
   static {
      Class<BooleanSupplier12> var10000 = BooleanSupplier12.class;
      int var0 = 983833315;
   }

   @Override
   public boolean getAsBoolean() {
      return CheckBoxDebug.testState2();
   }

   public static BooleanSupplier12 getBooleanSupplier12() {
      return new BooleanSupplier12();
   }
}
