package callbacks;

import java.util.function.BooleanSupplier;
import model.ClientState478;

public class BooleanSupplier22 implements BooleanSupplier {
   public ClientState478 clientState478;

   public BooleanSupplier22(ClientState478 clientState478) {
      this.clientState478 = clientState478;
   }

   @Override
   public boolean getAsBoolean() {
      return this.clientState478.testState();
   }

   public static BooleanSupplier22 resolveBooleanSupplier22(ClientState478 var0) {
      return new BooleanSupplier22(var0);
   }
}
