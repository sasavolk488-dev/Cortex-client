package callbacks;

import java.util.function.Consumer;
import modules.StreamerMode;
import settings.BooleanSetting;

public class StreamerModeConsumer3 implements Consumer {
   public StreamerMode streamerMode;

   public StreamerModeConsumer3(StreamerMode streamerMode) {
      this.streamerMode = streamerMode;
   }

   @Override
   public void accept(Object object) {
      this.streamerMode.handleBooleanSetting2((BooleanSetting)object);
   }

   public static StreamerModeConsumer3 resolveStreamerModeConsumer3(StreamerMode var0) {
      return new StreamerModeConsumer3(var0);
   }
}
