package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier32 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier32(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState10();
   }

   public static AimAssistBooleanSupplier32 resolveAimAssistBooleanSupplier32(AimAssist var0) {
      return new AimAssistBooleanSupplier32(var0);
   }
}
