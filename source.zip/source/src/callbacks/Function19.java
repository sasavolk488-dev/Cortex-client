package callbacks;

import java.util.function.Function;
import model.ClientState185;

public class Function19 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState185)object).getText();
   }

   public static Function19 getFunction19() {
      return new Function19();
   }
}
