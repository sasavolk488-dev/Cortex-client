package callbacks;

import java.util.function.Function;
import model.ClientState66;

public class Function72 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState66)object).getText();
   }

   public static Function72 getFunction72() {
      return new Function72();
   }
}
