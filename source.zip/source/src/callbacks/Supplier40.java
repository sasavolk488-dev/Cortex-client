package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup54;

public class Supplier40 implements Supplier {
   public OptionGroup54 optionGroup54;

   public Supplier40(OptionGroup54 optionGroup54) {
      this.optionGroup54 = optionGroup54;
   }

   @Override
   public Object get() {
      return this.optionGroup54.getItemStack();
   }

   public static Supplier40 resolveSupplier40(OptionGroup54 var0) {
      return new Supplier40(var0);
   }
}
