package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier19 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier19(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier19 resolveSupplier19(OptionGroup132 var0) {
      return new Supplier19(var0);
   }
}
