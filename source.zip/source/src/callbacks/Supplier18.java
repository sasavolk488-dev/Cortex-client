package callbacks;

import java.util.function.Supplier;
import model.ClientState585;

public class Supplier18 implements Supplier {
   public ClientState585 clientState585;

   public Supplier18(ClientState585 clientState585) {
      this.clientState585 = clientState585;
   }

   @Override
   public Object get() {
      return this.clientState585.isBooleanValue();
   }

   public static Supplier18 resolveSupplier18(ClientState585 var0) {
      return new Supplier18(var0);
   }
}
