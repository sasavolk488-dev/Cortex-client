package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier4 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier4(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier4 resolveSupplier4(OptionGroup132 var0) {
      return new Supplier4(var0);
   }
}
