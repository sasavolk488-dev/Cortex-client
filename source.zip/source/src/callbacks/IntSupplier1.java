package callbacks;

import clickgui.widgets.WidgetPart16;
import java.util.function.IntSupplier;

public class IntSupplier1 implements IntSupplier {
   @Override
   public int getAsInt() {
      return WidgetPart16.getInt();
   }

   public static IntSupplier1 getIntSupplier1() {
      return new IntSupplier1();
   }
}
