package callbacks;

import java.util.function.Function;
import model.ClientState226;

public class Function69 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState226)object).getText();
   }

   public static Function69 getFunction69() {
      return new Function69();
   }
}
