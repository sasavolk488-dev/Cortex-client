package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.KillAura;

public class Consumer36 implements Consumer {
   @Override
   public void accept(Object object) {
      KillAura.handleEnumMap((EnumMap)object);
   }

   public static Consumer36 getConsumer36() {
      return new Consumer36();
   }
}
