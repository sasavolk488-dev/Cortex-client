package callbacks;

import java.util.function.BooleanSupplier;
import modules.DragonFly;

public class DragonFlyBooleanSupplier4 implements BooleanSupplier {
   public DragonFly dragonFly;

   public DragonFlyBooleanSupplier4(DragonFly dragonFly) {
      this.dragonFly = dragonFly;
   }

   static {
      Class<DragonFlyBooleanSupplier4> var10000 = DragonFlyBooleanSupplier4.class;
      int var0 = 1435351595;
   }

   @Override
   public boolean getAsBoolean() {
      return this.dragonFly.testState4();
   }

   public static DragonFlyBooleanSupplier4 resolveDragonFlyBooleanSupplier4(DragonFly var0) {
      return new DragonFlyBooleanSupplier4(var0);
   }
}
