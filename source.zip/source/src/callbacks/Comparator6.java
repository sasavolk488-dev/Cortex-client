package callbacks;

import java.util.Comparator;
import model.ClientState124;
import model.ClientState323;

public class Comparator6 implements Comparator {
   @Override
   public int compare(Object object, Object object2) {
      return ClientState323.calculateInt((ClientState124)object, (ClientState124)object2);
   }

   public static Comparator6 getComparator6() {
      return new Comparator6();
   }
}
