package callbacks;

import java.util.function.Function;
import model.ClientState119;

public class Function7 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState119)object).getByteArray3();
   }

   public static Function7 getFunction7() {
      return new Function7();
   }
}
