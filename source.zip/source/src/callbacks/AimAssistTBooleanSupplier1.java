package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssistT;

public class AimAssistTBooleanSupplier1 implements BooleanSupplier {
   public AimAssistT aimAssistT;

   public AimAssistTBooleanSupplier1(AimAssistT aimAssistT) {
      this.aimAssistT = aimAssistT;
   }

   static {
      Class<AimAssistTBooleanSupplier1> var10000 = AimAssistTBooleanSupplier1.class;
      int var0 = -1749940768;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssistT.testState3();
   }

   public static AimAssistTBooleanSupplier1 resolveAimAssistTBooleanSupplier1(AimAssistT var0) {
      return new AimAssistTBooleanSupplier1(var0);
   }
}
