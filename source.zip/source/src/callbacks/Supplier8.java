package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier8 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier8(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier8 resolveSupplier8(OptionGroup132 var0) {
      return new Supplier8(var0);
   }
}
