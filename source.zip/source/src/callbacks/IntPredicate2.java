package callbacks;

import java.util.function.IntPredicate;
import model.ClientState242;

public class IntPredicate2 implements IntPredicate {
   @Override
   public boolean test(int index) {
      return ClientState242.testInt2(index);
   }

   public static IntPredicate2 getIntPredicate2() {
      return new IntPredicate2();
   }
}
