package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier22 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier22(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState15();
   }

   public static AimAssistBooleanSupplier22 resolveAimAssistBooleanSupplier22(AimAssist var0) {
      return new AimAssistBooleanSupplier22(var0);
   }
}
