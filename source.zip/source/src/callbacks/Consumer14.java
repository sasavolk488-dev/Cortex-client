package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.AntiAFK;

public class Consumer14 implements Consumer {
   @Override
   public void accept(Object object) {
      AntiAFK.handleEnumMap((EnumMap)object);
   }

   public static Consumer14 getConsumer14() {
      return new Consumer14();
   }
}
