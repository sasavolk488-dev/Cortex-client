package callbacks;

import java.util.function.Function;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class Function22 implements Function {
   @Override
   public Object apply(Object object) {
      return new ItemStack((Item)object);
   }

   public static Function22 getFunction22() {
      return new Function22();
   }
}
