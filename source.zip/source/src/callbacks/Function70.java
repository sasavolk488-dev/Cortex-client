package callbacks;

import java.util.function.Function;
import model.ClientState393;

public class Function70 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState393)object).getByteArray3();
   }

   public static Function70 getFunction70() {
      return new Function70();
   }
}
