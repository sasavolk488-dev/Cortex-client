package callbacks;

import java.util.function.Function;
import model.NumericState32;

public class Function43 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState32)object).getIntValue();
   }

   public static Function43 getFunction43() {
      return new Function43();
   }
}
