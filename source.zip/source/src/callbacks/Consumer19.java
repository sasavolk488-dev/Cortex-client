package callbacks;

import client.Cortex;
import java.util.function.Consumer;
import modules.AutoAuth;

public class Consumer19 implements Consumer {
   public Cortex cortex;

   public Consumer19(Cortex cortex) {
      this.cortex = cortex;
   }

   @Override
   public void accept(Object object) {
      this.cortex.handleAutoAuth((AutoAuth)object);
   }

   public static Consumer19 resolveConsumer19(Cortex var0) {
      return new Consumer19(var0);
   }
}
