package callbacks;

import java.util.function.Supplier;
import model.ClientState41;

public class Supplier5 implements Supplier {
   public ClientState41 clientState41;

   public Supplier5(ClientState41 clientState41) {
      this.clientState41 = clientState41;
   }

   @Override
   public Object get() {
      return this.clientState41.testState();
   }

   public static Supplier5 resolveSupplier5(ClientState41 var0) {
      return new Supplier5(var0);
   }
}
