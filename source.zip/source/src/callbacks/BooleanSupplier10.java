package callbacks;

import java.util.function.BooleanSupplier;
import settings.KeyBindSetting;

public class BooleanSupplier10 implements BooleanSupplier {
   public KeyBindSetting keyBindSetting;

   public BooleanSupplier10(KeyBindSetting keyBindSetting) {
      this.keyBindSetting = keyBindSetting;
   }

   static {
      Class<BooleanSupplier10> var10000 = BooleanSupplier10.class;
      int var0 = -1835572621;
   }

   @Override
   public boolean getAsBoolean() {
      return this.keyBindSetting.testState();
   }

   public static BooleanSupplier10 resolveBooleanSupplier10(KeyBindSetting setting) {
      return new BooleanSupplier10(setting);
   }
}
