package callbacks;

import java.util.function.BooleanSupplier;
import modules.ESP;

public class ESPBooleanSupplier4 implements BooleanSupplier {
   public ESP eSP;

   public ESPBooleanSupplier4(ESP eSP) {
      this.eSP = eSP;
   }

   @Override
   public boolean getAsBoolean() {
      return this.eSP.testState6();
   }

   public static ESPBooleanSupplier4 resolveESPBooleanSupplier4(ESP var0) {
      return new ESPBooleanSupplier4(var0);
   }
}
