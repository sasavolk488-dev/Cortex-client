package callbacks;

import java.util.Comparator;
import model.ClientState315;
import util.ClientUtils49;

public class Comparator1 implements Comparator {
   static {
      Class<Comparator1> var10000 = Comparator1.class;
      int var0 = 1186582715;
   }

   @Override
   public int compare(Object object, Object object2) {
      return ClientUtils49.calculateInt((ClientState315)object, (ClientState315)object2);
   }

   public static Comparator1 getComparator1() {
      return new Comparator1();
   }
}
