package callbacks;

import java.util.function.Supplier;
import settings.BooleanSetting;

public class Supplier45 implements Supplier {
   public BooleanSetting booleanSetting;

   public Supplier45(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   @Override
   public Object get() {
      return this.booleanSetting.getValue();
   }

   public static Supplier45 resolveSupplier45(BooleanSetting setting) {
      return new Supplier45(setting);
   }
}
