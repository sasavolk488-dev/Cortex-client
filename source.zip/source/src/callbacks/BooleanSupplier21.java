package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier21 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier21(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   static {
      Class<BooleanSupplier21> var10000 = BooleanSupplier21.class;
      int var0 = -1100286231;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier21 resolveBooleanSupplier21(BooleanSetting setting) {
      return new BooleanSupplier21(setting);
   }
}
