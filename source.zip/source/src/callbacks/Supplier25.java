package callbacks;

import java.util.function.Supplier;
import util.ClientUtils70;

public class Supplier25 implements Supplier {
   @Override
   public Object get() {
      return ClientUtils70.getCompletableFuture();
   }

   public static Supplier25 getSupplier25() {
      return new Supplier25();
   }
}
