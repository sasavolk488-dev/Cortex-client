package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup87;

public class Supplier15 implements Supplier {
   public OptionGroup87 optionGroup87;

   public Supplier15(OptionGroup87 optionGroup87) {
      this.optionGroup87 = optionGroup87;
   }

   @Override
   public Object get() {
      return this.optionGroup87.getItemStack();
   }

   public static Supplier15 resolveSupplier15(OptionGroup87 var0) {
      return new Supplier15(var0);
   }
}
