package callbacks;

import java.util.function.Consumer;
import modules.Freecam;
import settings.BooleanSetting;

public class FreecamConsumer1 implements Consumer {
   public Freecam freecam;

   public FreecamConsumer1(Freecam freecam) {
      this.freecam = freecam;
   }

   @Override
   public void accept(Object object) {
      this.freecam.handleBooleanSetting2((BooleanSetting)object);
   }

   public static FreecamConsumer1 resolveFreecamConsumer1(Freecam var0) {
      return new FreecamConsumer1(var0);
   }
}
