package callbacks;

import java.util.function.Supplier;
import model.ClientState568;

public class Supplier2 implements Supplier {
   public ClientState568 clientState568;

   public Supplier2(ClientState568 clientState568) {
      this.clientState568 = clientState568;
   }

   @Override
   public Object get() {
      return this.clientState568.isBooleanValue();
   }

   public static Supplier2 resolveSupplier2(ClientState568 var0) {
      return new Supplier2(var0);
   }
}
