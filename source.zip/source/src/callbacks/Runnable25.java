package callbacks;

import util.ClientUtils206;

public class Runnable25 implements Runnable {
   static {
      Class<Runnable25> var10000 = Runnable25.class;
      int var0 = -1577615039;
   }

   @Override
   public void run() {
      ClientUtils206.updateState();
   }

   public static Runnable25 getRunnable25() {
      return new Runnable25();
   }
}
