package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.AutoTotem;

public class Consumer28 implements Consumer {
   @Override
   public void accept(Object object) {
      AutoTotem.handleEnumMap((EnumMap)object);
   }

   public static Consumer28 getConsumer28() {
      return new Consumer28();
   }
}
