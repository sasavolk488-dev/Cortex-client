package callbacks;

import java.util.function.BooleanSupplier;
import modules.KillAura;

public class KillAuraBooleanSupplier1 implements BooleanSupplier {
   public KillAura killAura;

   public KillAuraBooleanSupplier1(KillAura killAura) {
      this.killAura = killAura;
   }

   @Override
   public boolean getAsBoolean() {
      return this.killAura.testState2();
   }

   public static KillAuraBooleanSupplier1 resolveKillAuraBooleanSupplier1(KillAura var0) {
      return new KillAuraBooleanSupplier1(var0);
   }
}
