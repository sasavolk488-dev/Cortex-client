package callbacks;

import java.util.function.Function;
import model.ClientState284;

public class Function54 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState284)object).getUUID();
   }

   public static Function54 getFunction54() {
      return new Function54();
   }
}
