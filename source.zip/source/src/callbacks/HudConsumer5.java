package callbacks;

import java.util.function.Consumer;
import modules.Hud;
import settings.Setting;

public class HudConsumer5 implements Consumer {
   public Hud hud;

   public HudConsumer5(Hud hud) {
      this.hud = hud;
   }

   @Override
   public void accept(Object object) {
      this.hud.handleSetting3((Setting)object);
   }

   public static HudConsumer5 resolveHudConsumer5(Hud var0) {
      return new HudConsumer5(var0);
   }
}
