package callbacks;

import java.util.function.BooleanSupplier;
import modules.PearlTarget;

public class PearlTargetBooleanSupplier1 implements BooleanSupplier {
   public PearlTarget pearlTarget;

   public PearlTargetBooleanSupplier1(PearlTarget pearlTarget) {
      this.pearlTarget = pearlTarget;
   }

   @Override
   public boolean getAsBoolean() {
      return this.pearlTarget.testState7();
   }

   public static PearlTargetBooleanSupplier1 resolvePearlTargetBooleanSupplier1(PearlTarget var0) {
      return new PearlTargetBooleanSupplier1(var0);
   }
}
