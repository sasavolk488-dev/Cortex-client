package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier18 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier18(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState12();
   }

   public static ArrowsBooleanSupplier18 resolveArrowsBooleanSupplier18(Arrows var0) {
      return new ArrowsBooleanSupplier18(var0);
   }
}
