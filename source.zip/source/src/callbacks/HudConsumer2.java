package callbacks;

import java.util.function.Consumer;
import modules.Hud;
import settings.Setting;

public class HudConsumer2 implements Consumer {
   public Hud hud;

   public HudConsumer2(Hud hud) {
      this.hud = hud;
   }

   @Override
   public void accept(Object object) {
      this.hud.handleSetting((Setting)object);
   }

   public static HudConsumer2 resolveHudConsumer2(Hud var0) {
      return new HudConsumer2(var0);
   }
}
