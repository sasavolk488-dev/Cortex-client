package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier3 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier3(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState4();
   }

   public static ArrowsBooleanSupplier3 resolveArrowsBooleanSupplier3(Arrows var0) {
      return new ArrowsBooleanSupplier3(var0);
   }
}
