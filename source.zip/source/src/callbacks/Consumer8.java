package callbacks;

import java.util.function.Consumer;
import model.ClientState404;
import model.ClientState505;

public class Consumer8 implements Consumer {
   public ClientState404 clientState404;

   public Consumer8(ClientState404 clientState404) {
      this.clientState404 = clientState404;
   }

   @Override
   public void accept(Object object) {
      this.clientState404.resolveClientState404((ClientState505)object);
   }

   public static Consumer8 resolveConsumer8(ClientState404 var0) {
      return new Consumer8(var0);
   }
}
