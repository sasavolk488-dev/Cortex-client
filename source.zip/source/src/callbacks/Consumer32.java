package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.NoRender;

public class Consumer32 implements Consumer {
   @Override
   public void accept(Object object) {
      NoRender.handleEnumMap((EnumMap)object);
   }

   public static Consumer32 getConsumer32() {
      return new Consumer32();
   }
}
