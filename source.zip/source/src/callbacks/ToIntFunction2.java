package callbacks;

import events.EventBus;
import java.util.function.ToIntFunction;
import model.ClientState94;

public class ToIntFunction2 implements ToIntFunction {
   @Override
   public int applyAsInt(Object object) {
      return EventBus.calculateInt((ClientState94)object);
   }

   public static ToIntFunction2 getToIntFunction2() {
      return new ToIntFunction2();
   }
}
