package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier37 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier37(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier37 resolveSupplier37(OptionGroup132 var0) {
      return new Supplier37(var0);
   }
}
