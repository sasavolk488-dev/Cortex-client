package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.Arrows;

public class Consumer29 implements Consumer {
   @Override
   public void accept(Object object) {
      Arrows.handleEnumMap((EnumMap)object);
   }

   public static Consumer29 getConsumer29() {
      return new Consumer29();
   }
}
