package callbacks;

import java.util.function.Supplier;
import modules.AutoSwap;

public class AutoSwapSupplier2 implements Supplier {
   public AutoSwap autoSwap;

   public AutoSwapSupplier2(AutoSwap autoSwap) {
      this.autoSwap = autoSwap;
   }

   @Override
   public Object get() {
      return this.autoSwap.getItemStack2();
   }

   public static AutoSwapSupplier2 resolveAutoSwapSupplier2(AutoSwap var0) {
      return new AutoSwapSupplier2(var0);
   }
}
