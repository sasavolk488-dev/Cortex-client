package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup87;

public class Supplier42 implements Supplier {
   public OptionGroup87 optionGroup87;

   public Supplier42(OptionGroup87 optionGroup87) {
      this.optionGroup87 = optionGroup87;
   }

   @Override
   public Object get() {
      return this.optionGroup87.getItemStack();
   }

   public static Supplier42 resolveSupplier42(OptionGroup87 var0) {
      return new Supplier42(var0);
   }
}
