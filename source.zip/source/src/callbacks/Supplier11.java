package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier11 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier11(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier11 resolveSupplier11(OptionGroup132 var0) {
      return new Supplier11(var0);
   }
}
