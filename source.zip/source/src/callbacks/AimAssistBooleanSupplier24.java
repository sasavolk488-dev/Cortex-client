package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier24 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier24(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState19();
   }

   public static AimAssistBooleanSupplier24 resolveAimAssistBooleanSupplier24(AimAssist var0) {
      return new AimAssistBooleanSupplier24(var0);
   }
}
