package callbacks;

import clickgui.widgets.WidgetPart9;
import java.util.function.BooleanSupplier;

public class BooleanSupplier8 implements BooleanSupplier {
   @Override
   public boolean getAsBoolean() {
      return WidgetPart9.testState4();
   }

   public static BooleanSupplier8 getBooleanSupplier8() {
      return new BooleanSupplier8();
   }
}
