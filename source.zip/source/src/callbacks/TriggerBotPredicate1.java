package callbacks;

import java.util.function.Predicate;
import modules.TriggerBot;
import net.minecraft.entity.player.PlayerEntity;
import settings.EnumSetting;
import settings.options.OptionGroup25;


public final class TriggerBotPredicate1 extends EnumSetting implements Predicate {
   public TriggerBotPredicate1(TriggerBot triggerBot) {
      super("armorFilter", OptionGroup25.IGNORE);
      this.triggerBot = triggerBot;
   }

   public boolean test(PlayerEntity player) {
      return switch ((OptionGroup25)this.getValue()) {
         case IGNORE -> true;
         case ARMORED -> this.triggerBot.testPlayer(player);
         case UNARMORED -> !this.triggerBot.testPlayer(player);
         case BY_TYPE -> this.triggerBot.testPlayer2(player);
      };
   }

   public final TriggerBot triggerBot;

   @Override
   public boolean test(Object var1) {
      return this.test((PlayerEntity)var1);
   }
}
