package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier12 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier12(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState17();
   }

   public static AimAssistBooleanSupplier12 resolveAimAssistBooleanSupplier12(AimAssist var0) {
      return new AimAssistBooleanSupplier12(var0);
   }
}
