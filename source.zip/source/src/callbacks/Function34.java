package callbacks;

import java.util.function.Function;
import model.ClientState179;

public class Function34 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState179)object).getIntValue2();
   }

   public static Function34 getFunction34() {
      return new Function34();
   }
}
