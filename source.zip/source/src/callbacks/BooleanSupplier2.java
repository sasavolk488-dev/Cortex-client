package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier2 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier2(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier2 resolveBooleanSupplier2(BooleanSetting setting) {
      return new BooleanSupplier2(setting);
   }
}
