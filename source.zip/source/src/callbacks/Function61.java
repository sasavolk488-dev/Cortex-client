package callbacks;

import java.util.function.Function;
import model.NumericState95;

public class Function61 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState95)object).getLongValue();
   }

   public static Function61 getFunction61() {
      return new Function61();
   }
}
