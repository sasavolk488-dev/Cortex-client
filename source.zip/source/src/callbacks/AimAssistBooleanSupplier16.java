package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier16 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier16(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState10();
   }

   public static AimAssistBooleanSupplier16 resolveAimAssistBooleanSupplier16(AimAssist var0) {
      return new AimAssistBooleanSupplier16(var0);
   }
}
