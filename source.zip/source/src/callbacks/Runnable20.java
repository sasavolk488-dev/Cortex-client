package callbacks;

import model.ClientState137;

public class Runnable20 implements Runnable {
   public ClientState137 clientState137;

   public Runnable20(ClientState137 clientState137) {
      this.clientState137 = clientState137;
   }

   @Override
   public void run() {
      this.clientState137.updateState4();
   }

   public static Runnable20 resolveRunnable20(ClientState137 var0) {
      return new Runnable20(var0);
   }
}
