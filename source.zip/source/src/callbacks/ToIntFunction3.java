package callbacks;

import api.ClientContract18;
import java.util.function.ToIntFunction;

public class ToIntFunction3 implements ToIntFunction {
   @Override
   public int applyAsInt(Object object) {
      return ClientContract18.calculateInt((ClientContract18)object);
   }

   public static ToIntFunction3 getToIntFunction3() {
      return new ToIntFunction3();
   }
}
