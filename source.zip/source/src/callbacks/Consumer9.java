package callbacks;

import java.util.function.Consumer;
import model.ClientState137;
import model.NumericState95;
import modules.AutoCaptcha;

public class Consumer9 implements Consumer {
   public NumericState95 numericState95;

   public Consumer9(NumericState95 numericState95) {
      this.numericState95 = numericState95;
   }

   static {
      Class<Consumer9> var10000 = Consumer9.class;
      int var0 = -1415042839;
   }

   @Override
   public void accept(Object object) {
      ClientState137.handleNumericState95(this.numericState95, (AutoCaptcha)object);
   }

   public static Consumer9 resolveConsumer9(NumericState95 var0) {
      return new Consumer9(var0);
   }
}
