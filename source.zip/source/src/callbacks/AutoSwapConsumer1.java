package callbacks;

import java.util.function.Consumer;
import modules.AutoSwap;
import net.minecraft.item.ItemStack;

public class AutoSwapConsumer1 implements Consumer {
   public AutoSwap autoSwap;

   public AutoSwapConsumer1(AutoSwap autoSwap) {
      this.autoSwap = autoSwap;
   }

   @Override
   public void accept(Object object) {
      this.autoSwap.handleItemStack3((ItemStack)object);
   }

   public static AutoSwapConsumer1 resolveAutoSwapConsumer1(AutoSwap var0) {
      return new AutoSwapConsumer1(var0);
   }
}
