package callbacks;

import client.Cortex;
import java.util.function.Consumer;
import model.ClientState105;

public class Consumer20 implements Consumer {
   public Cortex cortex;

   public Consumer20(Cortex cortex) {
      this.cortex = cortex;
   }

   static {
      Class<Consumer20> var10000 = Consumer20.class;
      int var0 = 1350162448;
   }

   @Override
   public void accept(Object object) {
      this.cortex.handleClientState105((ClientState105)object);
   }

   public static Consumer20 resolveConsumer20(Cortex var0) {
      return new Consumer20(var0);
   }
}
