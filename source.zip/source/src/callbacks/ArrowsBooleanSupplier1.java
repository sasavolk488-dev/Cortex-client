package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier1 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier1(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState7();
   }

   public static ArrowsBooleanSupplier1 resolveArrowsBooleanSupplier1(Arrows var0) {
      return new ArrowsBooleanSupplier1(var0);
   }
}
