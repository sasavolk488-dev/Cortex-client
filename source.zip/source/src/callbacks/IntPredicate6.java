package callbacks;

import java.util.function.IntPredicate;
import modules.StreamerMode;

public class IntPredicate6 implements IntPredicate {
   @Override
   public boolean test(int index) {
      return StreamerMode.testInt(index);
   }

   public static IntPredicate6 getIntPredicate6() {
      return new IntPredicate6();
   }
}
