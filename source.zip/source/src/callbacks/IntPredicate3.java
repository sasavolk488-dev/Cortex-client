package callbacks;

import java.util.function.IntPredicate;
import model.ClientState150;

public class IntPredicate3 implements IntPredicate {
   static {
      Class<IntPredicate3> var10000 = IntPredicate3.class;
      int var0 = -90692941;
   }

   @Override
   public boolean test(int index) {
      return ClientState150.testInt(index);
   }

   public static IntPredicate3 getIntPredicate3() {
      return new IntPredicate3();
   }
}
