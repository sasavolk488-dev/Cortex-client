package callbacks;

import java.util.function.BooleanSupplier;
import modules.AutoTotem;

public class AutoTotemBooleanSupplier1 implements BooleanSupplier {
   public AutoTotem autoTotem;

   public AutoTotemBooleanSupplier1(AutoTotem autoTotem) {
      this.autoTotem = autoTotem;
   }

   @Override
   public boolean getAsBoolean() {
      return this.autoTotem.testState2();
   }

   public static AutoTotemBooleanSupplier1 resolveAutoTotemBooleanSupplier1(AutoTotem var0) {
      return new AutoTotemBooleanSupplier1(var0);
   }
}
