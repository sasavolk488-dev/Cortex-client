package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier25 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier25(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState20();
   }

   public static AimAssistBooleanSupplier25 resolveAimAssistBooleanSupplier25(AimAssist var0) {
      return new AimAssistBooleanSupplier25(var0);
   }
}
