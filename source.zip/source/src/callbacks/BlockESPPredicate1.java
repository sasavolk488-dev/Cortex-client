package callbacks;

import java.util.function.Predicate;
import modules.BlockESP;
import net.minecraft.block.BlockState;

public class BlockESPPredicate1 implements Predicate {
   public BlockESP blockESP;

   public BlockESPPredicate1(BlockESP blockESP) {
      this.blockESP = blockESP;
   }

   @Override
   public boolean test(Object object) {
      return this.blockESP.testBlockState((BlockState)object);
   }

   public static BlockESPPredicate1 resolveBlockESPPredicate1(BlockESP var0) {
      return new BlockESPPredicate1(var0);
   }
}
