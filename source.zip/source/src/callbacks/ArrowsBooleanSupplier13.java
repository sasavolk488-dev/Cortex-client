package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier13 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier13(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState16();
   }

   public static ArrowsBooleanSupplier13 resolveArrowsBooleanSupplier13(Arrows var0) {
      return new ArrowsBooleanSupplier13(var0);
   }
}
