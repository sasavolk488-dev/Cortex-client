package callbacks;

import java.util.function.Supplier;
import modules.UseTracker;

public class UseTrackerSupplier1 implements Supplier {
   public UseTracker useTracker;

   public UseTrackerSupplier1(UseTracker useTracker) {
      this.useTracker = useTracker;
   }

   @Override
   public Object get() {
      return this.useTracker.testState4();
   }

   public static UseTrackerSupplier1 resolveUseTrackerSupplier1(UseTracker var0) {
      return new UseTrackerSupplier1(var0);
   }
}
