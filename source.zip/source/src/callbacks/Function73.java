package callbacks;

import java.util.function.Function;
import model.ClientState264;

public class Function73 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState264)object).getText();
   }

   public static Function73 getFunction73() {
      return new Function73();
   }
}
