package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier4 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier4(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier4 resolveAimAssistBooleanSupplier4(AimAssist var0) {
      return new AimAssistBooleanSupplier4(var0);
   }
}
