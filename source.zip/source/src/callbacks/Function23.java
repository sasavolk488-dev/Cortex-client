package callbacks;

import java.util.function.Function;
import model.ClientState189;

public class Function23 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState189)object).getByteArrayArray();
   }

   public static Function23 getFunction23() {
      return new Function23();
   }
}
