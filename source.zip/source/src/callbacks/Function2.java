package callbacks;

import java.util.function.Function;
import model.ClientState408;

public class Function2 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState408)object).getLongValue();
   }

   public static Function2 getFunction2() {
      return new Function2();
   }
}
