package callbacks;

import java.util.function.BooleanSupplier;
import modules.TriggerBot;

public class TriggerBotBooleanSupplier3 implements BooleanSupplier {
   public TriggerBot triggerBot;

   public TriggerBotBooleanSupplier3(TriggerBot triggerBot) {
      this.triggerBot = triggerBot;
   }

   @Override
   public boolean getAsBoolean() {
      return this.triggerBot.testState4();
   }

   public static TriggerBotBooleanSupplier3 resolveTriggerBotBooleanSupplier3(TriggerBot var0) {
      return new TriggerBotBooleanSupplier3(var0);
   }
}
