package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.NoTrace;

public class Consumer22 implements Consumer {
   @Override
   public void accept(Object object) {
      NoTrace.handleEnumMap((EnumMap)object);
   }

   public static Consumer22 getConsumer22() {
      return new Consumer22();
   }
}
