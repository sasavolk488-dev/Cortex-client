package callbacks;

import java.util.function.BooleanSupplier;
import model.ClientState478;

public class BooleanSupplier18 implements BooleanSupplier {
   public ClientState478 clientState478;

   public BooleanSupplier18(ClientState478 clientState478) {
      this.clientState478 = clientState478;
   }

   @Override
   public boolean getAsBoolean() {
      return this.clientState478.testState();
   }

   public static BooleanSupplier18 resolveBooleanSupplier18(ClientState478 var0) {
      return new BooleanSupplier18(var0);
   }
}
