package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup87;

public class Supplier29 implements Supplier {
   public OptionGroup87 optionGroup87;

   public Supplier29(OptionGroup87 optionGroup87) {
      this.optionGroup87 = optionGroup87;
   }

   @Override
   public Object get() {
      return this.optionGroup87.getItemStack();
   }

   public static Supplier29 resolveSupplier29(OptionGroup87 var0) {
      return new Supplier29(var0);
   }
}
