package callbacks;

import java.util.function.Function;
import model.ClientState179;

public class Function33 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState179)object).getUUID();
   }

   public static Function33 getFunction33() {
      return new Function33();
   }
}
