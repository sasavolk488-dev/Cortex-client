package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.AimBot;

public class Consumer3 implements Consumer {
   @Override
   public void accept(Object object) {
      AimBot.handleLinkedHashMap2((LinkedHashMap)object);
   }

   public static Consumer3 getConsumer3() {
      return new Consumer3();
   }
}
