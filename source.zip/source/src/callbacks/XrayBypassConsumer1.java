package callbacks;

import java.util.function.Consumer;
import modules.XrayBypass;

public class XrayBypassConsumer1 implements Consumer {
   public XrayBypass xrayBypass;

   public XrayBypassConsumer1(XrayBypass xrayBypass) {
      this.xrayBypass = xrayBypass;
   }

   @Override
   public void accept(Object object) {
      this.xrayBypass.handleValue(object);
   }

   public static XrayBypassConsumer1 resolveXrayBypassConsumer1(XrayBypass var0) {
      return new XrayBypassConsumer1(var0);
   }
}
