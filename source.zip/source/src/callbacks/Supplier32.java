package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier32 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier32(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier32 resolveSupplier32(OptionGroup132 var0) {
      return new Supplier32(var0);
   }
}
