package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier2 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier2(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState3();
   }

   public static ArrowsBooleanSupplier2 resolveArrowsBooleanSupplier2(Arrows var0) {
      return new ArrowsBooleanSupplier2(var0);
   }
}
