package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier1 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier1(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier1 resolveAimAssistBooleanSupplier1(AimAssist var0) {
      return new AimAssistBooleanSupplier1(var0);
   }
}
