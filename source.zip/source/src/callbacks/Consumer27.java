package callbacks;

import java.util.ArrayList;
import java.util.function.Consumer;
import modules.DebugModule;

public class Consumer27 implements Consumer {
   static {
      Class<Consumer27> var10000 = Consumer27.class;
      int var0 = 90986922;
   }

   @Override
   public void accept(Object object) {
      DebugModule.handleArrayList((ArrayList)object);
   }

   public static Consumer27 getConsumer27() {
      return new Consumer27();
   }
}
