package callbacks;

import util.ClientUtils125;

public class Runnable10 implements Runnable {
   static {
      Class<Runnable10> var10000 = Runnable10.class;
      int var0 = -1815500591;
   }

   @Override
   public void run() {
      ClientUtils125.updateState5();
   }

   public static Runnable10 getRunnable10() {
      return new Runnable10();
   }
}
