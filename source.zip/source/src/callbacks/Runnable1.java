package callbacks;

import model.ClientState137;
import model.ClientState173;

public class Runnable1 implements Runnable {
   public ClientState173[] clientState173Array;
   public int[] intArray;
   public int[] intArray2;

   public Runnable1(ClientState173[] clientState173Array, int[] intArray, int[] intArray2) {
      this.clientState173Array = clientState173Array;
      this.intArray = intArray;
      this.intArray2 = intArray2;
   }

   @Override
   public void run() {
      ClientState137.handleClientState173Array(this.clientState173Array, this.intArray, this.intArray2);
   }

   public static Runnable1 resolveRunnable1(ClientState173[] var0, int[] var1, int[] var2) {
      return new Runnable1(var0, var1, var2);
   }
}
