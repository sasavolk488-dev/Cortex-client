package callbacks;

import java.util.function.BooleanSupplier;
import model.ClientState103;

public class BooleanSupplier6 implements BooleanSupplier {
   @Override
   public boolean getAsBoolean() {
      return ClientState103.testState();
   }

   public static BooleanSupplier6 getBooleanSupplier6() {
      return new BooleanSupplier6();
   }
}
