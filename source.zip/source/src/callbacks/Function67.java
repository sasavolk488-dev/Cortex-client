package callbacks;

import java.util.concurrent.Executor;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import model.ClientState95;
import util.ClientUtils173;

public class Function67 implements Function {
   public ClientState95 clientState95;
   public Object[] valueArray;
   public Consumer consumer;
   public Executor executor;
   public Supplier supplier;
   public int intValue;

   public Function67(ClientState95 clientState95, Object[] valueArray, Consumer consumer, Executor executor, Supplier supplier, int intValue) {
      this.clientState95 = clientState95;
      this.valueArray = valueArray;
      this.consumer = consumer;
      this.executor = executor;
      this.supplier = supplier;
      this.intValue = intValue;
   }

   static {
      Class<Function67> var10000 = Function67.class;
      int var0 = -580309048;
   }

   @Override
   public Object apply(Object object) {
      return ClientUtils173.resolveCompletionStage(this.clientState95, this.valueArray, this.consumer, this.executor, this.supplier, this.intValue, (Void)object);
   }

   public static Function67 resolveFunction67(ClientState95 var0, Object[] var1, Consumer var2, Executor var3, Supplier var4, int index) {
      return new Function67(var0, var1, var2, var3, var4, index);
   }
}
