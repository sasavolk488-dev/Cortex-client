package callbacks;

import java.util.function.Function;
import model.ClientState484;

public class Function59 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState484)object).getText();
   }

   public static Function59 getFunction59() {
      return new Function59();
   }
}
