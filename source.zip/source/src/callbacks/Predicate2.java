package callbacks;

import java.lang.reflect.Field;
import java.util.function.Predicate;
import model.ScreenState1;

public class Predicate2 implements Predicate {
   static {
      Class<Predicate2> var10000 = Predicate2.class;
      int var0 = -1196028408;
   }

   @Override
   public boolean test(Object object) {
      return ScreenState1.testField((Field)object);
   }

   public static Predicate2 getPredicate2() {
      return new Predicate2();
   }
}
