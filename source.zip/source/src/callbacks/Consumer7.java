package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.ESP;

public class Consumer7 implements Consumer {
   @Override
   public void accept(Object object) {
      ESP.handleEnumMap((EnumMap)object);
   }

   public static Consumer7 getConsumer7() {
      return new Consumer7();
   }
}
