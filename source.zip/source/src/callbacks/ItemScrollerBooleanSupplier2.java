package callbacks;

import java.util.function.BooleanSupplier;
import modules.ItemScroller;

public class ItemScrollerBooleanSupplier2 implements BooleanSupplier {
   public ItemScroller itemScroller;

   public ItemScrollerBooleanSupplier2(ItemScroller itemScroller) {
      this.itemScroller = itemScroller;
   }

   @Override
   public boolean getAsBoolean() {
      return this.itemScroller.testState();
   }

   public static ItemScrollerBooleanSupplier2 resolveItemScrollerBooleanSupplier2(ItemScroller var0) {
      return new ItemScrollerBooleanSupplier2(var0);
   }
}
