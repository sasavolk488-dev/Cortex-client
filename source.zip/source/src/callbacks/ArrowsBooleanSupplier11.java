package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier11 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier11(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState6();
   }

   public static ArrowsBooleanSupplier11 resolveArrowsBooleanSupplier11(Arrows var0) {
      return new ArrowsBooleanSupplier11(var0);
   }
}
