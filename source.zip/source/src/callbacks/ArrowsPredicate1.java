package callbacks;

import java.util.function.Predicate;
import modules.Arrows;
import net.minecraft.entity.player.PlayerEntity;
import settings.EnumSetting;
import settings.options.OptionGroup146;


public final class ArrowsPredicate1 extends EnumSetting implements Predicate {
   public ArrowsPredicate1(Arrows arrows) {
      super("armorFilter", OptionGroup146.IGNORE);
      this.arrows = arrows;
   }

   public boolean test(PlayerEntity player) {
      return switch ((OptionGroup146)this.getValue()) {
         case IGNORE -> true;
         case ARMORED -> this.arrows.testPlayer(player);
         case UNARMORED -> !this.arrows.testPlayer(player);
         case BY_TYPE -> this.arrows.testPlayer2(player);
      };
   }

   public final Arrows arrows;

   @Override
   public boolean test(Object var1) {
      return this.test((PlayerEntity)var1);
   }
}
