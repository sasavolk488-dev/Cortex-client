package callbacks;

import client.Cortex;
import java.util.function.BiConsumer;

public class BiConsumer5 implements BiConsumer {
   public Cortex cortex;
   public Runnable runnable;

   public BiConsumer5(Cortex cortex, Runnable runnable) {
      this.cortex = cortex;
      this.runnable = runnable;
   }

   @Override
   public void accept(Object object, Object object2) {
      this.cortex.handleRunnable(this.runnable, (Void)object, (Throwable)object2);
   }

   public static BiConsumer5 resolveBiConsumer5(Cortex var0, Runnable var1) {
      return new BiConsumer5(var0, var1);
   }
}
