package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssistT;

public class AimAssistTBooleanSupplier5 implements BooleanSupplier {
   public AimAssistT aimAssistT;

   public AimAssistTBooleanSupplier5(AimAssistT aimAssistT) {
      this.aimAssistT = aimAssistT;
   }

   static {
      Class<AimAssistTBooleanSupplier5> var10000 = AimAssistTBooleanSupplier5.class;
      int var0 = 710655439;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssistT.testState4();
   }

   public static AimAssistTBooleanSupplier5 resolveAimAssistTBooleanSupplier5(AimAssistT var0) {
      return new AimAssistTBooleanSupplier5(var0);
   }
}
