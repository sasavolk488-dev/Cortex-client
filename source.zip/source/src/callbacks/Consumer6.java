package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.AimBot;

public class Consumer6 implements Consumer {
   @Override
   public void accept(Object object) {
      AimBot.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer6 getConsumer6() {
      return new Consumer6();
   }
}
