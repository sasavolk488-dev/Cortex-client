package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier12 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier12(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState10();
   }

   public static ArrowsBooleanSupplier12 resolveArrowsBooleanSupplier12(Arrows var0) {
      return new ArrowsBooleanSupplier12(var0);
   }
}
