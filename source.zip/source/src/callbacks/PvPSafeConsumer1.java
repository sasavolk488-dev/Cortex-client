package callbacks;

import java.util.function.Consumer;
import modules.PvPSafe;
import settings.EnumSetting;

public class PvPSafeConsumer1 implements Consumer {
   public PvPSafe pvPSafe;

   public PvPSafeConsumer1(PvPSafe pvPSafe) {
      this.pvPSafe = pvPSafe;
   }

   @Override
   public void accept(Object object) {
      this.pvPSafe.setText((EnumSetting)object);
   }

   public static PvPSafeConsumer1 resolvePvPSafeConsumer1(PvPSafe var0) {
      return new PvPSafeConsumer1(var0);
   }
}
