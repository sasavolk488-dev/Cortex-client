package callbacks;

import java.util.function.BooleanSupplier;
import modules.ServerHelper;

public class ServerHelperBooleanSupplier3 implements BooleanSupplier {
   public ServerHelper serverHelper;

   public ServerHelperBooleanSupplier3(ServerHelper serverHelper) {
      this.serverHelper = serverHelper;
   }

   @Override
   public boolean getAsBoolean() {
      return this.serverHelper.testState6();
   }

   public static ServerHelperBooleanSupplier3 resolveServerHelperBooleanSupplier3(ServerHelper var0) {
      return new ServerHelperBooleanSupplier3(var0);
   }
}
