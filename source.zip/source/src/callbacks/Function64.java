package callbacks;

import java.util.function.Function;
import model.ClientState448;

public class Function64 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState448)object).getByteArray();
   }

   public static Function64 getFunction64() {
      return new Function64();
   }
}
