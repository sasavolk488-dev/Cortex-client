package callbacks;

import model.ClientState137;
import model.NumericState167;

public class Runnable12 implements Runnable {
   public NumericState167 numericState167;

   public Runnable12(NumericState167 numericState167) {
      this.numericState167 = numericState167;
   }

   @Override
   public void run() {
      ClientState137.handleNumericState1672(this.numericState167);
   }

   public static Runnable12 resolveRunnable12(NumericState167 var0) {
      return new Runnable12(var0);
   }
}
