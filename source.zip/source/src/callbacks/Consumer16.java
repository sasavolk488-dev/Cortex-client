package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.AimAssist;

public class Consumer16 implements Consumer {
   @Override
   public void accept(Object object) {
      AimAssist.handleEnumMap((EnumMap)object);
   }

   public static Consumer16 getConsumer16() {
      return new Consumer16();
   }
}
