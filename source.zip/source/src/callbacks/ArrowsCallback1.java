package callbacks;

import java.util.Comparator;
import modules.Arrows;
import net.minecraft.entity.Entity;

public class ArrowsCallback1 implements Comparator {
   public Arrows arrows;

   public ArrowsCallback1(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public int compare(Object object, Object object2) {
      return this.arrows.calculateInt((Entity)object, (Entity)object2);
   }

   public static ArrowsCallback1 resolveArrowsCallback1(Arrows var0) {
      return new ArrowsCallback1(var0);
   }
}
