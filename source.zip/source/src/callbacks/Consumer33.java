package callbacks;

import java.util.function.Consumer;
import model.ClientState101;
import model.ClientState137;
import modules.AutoCaptcha;

public class Consumer33 implements Consumer {
   public ClientState101 clientState101;

   public Consumer33(ClientState101 clientState101) {
      this.clientState101 = clientState101;
   }

   static {
      Class<Consumer33> var10000 = Consumer33.class;
      int var0 = -76840409;
   }

   @Override
   public void accept(Object object) {
      ClientState137.handleClientState101(this.clientState101, (AutoCaptcha)object);
   }

   public static Consumer33 resolveConsumer33(ClientState101 var0) {
      return new Consumer33(var0);
   }
}
