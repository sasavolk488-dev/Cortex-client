package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.CropESP;

public class Consumer10 implements Consumer {
   static {
      Class<Consumer10> var10000 = Consumer10.class;
      int var0 = -1569714209;
   }

   @Override
   public void accept(Object object) {
      CropESP.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer10 getConsumer10() {
      return new Consumer10();
   }
}
