package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class BooleanSupplier24 implements BooleanSupplier {
   @Override
   public boolean getAsBoolean() {
      return AimAssist.testState4();
   }

   public static BooleanSupplier24 getBooleanSupplier24() {
      return new BooleanSupplier24();
   }
}
