package callbacks;

import java.util.function.Supplier;
import model.ClientState367;

public class Supplier12 implements Supplier {
   public ClientState367 clientState367;

   public Supplier12(ClientState367 clientState367) {
      this.clientState367 = clientState367;
   }

   @Override
   public Object get() {
      return this.clientState367.getText2();
   }

   public static Supplier12 resolveSupplier12(ClientState367 var0) {
      return new Supplier12(var0);
   }
}
