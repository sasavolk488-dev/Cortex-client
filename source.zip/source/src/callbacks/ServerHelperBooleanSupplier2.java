package callbacks;

import java.util.function.BooleanSupplier;
import modules.ServerHelper;

public class ServerHelperBooleanSupplier2 implements BooleanSupplier {
   public ServerHelper serverHelper;

   public ServerHelperBooleanSupplier2(ServerHelper serverHelper) {
      this.serverHelper = serverHelper;
   }

   @Override
   public boolean getAsBoolean() {
      return this.serverHelper.testState3();
   }

   public static ServerHelperBooleanSupplier2 resolveServerHelperBooleanSupplier2(ServerHelper var0) {
      return new ServerHelperBooleanSupplier2(var0);
   }
}
