package callbacks;

import java.lang.reflect.Field;
import java.util.function.Predicate;
import model.ScreenState1;

public class Predicate1 implements Predicate {
   static {
      Class<Predicate1> var10000 = Predicate1.class;
      int var0 = 1254037788;
   }

   @Override
   public boolean test(Object object) {
      return ScreenState1.testField2((Field)object);
   }

   public static Predicate1 getPredicate1() {
      return new Predicate1();
   }
}
