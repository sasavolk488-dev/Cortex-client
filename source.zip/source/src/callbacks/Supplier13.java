package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup54;

public class Supplier13 implements Supplier {
   public OptionGroup54 optionGroup54;

   public Supplier13(OptionGroup54 optionGroup54) {
      this.optionGroup54 = optionGroup54;
   }

   @Override
   public Object get() {
      return this.optionGroup54.getItemStack();
   }

   public static Supplier13 resolveSupplier13(OptionGroup54 var0) {
      return new Supplier13(var0);
   }
}
