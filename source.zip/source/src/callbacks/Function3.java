package callbacks;

import java.util.function.Function;
import model.NumericState184;

public class Function3 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState184)object).getIntValue();
   }

   public static Function3 getFunction3() {
      return new Function3();
   }
}
