package callbacks;

import java.util.function.Function;
import model.ClientState197;

public class Function26 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState197)object).text;
   }

   public static Function26 getFunction26() {
      return new Function26();
   }
}
