package callbacks;

import java.util.function.BooleanSupplier;
import model.ClientState478;

public class BooleanSupplier19 implements BooleanSupplier {
   public ClientState478 clientState478;

   public BooleanSupplier19(ClientState478 clientState478) {
      this.clientState478 = clientState478;
   }

   @Override
   public boolean getAsBoolean() {
      return this.clientState478.testState();
   }

   public static BooleanSupplier19 resolveBooleanSupplier19(ClientState478 var0) {
      return new BooleanSupplier19(var0);
   }
}
