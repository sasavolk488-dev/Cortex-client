package callbacks;

import java.util.function.Consumer;
import modules.StreamerMode;
import settings.StringSetting;

public class StreamerModeConsumer2 implements Consumer {
   public StreamerMode streamerMode;

   public StreamerModeConsumer2(StreamerMode streamerMode) {
      this.streamerMode = streamerMode;
   }

   @Override
   public void accept(Object object) {
      this.streamerMode.handleStringSetting2((StringSetting)object);
   }

   public static StreamerModeConsumer2 resolveStreamerModeConsumer2(StreamerMode var0) {
      return new StreamerModeConsumer2(var0);
   }
}
