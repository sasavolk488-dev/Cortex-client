package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.NoInteract;

public class Consumer5 implements Consumer {
   @Override
   public void accept(Object object) {
      NoInteract.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer5 getConsumer5() {
      return new Consumer5();
   }
}
