package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup87;

public class Supplier43 implements Supplier {
   public OptionGroup87 optionGroup87;

   public Supplier43(OptionGroup87 optionGroup87) {
      this.optionGroup87 = optionGroup87;
   }

   @Override
   public Object get() {
      return this.optionGroup87.getItemStack();
   }

   public static Supplier43 resolveSupplier43(OptionGroup87 var0) {
      return new Supplier43(var0);
   }
}
