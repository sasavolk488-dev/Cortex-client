package callbacks;

import clickgui.widgets.WidgetPart54;

public class Runnable8 implements Runnable {
   static {
      Class<Runnable8> var10000 = Runnable8.class;
      int var0 = 460155898;
   }

   @Override
   public void run() {
      WidgetPart54.updateState();
   }

   public static Runnable8 getRunnable8() {
      return new Runnable8();
   }
}
