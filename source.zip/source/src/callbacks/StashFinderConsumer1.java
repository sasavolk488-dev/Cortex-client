package callbacks;

import java.util.function.Consumer;
import modules.StashFinder;
import settings.Setting;

public class StashFinderConsumer1 implements Consumer {
   public StashFinder stashFinder;

   public StashFinderConsumer1(StashFinder stashFinder) {
      this.stashFinder = stashFinder;
   }

   static {
      Class<StashFinderConsumer1> var10000 = StashFinderConsumer1.class;
      int var0 = -846142567;
   }

   @Override
   public void accept(Object object) {
      this.stashFinder.handleSetting2((Setting)object);
   }

   public static StashFinderConsumer1 resolveStashFinderConsumer1(StashFinder var0) {
      return new StashFinderConsumer1(var0);
   }
}
