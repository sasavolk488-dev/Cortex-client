package callbacks;

import java.util.function.Function;
import model.ClientState439;

public class Function9 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState439)object).getByteArray();
   }

   public static Function9 getFunction9() {
      return new Function9();
   }
}
