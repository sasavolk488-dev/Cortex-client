package callbacks;

import java.util.function.Function;
import model.ClientState140;

public class Function10 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState140)object).getLongValue();
   }

   public static Function10 getFunction10() {
      return new Function10();
   }
}
