package callbacks;

import java.util.function.Consumer;
import modules.NoRender;
import settings.Setting;

public class NoRenderConsumer1 implements Consumer {
   public NoRender noRender;

   public NoRenderConsumer1(NoRender noRender) {
      this.noRender = noRender;
   }

   @Override
   public void accept(Object object) {
      this.noRender.handleSetting((Setting)object);
   }

   public static NoRenderConsumer1 resolveNoRenderConsumer1(NoRender var0) {
      return new NoRenderConsumer1(var0);
   }
}
