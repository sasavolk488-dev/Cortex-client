package callbacks;

import util.ClientUtils202;

public class Runnable7 implements Runnable {
   static {
      Class<Runnable7> var10000 = Runnable7.class;
      int var0 = 131322597;
   }

   @Override
   public void run() {
      ClientUtils202.updateState();
   }

   public static Runnable7 getRunnable7() {
      return new Runnable7();
   }
}
