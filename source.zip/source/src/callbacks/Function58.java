package callbacks;

import java.util.function.Function;
import model.ClientState380;

public class Function58 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState380)object).getText();
   }

   public static Function58 getFunction58() {
      return new Function58();
   }
}
