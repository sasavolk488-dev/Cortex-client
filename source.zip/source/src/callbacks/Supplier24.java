package callbacks;

import java.util.function.Supplier;
import model.ClientState323;

public class Supplier24 implements Supplier {
   public ClientState323 clientState323;

   public Supplier24(ClientState323 clientState323) {
      this.clientState323 = clientState323;
   }

   @Override
   public Object get() {
      return this.clientState323.testState();
   }

   public static Supplier24 resolveSupplier24(ClientState323 var0) {
      return new Supplier24(var0);
   }
}
