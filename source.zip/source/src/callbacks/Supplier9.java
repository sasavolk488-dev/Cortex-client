package callbacks;

import java.util.function.Supplier;
import util.ClientUtils173;

public class Supplier9 implements Supplier {
   public Class classValue;
   public byte[] byteArray;
   public String text;

   public Supplier9(Class classValue, byte[] byteArray, String text) {
      this.classValue = classValue;
      this.byteArray = byteArray;
      this.text = text;
   }

   @Override
   public Object get() {
      return ClientUtils173.resolveValue(this.classValue, this.byteArray, this.text);
   }

   public static Supplier9 resolveSupplier9(Class type, byte[] var1, String text) {
      return new Supplier9(type, var1, text);
   }
}
