package callbacks;

import java.util.function.Function;
import model.ClientState472;

public class Function4 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState472)object).getJson();
   }

   public static Function4 getFunction4() {
      return new Function4();
   }
}
