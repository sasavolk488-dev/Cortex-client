package callbacks;

import java.util.function.BooleanSupplier;
import modules.MaceHelperOld;

public class MaceHelperOldBooleanSupplier1 implements BooleanSupplier {
   public MaceHelperOld maceHelperOld;

   public MaceHelperOldBooleanSupplier1(MaceHelperOld maceHelperOld) {
      this.maceHelperOld = maceHelperOld;
   }

   static {
      Class<MaceHelperOldBooleanSupplier1> var10000 = MaceHelperOldBooleanSupplier1.class;
      int var0 = 720652667;
   }

   @Override
   public boolean getAsBoolean() {
      return this.maceHelperOld.testState5();
   }

   public static MaceHelperOldBooleanSupplier1 resolveMaceHelperOldBooleanSupplier1(MaceHelperOld var0) {
      return new MaceHelperOldBooleanSupplier1(var0);
   }
}
