package callbacks;

import model.PlayerState12;

public class Runnable3 implements Runnable {
   static {
      Class<Runnable3> var10000 = Runnable3.class;
      int var0 = -1002207512;
   }

   @Override
   public void run() {
      PlayerState12.updateState();
   }

   public static Runnable3 getRunnable3() {
      return new Runnable3();
   }
}
