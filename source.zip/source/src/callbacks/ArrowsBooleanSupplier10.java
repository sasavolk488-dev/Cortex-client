package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier10 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier10(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState2();
   }

   public static ArrowsBooleanSupplier10 resolveArrowsBooleanSupplier10(Arrows var0) {
      return new ArrowsBooleanSupplier10(var0);
   }
}
