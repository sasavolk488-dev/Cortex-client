package callbacks;

import java.util.function.Function;
import model.ClientState408;

public class Function57 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState408)object).getLocalDateTime();
   }

   public static Function57 getFunction57() {
      return new Function57();
   }
}
