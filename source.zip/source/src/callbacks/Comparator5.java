package callbacks;

import java.util.Comparator;
import model.ClientState263;
import util.ClientUtils49;

public class Comparator5 implements Comparator {
   static {
      Class<Comparator5> var10000 = Comparator5.class;
      int var0 = -1251418186;
   }

   @Override
   public int compare(Object object, Object object2) {
      return ClientUtils49.calculateInt((ClientState263)object, (ClientState263)object2);
   }

   public static Comparator5 getComparator5() {
      return new Comparator5();
   }
}
