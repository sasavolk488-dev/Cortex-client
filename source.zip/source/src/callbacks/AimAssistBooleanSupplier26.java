package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier26 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier26(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState10();
   }

   public static AimAssistBooleanSupplier26 resolveAimAssistBooleanSupplier26(AimAssist var0) {
      return new AimAssistBooleanSupplier26(var0);
   }
}
