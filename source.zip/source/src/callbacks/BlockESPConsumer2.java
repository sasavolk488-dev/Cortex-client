package callbacks;

import java.util.function.Consumer;
import modules.BlockESP;
import settings.Setting;

public class BlockESPConsumer2 implements Consumer {
   public BlockESP blockESP;

   public BlockESPConsumer2(BlockESP blockESP) {
      this.blockESP = blockESP;
   }

   @Override
   public void accept(Object object) {
      this.blockESP.handleSetting2((Setting)object);
   }

   public static BlockESPConsumer2 resolveBlockESPConsumer2(BlockESP var0) {
      return new BlockESPConsumer2(var0);
   }
}
