package callbacks;

import java.util.function.Function;
import model.ClientState167;

public class Function1 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState167)object).getByteArray();
   }

   public static Function1 getFunction1() {
      return new Function1();
   }
}
