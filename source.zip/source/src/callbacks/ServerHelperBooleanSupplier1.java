package callbacks;

import java.util.function.BooleanSupplier;
import modules.ServerHelper;

public class ServerHelperBooleanSupplier1 implements BooleanSupplier {
   public ServerHelper serverHelper;

   public ServerHelperBooleanSupplier1(ServerHelper serverHelper) {
      this.serverHelper = serverHelper;
   }

   @Override
   public boolean getAsBoolean() {
      return this.serverHelper.testState7();
   }

   public static ServerHelperBooleanSupplier1 resolveServerHelperBooleanSupplier1(ServerHelper var0) {
      return new ServerHelperBooleanSupplier1(var0);
   }
}
