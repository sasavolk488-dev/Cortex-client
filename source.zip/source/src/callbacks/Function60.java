package callbacks;

import java.util.function.Function;
import model.ClientState393;

public class Function60 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState393)object).getByteArray2();
   }

   public static Function60 getFunction60() {
      return new Function60();
   }
}
