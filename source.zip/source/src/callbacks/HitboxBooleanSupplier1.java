package callbacks;

import java.util.function.BooleanSupplier;
import modules.Hitbox;

public class HitboxBooleanSupplier1 implements BooleanSupplier {
   public Hitbox hitbox;

   public HitboxBooleanSupplier1(Hitbox hitbox) {
      this.hitbox = hitbox;
   }

   @Override
   public boolean getAsBoolean() {
      return this.hitbox.testState();
   }

   public static HitboxBooleanSupplier1 resolveHitboxBooleanSupplier1(Hitbox var0) {
      return new HitboxBooleanSupplier1(var0);
   }
}
