package callbacks;

import java.util.function.BooleanSupplier;
import modules.AutoExplosion;

public class AutoExplosionBooleanSupplier2 implements BooleanSupplier {
   public AutoExplosion autoExplosion;

   public AutoExplosionBooleanSupplier2(AutoExplosion autoExplosion) {
      this.autoExplosion = autoExplosion;
   }

   @Override
   public boolean getAsBoolean() {
      return this.autoExplosion.testState4();
   }

   public static AutoExplosionBooleanSupplier2 resolveAutoExplosionBooleanSupplier2(AutoExplosion var0) {
      return new AutoExplosionBooleanSupplier2(var0);
   }
}
