package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier8 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier8(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState7();
   }

   public static AimAssistBooleanSupplier8 resolveAimAssistBooleanSupplier8(AimAssist var0) {
      return new AimAssistBooleanSupplier8(var0);
   }
}
