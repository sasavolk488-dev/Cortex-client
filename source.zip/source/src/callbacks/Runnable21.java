package callbacks;

import model.ClientState137;
import model.NumericState12;

public class Runnable21 implements Runnable {
   public NumericState12 numericState12;

   public Runnable21(NumericState12 numericState12) {
      this.numericState12 = numericState12;
   }

   @Override
   public void run() {
      ClientState137.handleNumericState122(this.numericState12);
   }

   public static Runnable21 resolveRunnable21(NumericState12 var0) {
      return new Runnable21(var0);
   }
}
