package callbacks;

import java.util.function.Consumer;
import modules.AimAssist;
import settings.EnumSetting;

public class AimAssistConsumer1 implements Consumer {
   public AimAssist aimAssist;

   public AimAssistConsumer1(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public void accept(Object object) {
      this.aimAssist.handleEnumSetting((EnumSetting)object);
   }

   public static AimAssistConsumer1 resolveAimAssistConsumer1(AimAssist var0) {
      return new AimAssistConsumer1(var0);
   }
}
