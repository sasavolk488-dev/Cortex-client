package callbacks;

import clickgui.widgets.WidgetPart9;
import java.util.function.BooleanSupplier;

public class BooleanSupplier9 implements BooleanSupplier {
   @Override
   public boolean getAsBoolean() {
      return WidgetPart9.testState3();
   }

   public static BooleanSupplier9 getBooleanSupplier9() {
      return new BooleanSupplier9();
   }
}
