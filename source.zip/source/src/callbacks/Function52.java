package callbacks;

import java.util.function.Function;
import model.ClientState226;

public class Function52 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState226)object).getJson();
   }

   public static Function52 getFunction52() {
      return new Function52();
   }
}
