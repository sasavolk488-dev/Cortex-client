package callbacks;

import java.util.Comparator;
import model.ClientState124;
import model.ClientState323;

public class Comparator3 implements Comparator {
   @Override
   public int compare(Object object, Object object2) {
      return ClientState323.calculateInt2((ClientState124)object, (ClientState124)object2);
   }

   public static Comparator3 getComparator3() {
      return new Comparator3();
   }
}
