package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier6 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier6(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState10();
   }

   public static AimAssistBooleanSupplier6 resolveAimAssistBooleanSupplier6(AimAssist var0) {
      return new AimAssistBooleanSupplier6(var0);
   }
}
