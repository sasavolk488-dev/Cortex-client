package callbacks;

import java.util.function.Supplier;
import settings.options.OptionGroup132;

public class Supplier28 implements Supplier {
   public OptionGroup132 optionGroup132;

   public Supplier28(OptionGroup132 optionGroup132) {
      this.optionGroup132 = optionGroup132;
   }

   @Override
   public Object get() {
      return this.optionGroup132.getItemStack();
   }

   public static Supplier28 resolveSupplier28(OptionGroup132 var0) {
      return new Supplier28(var0);
   }
}
