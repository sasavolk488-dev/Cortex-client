package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier8 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier8(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState19();
   }

   public static ArrowsBooleanSupplier8 resolveArrowsBooleanSupplier8(Arrows var0) {
      return new ArrowsBooleanSupplier8(var0);
   }
}
