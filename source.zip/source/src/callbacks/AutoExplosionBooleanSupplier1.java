package callbacks;

import java.util.function.BooleanSupplier;
import modules.AutoExplosion;

public class AutoExplosionBooleanSupplier1 implements BooleanSupplier {
   public AutoExplosion autoExplosion;

   public AutoExplosionBooleanSupplier1(AutoExplosion autoExplosion) {
      this.autoExplosion = autoExplosion;
   }

   @Override
   public boolean getAsBoolean() {
      return this.autoExplosion.testState2();
   }

   public static AutoExplosionBooleanSupplier1 resolveAutoExplosionBooleanSupplier1(AutoExplosion var0) {
      return new AutoExplosionBooleanSupplier1(var0);
   }
}
