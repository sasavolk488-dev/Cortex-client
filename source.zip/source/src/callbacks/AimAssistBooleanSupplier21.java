package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier21 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier21(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier21 resolveAimAssistBooleanSupplier21(AimAssist var0) {
      return new AimAssistBooleanSupplier21(var0);
   }
}
