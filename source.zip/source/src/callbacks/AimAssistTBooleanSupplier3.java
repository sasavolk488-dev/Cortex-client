package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssistT;

public class AimAssistTBooleanSupplier3 implements BooleanSupplier {
   public AimAssistT aimAssistT;

   public AimAssistTBooleanSupplier3(AimAssistT aimAssistT) {
      this.aimAssistT = aimAssistT;
   }

   static {
      Class<AimAssistTBooleanSupplier3> var10000 = AimAssistTBooleanSupplier3.class;
      int var0 = -264574246;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssistT.testState5();
   }

   public static AimAssistTBooleanSupplier3 resolveAimAssistTBooleanSupplier3(AimAssistT var0) {
      return new AimAssistTBooleanSupplier3(var0);
   }
}
