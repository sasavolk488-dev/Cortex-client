package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier29 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier29(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState10();
   }

   public static AimAssistBooleanSupplier29 resolveAimAssistBooleanSupplier29(AimAssist var0) {
      return new AimAssistBooleanSupplier29(var0);
   }
}
