package callbacks;

import java.util.function.Function;
import model.ClientState484;

public class Function66 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState484)object).getByteArray();
   }

   public static Function66 getFunction66() {
      return new Function66();
   }
}
