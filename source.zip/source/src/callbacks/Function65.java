package callbacks;

import java.util.function.Function;
import model.ClientState448;

public class Function65 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState448)object).isBooleanValue();
   }

   public static Function65 getFunction65() {
      return new Function65();
   }
}
