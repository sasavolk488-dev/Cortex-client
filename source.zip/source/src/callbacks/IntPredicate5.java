package callbacks;

import java.util.function.IntPredicate;
import modules.StreamerMode;

public class IntPredicate5 implements IntPredicate {
   @Override
   public boolean test(int index) {
      return StreamerMode.testInt3(index);
   }

   public static IntPredicate5 getIntPredicate5() {
      return new IntPredicate5();
   }
}
