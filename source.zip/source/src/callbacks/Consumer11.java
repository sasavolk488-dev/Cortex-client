package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.NoRender;

public class Consumer11 implements Consumer {
   @Override
   public void accept(Object object) {
      NoRender.handleEnumMap2((EnumMap)object);
   }

   public static Consumer11 getConsumer11() {
      return new Consumer11();
   }
}
