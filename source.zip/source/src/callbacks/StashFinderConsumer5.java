package callbacks;

import java.util.function.Consumer;
import modules.StashFinder;
import settings.Setting;

public class StashFinderConsumer5 implements Consumer {
   public StashFinder stashFinder;

   public StashFinderConsumer5(StashFinder stashFinder) {
      this.stashFinder = stashFinder;
   }

   static {
      Class<StashFinderConsumer5> var10000 = StashFinderConsumer5.class;
      int var0 = -1065396081;
   }

   @Override
   public void accept(Object object) {
      this.stashFinder.handleSetting4((Setting)object);
   }

   public static StashFinderConsumer5 resolveStashFinderConsumer5(StashFinder var0) {
      return new StashFinderConsumer5(var0);
   }
}
