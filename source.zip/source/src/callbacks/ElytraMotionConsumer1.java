package callbacks;

import java.util.function.Consumer;
import modules.ElytraMotion;
import settings.BooleanSetting;

public class ElytraMotionConsumer1 implements Consumer {
   public ElytraMotion elytraMotion;

   public ElytraMotionConsumer1(ElytraMotion elytraMotion) {
      this.elytraMotion = elytraMotion;
   }

   @Override
   public void accept(Object object) {
      this.elytraMotion.handleBooleanSetting((BooleanSetting)object);
   }

   public static ElytraMotionConsumer1 resolveElytraMotionConsumer1(ElytraMotion var0) {
      return new ElytraMotionConsumer1(var0);
   }
}
