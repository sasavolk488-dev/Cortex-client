package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.LockSlot;

public class Consumer15 implements Consumer {
   @Override
   public void accept(Object object) {
      LockSlot.handleEnumMap((EnumMap)object);
   }

   public static Consumer15 getConsumer15() {
      return new Consumer15();
   }
}
