package callbacks;

import java.util.function.Function;
import model.ClientState472;

public class Function25 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState472)object).getLongValue();
   }

   public static Function25 getFunction25() {
      return new Function25();
   }
}
