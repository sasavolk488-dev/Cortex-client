package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimBot;

public class AimBotBooleanSupplier1 implements BooleanSupplier {
   public AimBot aimBot;

   public AimBotBooleanSupplier1(AimBot aimBot) {
      this.aimBot = aimBot;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimBot.testState4();
   }

   public static AimBotBooleanSupplier1 resolveAimBotBooleanSupplier1(AimBot var0) {
      return new AimBotBooleanSupplier1(var0);
   }
}
