package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier2 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier2(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState6();
   }

   public static AimAssistBooleanSupplier2 resolveAimAssistBooleanSupplier2(AimAssist var0) {
      return new AimAssistBooleanSupplier2(var0);
   }
}
