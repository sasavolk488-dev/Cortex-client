package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier11 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier11(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   static {
      Class<BooleanSupplier11> var10000 = BooleanSupplier11.class;
      int var0 = 824001356;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier11 resolveBooleanSupplier11(BooleanSetting setting) {
      return new BooleanSupplier11(setting);
   }
}
