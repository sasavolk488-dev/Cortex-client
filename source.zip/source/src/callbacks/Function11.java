package callbacks;

import java.util.function.Function;
import model.ClientState140;

public class Function11 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState140)object).getIntValue();
   }

   public static Function11 getFunction11() {
      return new Function11();
   }
}
