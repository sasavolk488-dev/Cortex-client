package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier17 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier17(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState3();
   }

   public static AimAssistBooleanSupplier17 resolveAimAssistBooleanSupplier17(AimAssist var0) {
      return new AimAssistBooleanSupplier17(var0);
   }
}
