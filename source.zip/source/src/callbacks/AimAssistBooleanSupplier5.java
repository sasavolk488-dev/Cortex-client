package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier5 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier5(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState5();
   }

   public static AimAssistBooleanSupplier5 resolveAimAssistBooleanSupplier5(AimAssist var0) {
      return new AimAssistBooleanSupplier5(var0);
   }
}
