package callbacks;

import java.util.function.BooleanSupplier;
import modules.ESP;

public class ESPBooleanSupplier3 implements BooleanSupplier {
   public ESP eSP;

   public ESPBooleanSupplier3(ESP eSP) {
      this.eSP = eSP;
   }

   @Override
   public boolean getAsBoolean() {
      return this.eSP.testState4();
   }

   public static ESPBooleanSupplier3 resolveESPBooleanSupplier3(ESP var0) {
      return new ESPBooleanSupplier3(var0);
   }
}
