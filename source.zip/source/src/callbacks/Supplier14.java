package callbacks;

import java.util.List;
import java.util.function.Supplier;
import model.ClientState95;
import util.ClientUtils173;

public class Supplier14 implements Supplier {
   public byte[][] byteArrayArray;
   public int intValue;
   public List list;
   public ClientState95 clientState95;

   public Supplier14(byte[][] byteArrayArray, int intValue, List list, ClientState95 clientState95) {
      this.byteArrayArray = byteArrayArray;
      this.intValue = intValue;
      this.list = list;
      this.clientState95 = clientState95;
   }

   @Override
   public Object get() {
      return ClientUtils173.resolveBoolean(this.byteArrayArray, this.intValue, this.list, this.clientState95);
   }

   public static Supplier14 resolveSupplier14(byte[][] var0, int index, List values, ClientState95 var3) {
      return new Supplier14(var0, index, values, var3);
   }
}
