package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier7 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier7(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState11();
   }

   public static ArrowsBooleanSupplier7 resolveArrowsBooleanSupplier7(Arrows var0) {
      return new ArrowsBooleanSupplier7(var0);
   }
}
