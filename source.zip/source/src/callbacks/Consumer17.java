package callbacks;

import client.Cortex;
import java.util.function.Consumer;
import model.ClientState326;

public class Consumer17 implements Consumer {
   public Cortex cortex;

   public Consumer17(Cortex cortex) {
      this.cortex = cortex;
   }

   static {
      Class<Consumer17> var10000 = Consumer17.class;
      int var0 = 613753347;
   }

   @Override
   public void accept(Object object) {
      this.cortex.handleClientState326((ClientState326)object);
   }

   public static Consumer17 resolveConsumer17(Cortex var0) {
      return new Consumer17(var0);
   }
}
