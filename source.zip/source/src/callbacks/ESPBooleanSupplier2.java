package callbacks;

import java.util.function.BooleanSupplier;
import modules.ESP;

public class ESPBooleanSupplier2 implements BooleanSupplier {
   public ESP eSP;

   public ESPBooleanSupplier2(ESP eSP) {
      this.eSP = eSP;
   }

   @Override
   public boolean getAsBoolean() {
      return this.eSP.testState2();
   }

   public static ESPBooleanSupplier2 resolveESPBooleanSupplier2(ESP var0) {
      return new ESPBooleanSupplier2(var0);
   }
}
