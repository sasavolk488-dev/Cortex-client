package callbacks;

import model.ClientState137;
import model.ClientState464;

public class Runnable24 implements Runnable {
   public ClientState464 clientState464;

   public Runnable24(ClientState464 clientState464) {
      this.clientState464 = clientState464;
   }

   static {
      Class<Runnable24> var10000 = Runnable24.class;
      int var0 = 1839775195;
   }

   @Override
   public void run() {
      ClientState137.handleClientState4642(this.clientState464);
   }

   public static Runnable24 resolveRunnable24(ClientState464 var0) {
      return new Runnable24(var0);
   }
}
