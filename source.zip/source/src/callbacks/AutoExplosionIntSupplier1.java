package callbacks;

import client.MinecraftAccess;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import modules.AutoExplosion;
import net.minecraft.entity.Entity;


public class AutoExplosionIntSupplier1 implements IntSupplier {
   public int intValue;
   public Entity entity;

   public AutoExplosionIntSupplier1(AutoExplosion autoExplosion, Supplier supplier, double doubleValue) {
      this.autoExplosion = autoExplosion;
      this.supplier = supplier;
      this.doubleValue = doubleValue;
      this.intValue = -1;
   }

   static {
      Class<AutoExplosionIntSupplier1> var10000 = AutoExplosionIntSupplier1.class;
      boolean var2 = false;
      boolean var10001 = false;
      boolean var10002 = false;
      long var0 = 0L;
      var10000 = AutoExplosionIntSupplier1.class;
      long var6 = 8444859220798736L;
      var10000 = null;
      int var5 = -1395130784;
   }

   @Override
   public int getAsInt() {
      Entity entity = (Entity)this.supplier.get();
      if (entity == null) {
         return 3;
      }

      if (this.intValue < 0 || this.entity != entity) {
         this.entity = entity;
         this.intValue = this.autoExplosion.calculateInt(MinecraftAccess.mc.player.getMainHandStack(), entity, this.doubleValue);
      }

      return this.intValue;
   }

   public final Supplier supplier;

   public final double doubleValue;

   public final AutoExplosion autoExplosion;
}
