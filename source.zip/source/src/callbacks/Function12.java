package callbacks;

import java.util.function.Function;
import model.ClientState119;

public class Function12 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState119)object).getByteArray4();
   }

   public static Function12 getFunction12() {
      return new Function12();
   }
}
