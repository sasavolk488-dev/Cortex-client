package callbacks;

import java.util.function.Function;
import model.NumericState12;

public class Function56 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState12)object).getLongValue();
   }

   public static Function56 getFunction56() {
      return new Function56();
   }
}
