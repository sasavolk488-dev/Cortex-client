package callbacks;

import java.util.function.Function;
import model.NumericState94;

public class Function75 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState94)object).getIntValue();
   }

   public static Function75 getFunction75() {
      return new Function75();
   }
}
