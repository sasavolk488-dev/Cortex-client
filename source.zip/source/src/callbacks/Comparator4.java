package callbacks;

import java.util.Comparator;
import model.BoundsState11;
import util.ClientUtils338;

public class Comparator4 implements Comparator {
   static {
      Class<Comparator4> var10000 = Comparator4.class;
      int var0 = 82336477;
   }

   @Override
   public int compare(Object object, Object object2) {
      return ClientUtils338.calculateInt((BoundsState11)object, (BoundsState11)object2);
   }

   public static Comparator4 getComparator4() {
      return new Comparator4();
   }
}
