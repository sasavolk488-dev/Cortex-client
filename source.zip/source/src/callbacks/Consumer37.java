package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.XrayBypass;

public class Consumer37 implements Consumer {
   @Override
   public void accept(Object object) {
      XrayBypass.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer37 getConsumer37() {
      return new Consumer37();
   }
}
