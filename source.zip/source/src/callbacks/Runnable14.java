package callbacks;

import model.ClientState137;

public class Runnable14 implements Runnable {
   public String text;

   public Runnable14(String text) {
      this.text = text;
   }

   static {
      Class<Runnable14> var10000 = Runnable14.class;
      int var0 = 310112446;
   }

   @Override
   public void run() {
      ClientState137.handleText(this.text);
   }

   public static Runnable14 resolveRunnable14(String text) {
      return new Runnable14(text);
   }
}
