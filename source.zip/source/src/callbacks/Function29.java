package callbacks;

import java.util.function.Function;
import model.ClientState140;

public class Function29 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState140)object).getJson();
   }

   public static Function29 getFunction29() {
      return new Function29();
   }
}
