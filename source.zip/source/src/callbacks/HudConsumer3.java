package callbacks;

import java.util.function.Consumer;
import modules.Hud;
import settings.Setting;

public class HudConsumer3 implements Consumer {
   public Hud hud;

   public HudConsumer3(Hud hud) {
      this.hud = hud;
   }

   @Override
   public void accept(Object object) {
      this.hud.handleSetting5((Setting)object);
   }

   public static HudConsumer3 resolveHudConsumer3(Hud var0) {
      return new HudConsumer3(var0);
   }
}
