package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier11 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier11(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState10();
   }

   public static AimAssistBooleanSupplier11 resolveAimAssistBooleanSupplier11(AimAssist var0) {
      return new AimAssistBooleanSupplier11(var0);
   }
}
