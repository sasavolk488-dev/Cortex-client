package callbacks;

import java.util.function.Consumer;
import modules.AirStuck;
import settings.BooleanSetting;

public class AirStuckConsumer2 implements Consumer {
   public AirStuck airStuck;

   public AirStuckConsumer2(AirStuck airStuck) {
      this.airStuck = airStuck;
   }

   @Override
   public void accept(Object object) {
      this.airStuck.handleBooleanSetting((BooleanSetting)object);
   }

   public static AirStuckConsumer2 resolveAirStuckConsumer2(AirStuck var0) {
      return new AirStuckConsumer2(var0);
   }
}
