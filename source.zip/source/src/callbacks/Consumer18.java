package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.AutoExplosion;

public class Consumer18 implements Consumer {
   @Override
   public void accept(Object object) {
      AutoExplosion.handleEnumMap((EnumMap)object);
   }

   public static Consumer18 getConsumer18() {
      return new Consumer18();
   }
}
