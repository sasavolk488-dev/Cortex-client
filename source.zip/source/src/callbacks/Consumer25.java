package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.DebugModule;

public class Consumer25 implements Consumer {
   static {
      Class<Consumer25> var10000 = Consumer25.class;
      int var0 = 668742081;
   }

   @Override
   public void accept(Object object) {
      DebugModule.handleEnumMap((EnumMap)object);
   }

   public static Consumer25 getConsumer25() {
      return new Consumer25();
   }
}
