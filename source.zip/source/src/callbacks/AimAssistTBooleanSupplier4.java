package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssistT;

public class AimAssistTBooleanSupplier4 implements BooleanSupplier {
   public AimAssistT aimAssistT;

   public AimAssistTBooleanSupplier4(AimAssistT aimAssistT) {
      this.aimAssistT = aimAssistT;
   }

   static {
      Class<AimAssistTBooleanSupplier4> var10000 = AimAssistTBooleanSupplier4.class;
      int var0 = 1078704431;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssistT.testState2();
   }

   public static AimAssistTBooleanSupplier4 resolveAimAssistTBooleanSupplier4(AimAssistT var0) {
      return new AimAssistTBooleanSupplier4(var0);
   }
}
