package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier15 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier15(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier15 resolveAimAssistBooleanSupplier15(AimAssist var0) {
      return new AimAssistBooleanSupplier15(var0);
   }
}
