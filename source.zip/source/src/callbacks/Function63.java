package callbacks;

import java.util.function.Function;
import model.NumericState32;

public class Function63 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState32)object).getIntValue2();
   }

   public static Function63 getFunction63() {
      return new Function63();
   }
}
