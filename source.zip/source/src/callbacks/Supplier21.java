package callbacks;

import java.util.function.Supplier;
import model.ClientState95;
import util.ClientUtils173;

public class Supplier21 implements Supplier {
   public byte[][] byteArrayArray;
   public int intValue;
   public ClientState95 clientState95;

   public Supplier21(byte[][] byteArrayArray, int intValue, ClientState95 clientState95) {
      this.byteArrayArray = byteArrayArray;
      this.intValue = intValue;
      this.clientState95 = clientState95;
   }

   static {
      Class<Supplier21> var10000 = Supplier21.class;
      int var0 = -53846876;
   }

   @Override
   public Object get() {
      return ClientUtils173.resolveByteArray(this.byteArrayArray, this.intValue, this.clientState95);
   }

   public static Supplier21 resolveSupplier21(byte[][] var0, int index, ClientState95 var2) {
      return new Supplier21(var0, index, var2);
   }
}
