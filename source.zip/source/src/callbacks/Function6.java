package callbacks;

import java.util.function.Function;
import model.NumericState167;

public class Function6 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState167)object).getLongValue();
   }

   public static Function6 getFunction6() {
      return new Function6();
   }
}
