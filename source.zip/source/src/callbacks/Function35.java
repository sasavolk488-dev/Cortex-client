package callbacks;

import java.util.function.Function;
import model.ClientState580;

public class Function35 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState580)object).getByteArray();
   }

   public static Function35 getFunction35() {
      return new Function35();
   }
}
