package callbacks;

import java.util.function.Function;
import model.ClientState66;

public class Function31 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState66)object).getByteArray();
   }

   public static Function31 getFunction31() {
      return new Function31();
   }
}
