package callbacks;

import java.util.function.BooleanSupplier;
import modules.TriggerBot;

public class TriggerBotBooleanSupplier2 implements BooleanSupplier {
   public TriggerBot triggerBot;

   public TriggerBotBooleanSupplier2(TriggerBot triggerBot) {
      this.triggerBot = triggerBot;
   }

   @Override
   public boolean getAsBoolean() {
      return this.triggerBot.testState2();
   }

   public static TriggerBotBooleanSupplier2 resolveTriggerBotBooleanSupplier2(TriggerBot var0) {
      return new TriggerBotBooleanSupplier2(var0);
   }
}
