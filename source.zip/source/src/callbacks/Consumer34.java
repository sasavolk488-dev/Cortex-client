package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.Freecam;

public class Consumer34 implements Consumer {
   @Override
   public void accept(Object object) {
      Freecam.handleEnumMap((EnumMap)object);
   }

   public static Consumer34 getConsumer34() {
      return new Consumer34();
   }
}
