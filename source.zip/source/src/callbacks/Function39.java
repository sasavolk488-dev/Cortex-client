package callbacks;

import java.util.function.Function;
import model.NumericState111;

public class Function39 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState111)object).getLongValue2();
   }

   public static Function39 getFunction39() {
      return new Function39();
   }
}
