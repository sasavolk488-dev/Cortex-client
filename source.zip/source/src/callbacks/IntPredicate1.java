package callbacks;

import java.util.function.IntPredicate;
import modules.StreamerMode;

public class IntPredicate1 implements IntPredicate {
   @Override
   public boolean test(int index) {
      return StreamerMode.testInt4(index);
   }

   public static IntPredicate1 getIntPredicate1() {
      return new IntPredicate1();
   }
}
