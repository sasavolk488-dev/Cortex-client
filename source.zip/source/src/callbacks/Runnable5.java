package callbacks;

import model.ClientState16;

public class Runnable5 implements Runnable {
   static {
      Class<Runnable5> var10000 = Runnable5.class;
      int var0 = 1858164121;
   }

   @Override
   public void run() {
      ClientState16.updateState2();
   }

   public static Runnable5 getRunnable5() {
      return new Runnable5();
   }
}
