package callbacks;

import java.util.function.BiConsumer;
import util.ClientUtils173;

public class BiConsumer1 implements BiConsumer {
   static {
      Class<BiConsumer1> var10000 = BiConsumer1.class;
      int var0 = 1880261912;
   }

   @Override
   public void accept(Object object, Object object2) {
      ClientUtils173.handleClass((Class)object, (byte[])object2);
   }

   public static BiConsumer1 getBiConsumer1() {
      return new BiConsumer1();
   }
}
