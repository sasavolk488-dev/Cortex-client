package callbacks;

import model.ClientState137;

public class Runnable16 implements Runnable {
   static {
      Class<Runnable16> var10000 = Runnable16.class;
      int var0 = 41186431;
   }

   @Override
   public void run() {
      ClientState137.updateState();
   }

   public static Runnable16 getRunnable16() {
      return new Runnable16();
   }
}
