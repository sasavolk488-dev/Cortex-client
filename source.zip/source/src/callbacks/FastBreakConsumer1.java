package callbacks;

import java.util.function.Consumer;
import modules.FastBreak;
import settings.Setting;

public class FastBreakConsumer1 implements Consumer {
   public FastBreak fastBreak;

   public FastBreakConsumer1(FastBreak fastBreak) {
      this.fastBreak = fastBreak;
   }

   @Override
   public void accept(Object object) {
      this.fastBreak.handleSetting((Setting)object);
   }

   public static FastBreakConsumer1 resolveFastBreakConsumer1(FastBreak var0) {
      return new FastBreakConsumer1(var0);
   }
}
