package callbacks;

import java.util.function.Function;
import model.ClientState185;

public class Function32 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState185)object).getByteArray();
   }

   public static Function32 getFunction32() {
      return new Function32();
   }
}
