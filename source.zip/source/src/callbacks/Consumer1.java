package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.TriggerBot;

public class Consumer1 implements Consumer {
   @Override
   public void accept(Object object) {
      TriggerBot.handleEnumMap((EnumMap)object);
   }

   public static Consumer1 getConsumer1() {
      return new Consumer1();
   }
}
