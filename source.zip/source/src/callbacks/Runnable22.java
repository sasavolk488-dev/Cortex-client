package callbacks;

import model.ClientState137;

public class Runnable22 implements Runnable {
   @Override
   public void run() {
      ClientState137.updateState7();
   }

   public static Runnable22 getRunnable22() {
      return new Runnable22();
   }
}
