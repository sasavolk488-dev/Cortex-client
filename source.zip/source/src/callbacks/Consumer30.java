package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.KillAura;

public class Consumer30 implements Consumer {
   @Override
   public void accept(Object object) {
      KillAura.handleEnumMap2((EnumMap)object);
   }

   public static Consumer30 getConsumer30() {
      return new Consumer30();
   }
}
