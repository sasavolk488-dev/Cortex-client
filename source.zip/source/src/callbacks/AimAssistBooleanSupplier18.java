package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier18 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier18(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState20();
   }

   public static AimAssistBooleanSupplier18 resolveAimAssistBooleanSupplier18(AimAssist var0) {
      return new AimAssistBooleanSupplier18(var0);
   }
}
