package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier14 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier14(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier14 resolveAimAssistBooleanSupplier14(AimAssist var0) {
      return new AimAssistBooleanSupplier14(var0);
   }
}
