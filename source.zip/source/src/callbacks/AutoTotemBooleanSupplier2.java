package callbacks;

import java.util.function.BooleanSupplier;
import modules.AutoTotem;

public class AutoTotemBooleanSupplier2 implements BooleanSupplier {
   public AutoTotem autoTotem;

   public AutoTotemBooleanSupplier2(AutoTotem autoTotem) {
      this.autoTotem = autoTotem;
   }

   @Override
   public boolean getAsBoolean() {
      return this.autoTotem.testState4();
   }

   public static AutoTotemBooleanSupplier2 resolveAutoTotemBooleanSupplier2(AutoTotem var0) {
      return new AutoTotemBooleanSupplier2(var0);
   }
}
