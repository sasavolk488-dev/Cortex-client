package callbacks;

import util.ClientUtils268;

public class Runnable9 implements Runnable {
   static {
      Class<Runnable9> var10000 = Runnable9.class;
      int var0 = -1481052183;
   }

   @Override
   public void run() {
      ClientUtils268.updateState();
   }

   public static Runnable9 getRunnable9() {
      return new Runnable9();
   }
}
