package callbacks;

import java.util.function.Consumer;
import modules.StreamerMode;
import settings.StringSetting;

public class StreamerModeConsumer5 implements Consumer {
   public StreamerMode streamerMode;

   public StreamerModeConsumer5(StreamerMode streamerMode) {
      this.streamerMode = streamerMode;
   }

   @Override
   public void accept(Object object) {
      this.streamerMode.handleStringSetting((StringSetting)object);
   }

   public static StreamerModeConsumer5 resolveStreamerModeConsumer5(StreamerMode var0) {
      return new StreamerModeConsumer5(var0);
   }
}
