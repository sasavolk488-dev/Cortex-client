package callbacks;

import java.util.function.BooleanSupplier;
import modules.ESP;

public class ESPBooleanSupplier1 implements BooleanSupplier {
   public ESP eSP;

   public ESPBooleanSupplier1(ESP eSP) {
      this.eSP = eSP;
   }

   @Override
   public boolean getAsBoolean() {
      return this.eSP.testState5();
   }

   public static ESPBooleanSupplier1 resolveESPBooleanSupplier1(ESP var0) {
      return new ESPBooleanSupplier1(var0);
   }
}
