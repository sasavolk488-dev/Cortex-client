package callbacks;

import java.util.function.BooleanSupplier;
import modules.XrayBypass;

public class XrayBypassBooleanSupplier1 implements BooleanSupplier {
   public XrayBypass xrayBypass;

   public XrayBypassBooleanSupplier1(XrayBypass xrayBypass) {
      this.xrayBypass = xrayBypass;
   }

   @Override
   public boolean getAsBoolean() {
      return this.xrayBypass.testState();
   }

   public static XrayBypassBooleanSupplier1 resolveXrayBypassBooleanSupplier1(XrayBypass var0) {
      return new XrayBypassBooleanSupplier1(var0);
   }
}
