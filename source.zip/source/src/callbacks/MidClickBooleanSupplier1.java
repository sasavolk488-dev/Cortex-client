package callbacks;

import java.util.function.BooleanSupplier;
import modules.MidClick;

public class MidClickBooleanSupplier1 implements BooleanSupplier {
   public MidClick midClick;

   public MidClickBooleanSupplier1(MidClick midClick) {
      this.midClick = midClick;
   }

   @Override
   public boolean getAsBoolean() {
      return this.midClick.testState4();
   }

   public static MidClickBooleanSupplier1 resolveMidClickBooleanSupplier1(MidClick var0) {
      return new MidClickBooleanSupplier1(var0);
   }
}
