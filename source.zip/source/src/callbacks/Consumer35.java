package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.Optimizer;

public class Consumer35 implements Consumer {
   @Override
   public void accept(Object object) {
      Optimizer.handleEnumMap((EnumMap)object);
   }

   public static Consumer35 getConsumer35() {
      return new Consumer35();
   }
}
