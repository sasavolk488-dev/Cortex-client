package callbacks;

import java.util.function.BooleanSupplier;
import modules.Arrows;

public class ArrowsBooleanSupplier15 implements BooleanSupplier {
   public Arrows arrows;

   public ArrowsBooleanSupplier15(Arrows arrows) {
      this.arrows = arrows;
   }

   @Override
   public boolean getAsBoolean() {
      return this.arrows.testState18();
   }

   public static ArrowsBooleanSupplier15 resolveArrowsBooleanSupplier15(Arrows var0) {
      return new ArrowsBooleanSupplier15(var0);
   }
}
