package callbacks;

import java.util.function.BooleanSupplier;
import modules.AutoExplosion;

public class AutoExplosionBooleanSupplier3 implements BooleanSupplier {
   public AutoExplosion autoExplosion;

   public AutoExplosionBooleanSupplier3(AutoExplosion autoExplosion) {
      this.autoExplosion = autoExplosion;
   }

   @Override
   public boolean getAsBoolean() {
      return this.autoExplosion.testState();
   }

   public static AutoExplosionBooleanSupplier3 resolveAutoExplosionBooleanSupplier3(AutoExplosion var0) {
      return new AutoExplosionBooleanSupplier3(var0);
   }
}
