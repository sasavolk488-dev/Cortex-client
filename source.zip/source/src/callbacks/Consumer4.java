package callbacks;

import java.util.LinkedHashMap;
import java.util.function.Consumer;
import modules.NoTrace;

public class Consumer4 implements Consumer {
   @Override
   public void accept(Object object) {
      NoTrace.handleLinkedHashMap((LinkedHashMap)object);
   }

   public static Consumer4 getConsumer4() {
      return new Consumer4();
   }
}
