package callbacks;

import java.util.function.LongSupplier;

public class LongSupplier1 implements LongSupplier {
   static {
      Class<LongSupplier1> var10000 = LongSupplier1.class;
      int var0 = -1689536666;
   }

   @Override
   public long getAsLong() {
      return System.currentTimeMillis();
   }

   public static LongSupplier1 getLongSupplier1() {
      return new LongSupplier1();
   }
}
