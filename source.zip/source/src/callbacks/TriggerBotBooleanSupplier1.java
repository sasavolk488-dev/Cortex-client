package callbacks;

import java.util.function.BooleanSupplier;
import modules.TriggerBot;

public class TriggerBotBooleanSupplier1 implements BooleanSupplier {
   public TriggerBot triggerBot;

   public TriggerBotBooleanSupplier1(TriggerBot triggerBot) {
      this.triggerBot = triggerBot;
   }

   @Override
   public boolean getAsBoolean() {
      return this.triggerBot.testState6();
   }

   public static TriggerBotBooleanSupplier1 resolveTriggerBotBooleanSupplier1(TriggerBot var0) {
      return new TriggerBotBooleanSupplier1(var0);
   }
}
