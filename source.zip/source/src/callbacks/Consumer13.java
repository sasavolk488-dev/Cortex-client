package callbacks;

import java.util.EnumMap;
import java.util.function.Consumer;
import modules.NoRender;

public class Consumer13 implements Consumer {
   @Override
   public void accept(Object object) {
      NoRender.handleEnumMap3((EnumMap)object);
   }

   public static Consumer13 getConsumer13() {
      return new Consumer13();
   }
}
