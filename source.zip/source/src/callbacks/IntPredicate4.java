package callbacks;

import java.util.function.IntPredicate;
import modules.StreamerMode;

public class IntPredicate4 implements IntPredicate {
   @Override
   public boolean test(int index) {
      return StreamerMode.testInt2(index);
   }

   public static IntPredicate4 getIntPredicate4() {
      return new IntPredicate4();
   }
}
