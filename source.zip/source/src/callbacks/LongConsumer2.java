package callbacks;

import java.util.function.LongConsumer;
import model.ClientState72;

public class LongConsumer2 implements LongConsumer {
   public ClientState72 clientState72;

   public LongConsumer2(ClientState72 clientState72) {
      this.clientState72 = clientState72;
   }

   @Override
   public void accept(long value) {
      this.clientState72.handleLong2(value);
   }

   public static LongConsumer2 resolveLongConsumer2(ClientState72 var0) {
      return new LongConsumer2(var0);
   }
}
