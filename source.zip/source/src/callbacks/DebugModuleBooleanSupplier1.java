package callbacks;

import java.util.function.BooleanSupplier;
import modules.DebugModule;

public class DebugModuleBooleanSupplier1 implements BooleanSupplier {
   public DebugModule debugModule;

   public DebugModuleBooleanSupplier1(DebugModule debugModule) {
      this.debugModule = debugModule;
   }

   static {
      Class<DebugModuleBooleanSupplier1> var10000 = DebugModuleBooleanSupplier1.class;
      int var0 = -526711563;
   }

   @Override
   public boolean getAsBoolean() {
      return this.debugModule.testState();
   }

   public static DebugModuleBooleanSupplier1 resolveDebugModuleBooleanSupplier1(DebugModule var0) {
      return new DebugModuleBooleanSupplier1(var0);
   }
}
