package callbacks;

import java.util.function.BiConsumer;
import util.ClientUtils70;

public class BiConsumer4 implements BiConsumer {
   @Override
   public void accept(Object object, Object object2) {
      ClientUtils70.handleLong((Long)object, (Long)object2);
   }

   public static BiConsumer4 getBiConsumer4() {
      return new BiConsumer4();
   }
}
