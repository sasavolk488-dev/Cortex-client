package callbacks;

import java.util.function.Consumer;
import modules.Freecam;
import settings.BooleanSetting;

public class FreecamConsumer2 implements Consumer {
   public Freecam freecam;

   public FreecamConsumer2(Freecam freecam) {
      this.freecam = freecam;
   }

   @Override
   public void accept(Object object) {
      this.freecam.handleBooleanSetting((BooleanSetting)object);
   }

   public static FreecamConsumer2 resolveFreecamConsumer2(Freecam var0) {
      return new FreecamConsumer2(var0);
   }
}
