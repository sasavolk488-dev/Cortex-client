package callbacks;

import java.util.function.Function;
import model.ClientState101;

public class Function42 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState101)object).getLongValue();
   }

   public static Function42 getFunction42() {
      return new Function42();
   }
}
