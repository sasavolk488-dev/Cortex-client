package callbacks;

import java.util.function.Function;
import model.ClientState185;

public class Function47 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState185)object).getLongValue();
   }

   public static Function47 getFunction47() {
      return new Function47();
   }
}
