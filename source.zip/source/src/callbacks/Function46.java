package callbacks;

import java.util.function.Function;
import model.ClientState439;

public class Function46 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState439)object).getText();
   }

   public static Function46 getFunction46() {
      return new Function46();
   }
}
