package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier13 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier13(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState();
   }

   public static AimAssistBooleanSupplier13 resolveAimAssistBooleanSupplier13(AimAssist var0) {
      return new AimAssistBooleanSupplier13(var0);
   }
}
