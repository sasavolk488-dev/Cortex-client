package callbacks;

import java.util.function.Function;
import model.ClientState484;

public class Function40 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState484)object).getByteArray2();
   }

   public static Function40 getFunction40() {
      return new Function40();
   }
}
