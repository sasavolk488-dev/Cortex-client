package callbacks;

import java.util.function.Function;
import model.ClientState106;

public class Function76 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState106)object).getText();
   }

   public static Function76 getFunction76() {
      return new Function76();
   }
}
