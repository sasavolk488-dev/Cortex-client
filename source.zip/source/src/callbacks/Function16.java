package callbacks;

import java.util.function.Function;
import model.ClientState179;

public class Function16 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState179)object).getIntValue();
   }

   public static Function16 getFunction16() {
      return new Function16();
   }
}
