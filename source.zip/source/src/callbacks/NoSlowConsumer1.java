package callbacks;

import java.util.function.Consumer;
import modules.NoSlow;
import settings.EnumSetting;

public class NoSlowConsumer1 implements Consumer {
   public NoSlow noSlow;

   public NoSlowConsumer1(NoSlow noSlow) {
      this.noSlow = noSlow;
   }

   @Override
   public void accept(Object object) {
      this.noSlow.handleEnumSetting((EnumSetting)object);
   }

   public static NoSlowConsumer1 resolveNoSlowConsumer1(NoSlow var0) {
      return new NoSlowConsumer1(var0);
   }
}
