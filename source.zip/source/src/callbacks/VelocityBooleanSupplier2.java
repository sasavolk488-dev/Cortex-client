package callbacks;

import java.util.function.BooleanSupplier;
import modules.Velocity;

public class VelocityBooleanSupplier2 implements BooleanSupplier {
   public Velocity velocity;

   public VelocityBooleanSupplier2(Velocity velocity) {
      this.velocity = velocity;
   }

   @Override
   public boolean getAsBoolean() {
      return this.velocity.testState();
   }

   public static VelocityBooleanSupplier2 resolveVelocityBooleanSupplier2(Velocity var0) {
      return new VelocityBooleanSupplier2(var0);
   }
}
