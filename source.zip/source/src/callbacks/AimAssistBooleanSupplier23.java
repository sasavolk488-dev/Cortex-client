package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier23 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier23(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier23 resolveAimAssistBooleanSupplier23(AimAssist var0) {
      return new AimAssistBooleanSupplier23(var0);
   }
}
