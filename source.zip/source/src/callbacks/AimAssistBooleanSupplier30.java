package callbacks;

import java.util.function.BooleanSupplier;
import modules.AimAssist;

public class AimAssistBooleanSupplier30 implements BooleanSupplier {
   public AimAssist aimAssist;

   public AimAssistBooleanSupplier30(AimAssist aimAssist) {
      this.aimAssist = aimAssist;
   }

   @Override
   public boolean getAsBoolean() {
      return this.aimAssist.testState14();
   }

   public static AimAssistBooleanSupplier30 resolveAimAssistBooleanSupplier30(AimAssist var0) {
      return new AimAssistBooleanSupplier30(var0);
   }
}
