package callbacks;

import java.util.function.Consumer;
import modules.Hud;
import settings.Setting;

public class HudConsumer4 implements Consumer {
   public Hud hud;

   public HudConsumer4(Hud hud) {
      this.hud = hud;
   }

   @Override
   public void accept(Object object) {
      this.hud.handleSetting4((Setting)object);
   }

   public static HudConsumer4 resolveHudConsumer4(Hud var0) {
      return new HudConsumer4(var0);
   }
}
