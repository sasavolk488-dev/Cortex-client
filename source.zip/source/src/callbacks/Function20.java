package callbacks;

import java.util.function.Function;
import model.ClientState9;
import net.minecraft.potion.Potion;

public class Function20 implements Function {
   @Override
   public Object apply(Object object) {
      return ClientState9.resolveItemStack((Potion)object);
   }

   public static Function20 getFunction20() {
      return new Function20();
   }
}
