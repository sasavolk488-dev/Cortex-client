package callbacks;

import java.util.function.Function;
import model.ClientState101;

public class Function24 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState101)object).getText();
   }

   public static Function24 getFunction24() {
      return new Function24();
   }
}
