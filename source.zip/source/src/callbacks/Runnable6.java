package callbacks;

import model.ClientState137;

public class Runnable6 implements Runnable {
   public String text;
   public byte[] byteArray;

   public Runnable6(String text, byte[] byteArray) {
      this.text = text;
      this.byteArray = byteArray;
   }

   @Override
   public void run() {
      ClientState137.handleText(this.text, this.byteArray);
   }

   public static Runnable6 resolveRunnable6(String text, byte[] var1) {
      return new Runnable6(text, var1);
   }
}
