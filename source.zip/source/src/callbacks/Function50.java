package callbacks;

import java.util.function.Function;
import model.NumericState188;

public class Function50 implements Function {
   @Override
   public Object apply(Object object) {
      return ((NumericState188)object).getLongValue2();
   }

   public static Function50 getFunction50() {
      return new Function50();
   }
}
