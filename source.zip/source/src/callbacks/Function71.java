package callbacks;

import java.util.function.Function;
import model.ClientState189;

public class Function71 implements Function {
   @Override
   public Object apply(Object object) {
      return ((ClientState189)object).getLongValue();
   }

   public static Function71 getFunction71() {
      return new Function71();
   }
}
