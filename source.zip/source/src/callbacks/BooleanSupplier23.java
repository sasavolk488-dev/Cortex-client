package callbacks;

import java.util.function.BooleanSupplier;
import settings.BooleanSetting;

public class BooleanSupplier23 implements BooleanSupplier {
   public BooleanSetting booleanSetting;

   public BooleanSupplier23(BooleanSetting booleanSetting) {
      this.booleanSetting = booleanSetting;
   }

   @Override
   public boolean getAsBoolean() {
      return (Boolean)this.booleanSetting.getValue();
   }

   public static BooleanSupplier23 resolveBooleanSupplier23(BooleanSetting setting) {
      return new BooleanSupplier23(setting);
   }
}
