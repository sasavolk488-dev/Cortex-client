package api;

import model.NumericState59;

public interface ClientContract73 {
   public NumericState59 resolveNumericState59(NumericState59 var1);
}
