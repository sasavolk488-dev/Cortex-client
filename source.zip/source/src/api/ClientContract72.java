package api;

public interface ClientContract72 extends ClientContract43, ClientContract27 {
   public void setText(String text);

   public void setShortValue(short var1);
}
