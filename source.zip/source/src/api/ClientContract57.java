package api;

public interface ClientContract57 {
   public Object resolveValue(Object object, Object object2, Object object3);
}
