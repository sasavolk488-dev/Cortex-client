package api;

import net.minecraft.item.ItemStack;

public interface ClientContract10 {
   public boolean testItemStack(ItemStack stack);
}
