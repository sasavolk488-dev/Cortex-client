package api;

public interface ClientContract22 extends AutoCloseable {
   public @Override
   void close();
}
