package api;

public interface ClientContract27 extends ClientContract67 {
   public String getText();

   public short getShort();
}
