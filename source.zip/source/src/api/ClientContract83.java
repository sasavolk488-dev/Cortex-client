package api;

import events.EventPriority;
import java.util.Optional;
import model.ClientState28;
import modules.Module;

public interface ClientContract83 {
   public Optional resolveOptional(ClientState28 var1, EventPriority var2, Module var3);
}
