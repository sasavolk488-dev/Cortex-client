package api;

import java.util.Collection;

public interface ClientContract7 {
   public void handleLong(long value, long value2, Collection values);
}
