package api;

import java.util.Set;
import model.NumericState39;

public interface ClientContract53 {
   public boolean testNumericState39(NumericState39 var1, Set values);
}
