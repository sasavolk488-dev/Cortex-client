package api;

import java.nio.file.Path;
import model.ClientState16;

public interface ClientContract16 {
   public ClientState16 resolveClientState16(Path var1, String text);
}
