package api;

import events.PacketEvent1;
import java.util.function.Predicate;
import model.ClientState110;
import model.ClientState293;
import model.ClientState333;
import model.ClientState475;
import model.ClientState59;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.SetPlayerInventoryS2CPacket;
import settings.options.OptionGroup183;

public interface ClientContract36 {
   public int INT_CONSTANT = 12;
   public int INT_CONSTANT2 = 20;

   public default boolean testState() {
      return false;
   }

   public static ClientContract36 getClientContract36() {
      return resolveClientContract36(20);
   }

   public static ClientContract36 resolveClientContract36(int index) {
      return new ClientState110(index);
   }

   public static ClientContract36 resolveClientContract36(Predicate<PacketEvent1> var0, int index, int index2) {
      return new ClientState333(var0, index, index2);
   }

   public default int getIntValue() {
      return 1;
   }

   public default int getIntValue2() {
      return 6;
   }

   public static ClientContract36 resolveClientContract36(int index, ClientContract36... var1) {
      return new ClientState293(index, var1);
   }

   public static ClientContract36 resolveClientContract36(ClientContract36... var0) {
      return resolveClientContract36(6, var0);
   }

   public static ClientContract36 resolveClientContract362(int index, ClientContract36... var1) {
      return new ClientState475(index, var1);
   }

   public static ClientContract36 resolveClientContract362(ClientContract36... var0) {
      return new ClientState475(0, var0);
   }

   public boolean testPacketEvent1(PacketEvent1 var1);

   public static ClientContract36 getVALUE1() {
      return OptionGroup183.VALUE_1;
   }

   public default boolean testPacketEvent12(PacketEvent1 var1) {
      return false;
   }

   public static ClientContract36 resolveClientContract36(Predicate<PacketEvent1> var0, int index) {
      return new ClientState59(var0, 1, index);
   }

   public static ClientContract36 resolveClientContract362(int index) {
      return new ClientState59(var0x -> true, 1, index);
   }

   public static ClientContract36 resolveClientContract36(Predicate<PacketEvent1> var0) {
      return resolveClientContract36(var0, 12);
   }

   public static ClientContract36 getClientContract362() {
      return resolveClientContract362(12);
   }

   public static ClientContract36 resolveClientContract362(Predicate<PacketEvent1> var0, int index, int index2) {
      return new ClientState59(var0, index, index2);
   }

   public default boolean isBooleanValue() {
      return false;
   }

   public static boolean testPacket2(Packet packet) {
      return packet instanceof InventoryS2CPacket || packet instanceof ScreenHandlerSlotUpdateS2CPacket || packet instanceof SetPlayerInventoryS2CPacket;
   }

   public static ClientContract36 resolveClientContract363(Predicate<Packet<?>> var0, int index, int index2) {
      Predicate<PacketEvent1> var3 = var0 == null ? var0x -> true : var1x -> var0.test(((events.PacketEvent1) (var1x)).getPacket());
      return new ClientState333(var3, index, index2);
   }
}
