package api;


public interface ClientContract65 extends ClientContract56 {
   public @Override
   default Object setValue2(Object object) {
      return this.resolveValue(object, true);
   }

   public Object resolveValue(Object object, boolean flag);

   public @Override
   default boolean is(Object var1) {
      throw new AbstractMethodError("Method あ/ヂウで.ヌウ(Ljava/lang/Object;)Z is abstract");
   }
}
