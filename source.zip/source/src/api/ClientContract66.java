package api;

public interface ClientContract66 extends AutoCloseable {
   public @Override
   void close();
}
