package api;

import clickgui.widgets.WidgetPart59;

public interface ClientContract45 {
   public boolean testWidgetPart59(WidgetPart59 var1);
}
