package api;

import java.io.IOException;
import model.ClientState469;

public interface ClientContract97 {
   public ClientState469 getClientState469() throws IOException;
}
