package api;

public interface ClientContract98 {
   public boolean testState();

   public int getIntValue22();
}
