package api;

import clickgui.widgets.ModuleWidget1;

public interface ClientContract8 {
   public boolean testModuleWidget1(ModuleWidget1 var1);

   public void handleModuleWidget1(ModuleWidget1 var1, float value, float value2);

   public void handleModuleWidget1(ModuleWidget1 var1);

   public float getFloat();

   public void handleModuleWidget12(ModuleWidget1 var1, float value, float value2);

   public void handleModuleWidget13(ModuleWidget1 var1, float value, float value2);

   public boolean testFloat(float value, float value2);
}
