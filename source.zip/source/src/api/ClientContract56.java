package api;

public interface ClientContract56 {
   public Object setValue2(Object object);

   public boolean is(Object object);
}
