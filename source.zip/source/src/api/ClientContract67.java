package api;

import java.util.Iterator;

public interface ClientContract67 {
   public Iterator getIterator();

   public String resolveText(String text);

   public byte[] getByteArray();

   public boolean testText(String text);
}
