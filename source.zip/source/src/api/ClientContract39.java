package api;

public interface ClientContract39 {
   public void handleClientContract46(ClientContract46 var1);
}
