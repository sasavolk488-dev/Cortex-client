package api;

import client.MinecraftAccess;
import model.NumericState116;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import settings.options.OptionGroup126;
import settings.options.OptionGroup51;
import util.MinecraftAccess131;

public interface ClientContract81 extends MinecraftAccess {
   public default boolean testState18() {
      return false;
   }

   public default boolean testState19() {
      return mc.player != null && mc.interactionManager != null && mc.player.currentScreenHandler == mc.player.playerScreenHandler;
   }

   public default boolean testState5() {
      return false;
   }

   public ClientContract36 getClientContract36();

   public default boolean testBoolean(boolean flag) {
      return flag;
   }

   public default boolean testState20() {
      return false;
   }

   public default String getText() {
      return this.getClass().getSimpleName();
   }

   public default boolean testState21() {
      return true;
   }

   public default boolean testState7() {
      return false;
   }

   public default void updateState3() {
   }

   public default boolean testState8() {
      return false;
   }

   public OptionGroup51 getVALUE1();

   public default boolean testState4() {
      return false;
   }

   public NumericState116 getNumericState116();

   public default void updateState() {
   }

   public default OptionGroup126 getType() {
      return OptionGroup126.VALUE_1;
   }

   public default void handleBoolean(boolean flag) {
   }

   public default boolean testState() {
      return false;
   }

   public default boolean testState9() {
      return false;
   }

   public boolean testState2();

   public default void updateState4() {
      if (mc.player != null && mc.player.networkHandler != null && mc.player.currentScreenHandler != mc.player.playerScreenHandler) {
         mc.player.networkHandler.sendPacket(new CloseHandledScreenC2SPacket(MinecraftAccess131.getSyncId(mc.player.currentScreenHandler)));
      }
   }

   public default boolean testClientConnection(ClientConnection var1, Packet packet) {
      return false;
   }

   public default boolean testState10() {
      return false;
   }
}
