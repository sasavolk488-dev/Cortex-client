package api;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public interface ClientContract30 {
   public boolean testPosition2(Vec3d position, Vec3d position2);

   public static ClientContract30 getClientContract30() {
      return (var0, var1) -> true;
   }

   public static ClientContract30 getClientContract302() {
      return (var0, var1) -> {
         MinecraftClient client = MinecraftClient.getInstance();
         return client.world != null && client.player != null
            ? client.world.raycast(new RaycastContext(var0, var1, ShapeType.OUTLINE, FluidHandling.NONE, client.player)).getType() == Type.MISS
            : false;
      };
   }
}
