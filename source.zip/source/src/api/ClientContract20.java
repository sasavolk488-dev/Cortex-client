package api;

public interface ClientContract20 extends AutoCloseable {
   public @Override
   void close();
}
