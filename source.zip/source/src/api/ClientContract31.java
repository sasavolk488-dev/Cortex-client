package api;

public interface ClientContract31 {
   public void handleFloat(float value, float value2, float value3, float value4, float value5, float value6, int index, int index2, float value7);
}
