package api;

import net.minecraft.item.ItemStack;

public interface ClientContract84 {
   public ItemStack getItemStack();

   public int getIntValue22();
}
