package api;

import model.NumericState202;
import model.NumericState5;
import util.ClientUtils226;

public interface ClientContract1 {
   public int INT_CONSTANT = 36;
   public int INT_CONSTANT2 = 40;
   public int INT_CONSTANT3 = 45;

   public static ClientUtils226 getClientUtils226() {
      return new ClientUtils226();
   }

   public static NumericState5 resolveNumericState5(int index) {
      return new NumericState5(index);
   }

   public int getInt();

   public static NumericState202 resolveNumericState202(int index) {
      return new NumericState202(index);
   }

   public int getInt2();
}
