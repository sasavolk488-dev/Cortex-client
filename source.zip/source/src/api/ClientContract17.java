package api;

public interface ClientContract17 {
   public Object resolveValue(Object object, Object object2, Object object3);
}
