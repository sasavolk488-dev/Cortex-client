package api;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.Collection;
import model.ClientState55;
import settings.options.OptionGroup149;

public interface ClientContract99 {
   public void handleInt(int index, String text);

   public void handleInt3(int index);

   public void updateState5();

   public void updateState6();

   public boolean testState();

   public boolean testState2();

   public void handleCollection(Collection values);

   public void handleClientContract28(ClientContract28 var1);

   public InetSocketAddress getInetSocketAddress();

   public boolean testState3();

   public ClientState55 getClientState55();

   public void handleInt2(int index, String text);

   public InetSocketAddress getInetSocketAddress2();

   public OptionGroup149 getOptionGroup149();

   public boolean testState4();

   public String getText();

   public void handleValue(Object object);

   public void handleByteArray(byte[] var1);

   public void handleByteBuffer(ByteBuffer var1);

   public boolean testState5();

   public Object getValue();
}
