package api;

public interface ClientContract87 {
   public Object resolveValue(Object object, Object object2, Object object3, Object object4);
}
