package api;

import java.util.function.Supplier;
import model.ClientState477;
import model.ClientState62;

public interface ClientContract71 {
   public Object resolveValue(ClientState62 var1);

   public default Object resolveValue(int index) {
      return this.resolveValue(ClientState62.resolveClientState62(index));
   }

   public default Object resolveValue(ClientState477 var1) {
      return this.resolveValue(ClientState62.resolveClientState62(var1));
   }

   public default Object resolveValue(Supplier var1) {
      return this.resolveValue(ClientState62.resolveClientState62(var1));
   }
}
