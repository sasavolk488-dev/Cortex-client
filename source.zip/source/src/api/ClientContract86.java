package api;

public interface ClientContract86 {
   public default boolean testState() {
      return true;
   }

   public float getFloat();

   public float getFloat2();
}
