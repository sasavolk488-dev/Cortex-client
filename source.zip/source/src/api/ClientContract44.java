package api;

public interface ClientContract44 {
   public Object getValue();
}
