package api;

import java.util.function.Function;
import model.ClientState17;
import model.ClientState193;
import model.ClientState215;
import model.ClientState308;
import model.ClientState445;
import model.ClientState481;
import model.ClientState598;
import model.ClientState8;
import util.ClientUtils356;

public interface ClientContract41 {
   public default ClientContract41 resolveClientContract41(Function var1, Function var2) {
      ClientContract41 var3 = this;
      return new ClientState445(this, var3, var2, var1);
   }

   public default void handleValue(Object object, Object object2) {
      this.handleClientState193(ClientState193.clientState193, object, object2);
   }

   public void handleClientState193(ClientState193 var1, Object object, Object object2);

   public static ClientState598 resolveClientState598(ClientContract57 var0) {
      return new ClientState598(var0);
   }

   public static ClientState308 resolveClientState308(ClientContract93 var0) {
      return new ClientState308(var0);
   }

   public static ClientState481 resolveClientState481(ClientContract42 var0) {
      return new ClientState481(var0);
   }

   public static ClientState17 resolveClientState17(ClientContract87 var0) {
      return new ClientState17(var0);
   }

   public static ClientState215 resolveClientState215(ClientContract77 var0) {
      return new ClientState215(var0);
   }

   public static ClientContract41 resolveClientContract41(ClientContract44 var0) {
      return ClientUtils356.resolveClientContract41(var0);
   }

   public static ClientState8 resolveClientState8(ClientContract33 var0) {
      return new ClientState8(var0);
   }

   public default Object resolveValue(Object object) {
      return this.resolveValue(ClientState193.clientState193, object);
   }

   public Object resolveValue(ClientState193 var1, Object object);
}
