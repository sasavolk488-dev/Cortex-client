package api;

import net.minecraft.item.ItemStack;

public interface ClientContract48 {
   public boolean testItemStack(ItemStack stack);
}
