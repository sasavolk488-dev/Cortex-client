package api;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import model.NumericState126;
import util.ClientUtils169;

public interface ClientContract52 {
   public void handleClientContract99(ClientContract99 var1, ClientContract28 var2);

   public void handleClientContract99(ClientContract99 var1, int index, String text, boolean flag);

   public void handleClientContract99(ClientContract99 var1, ClientContract62 var2, ClientContract27 var3) throws NumericState126;

   public void handleClientContract99(ClientContract99 var1, int index, String text);

   public void handleClientContract992(ClientContract99 var1, int index, String text, boolean flag);

   public void handleClientContract992(ClientContract99 var1, ClientContract28 var2);

   public void handleClientContract99(ClientContract99 var1);

   public void handleClientContract99(ClientContract99 var1, Exception var2);

   public InetSocketAddress resolveInetSocketAddress(ClientContract99 var1);

   public ClientUtils169 resolveClientUtils169(ClientContract99 var1);

   public void handleClientContract99(ClientContract99 var1, ClientContract67 var2);

   public void handleClientContract99(ClientContract99 var1, ByteBuffer var2);

   public default void handleClientContract99(ClientContract99 var1, long value, long value2) {
   }

   public void handleClientContract99(ClientContract99 var1, ClientContract62 var2) throws NumericState126;

   public InetSocketAddress resolveInetSocketAddress2(ClientContract99 var1);
}
