package api;

import java.io.IOException;

public interface ClientContract35 {
   public Integer getInteger() throws IOException;
}
