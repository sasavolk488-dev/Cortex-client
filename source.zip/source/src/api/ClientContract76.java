package api;

import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import model.ClientState483;
import settings.ChangeListenerSource;
import settings.JsonSerializable;

public interface ClientContract76 {
   public static ClientContract76 resolveClientContract76(String text, Supplier<JsonElement> var1, Consumer<JsonElement> var2, ChangeListenerSource... var3) {
      String text2 = resolveText(text);
      Objects.requireNonNull(var1, "serializer");
      Objects.requireNonNull(var2, "deserializer");
      List values = resolveList(var3);
      return new ClientState483(text2, var1, var2, values);
   }

   public static ClientContract76 resolveClientContract76(String text, JsonSerializable var1, ChangeListenerSource... var2) {
      Objects.requireNonNull(var1, "adaptor");
      return resolveClientContract76(text, var1::toJson, var1::deserialize, resolveChangeListenerSourceArray(var1, var2));
   }

   public static ClientContract76 resolveClientContract76(String text, JsonSerializable var1) {
      return resolveClientContract76(text, var1, resolveChangeListenerSourceArray(var1));
   }

   public static ClientContract76 resolveClientContract76(String text, Supplier<JsonElement> var1, Consumer<JsonElement> var2) {
      return resolveClientContract76(text, var1, var2, new ChangeListenerSource[0]);
   }

   public static ClientContract76 resolveClientContract762(String text, JsonSerializable var1) {
      return resolveClientContract762(text, var1, resolveChangeListenerSourceArray(var1));
   }

   public static ClientContract76 resolveClientContract762(String text, JsonSerializable var1, ChangeListenerSource... var2) {
      Objects.requireNonNull(var1, "adaptor");
      return resolveClientContract76(text, var1::toJson, var1x -> {
         if (var1x != null && ((com.google.gson.JsonElement) (var1x)).isJsonObject()) {
            var1.deserialize(((com.google.gson.JsonElement) (var1x)).getAsJsonObject());
         }
      }, resolveChangeListenerSourceArray(var1, var2));
   }

   public static List resolveList(ChangeListenerSource[] var0) {
      if (var0 != null && var0.length != 0) {
         IdentityHashMap var1 = new IdentityHashMap();
         ArrayList values = new ArrayList(var0.length);

         for (ChangeListenerSource var6 : var0) {
            if (var6 != null && var1.put(var6, Boolean.TRUE) == null) {
               values.add(var6);
            }
         }

         return List.copyOf(values);
      } else {
         return List.of();
      }
   }

   public String getText();

   public static ChangeListenerSource[] resolveChangeListenerSourceArray(Object object, ChangeListenerSource[] var1) {
      ArrayList values = new ArrayList();
      if (object instanceof ChangeListenerSource var3) {
         values.add(var3);
      }

      if (var1 != null) {
         for (ChangeListenerSource var6 : var1) {
            if (var6 != null) {
               values.add(var6);
            }
         }
      }

      return ((ChangeListenerSource[]) (((ChangeListenerSource[]) (values.toArray(ChangeListenerSource[]::new)))));
   }

   public default void handleRunnable(Runnable var1) {
   }

   public void handleJson(JsonElement element);

   public JsonElement getJson();

   public static ChangeListenerSource[] resolveChangeListenerSourceArray(Object object) {
      return object instanceof ChangeListenerSource var1 ? new ChangeListenerSource[]{var1} : new ChangeListenerSource[0];
   }

   public static String resolveText(String text) {
      if (text != null && !text.isBlank()) {
         return text.trim();
      } else {
         throw new IllegalArgumentException("E431");
      }
   }
}
