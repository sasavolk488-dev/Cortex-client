package api;

public interface ClientContract43 extends ClientContract67 {
   public void handleText(String text, String text2);

   public void handleByteArray(byte[] var1);
}
