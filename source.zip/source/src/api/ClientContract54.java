package api;

public interface ClientContract54 {
   public double calculateDouble(double value);

   public default double calculateDouble2(double value) {
      return this.calculateDouble(calculateDouble3(value));
   }

   private static double calculateDouble3(double value) {
      if (value <= 0.0) {
         return 0.0;
      } else {
         return value >= 1.0 ? 1.0 : value;
      }
   }
}
