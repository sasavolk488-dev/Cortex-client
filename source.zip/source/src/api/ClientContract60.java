package api;

import net.minecraft.item.ItemStack;
import util.ClientUtils113;
import util.ClientUtils263;

public interface ClientContract60 {
   public static ClientContract60 getClientContract60() {
      return new ClientUtils263();
   }

   public static ClientContract60 getClientContract602() {
      return new ClientUtils113();
   }

   public default boolean testState() {
      return true;
   }

   public static ClientContract60 getClientContract603() {
      return (var0, var1) -> var0 != null && var1 != null && !ItemStack.areEqual(var0, var1);
   }

   public static ClientContract60 getClientContract604() {
      return (var0, var1) -> {
         if (var0 != null && !var0.isEmpty() && var1 != null) {
            return var0.getCount() == 1 ? var1.isEmpty() : !var1.isEmpty() && var0.getItem() == var1.getItem() && var1.getCount() == var0.getCount() - 1;
         } else {
            return false;
         }
      };
   }

   public static ClientContract60 getClientContract605() {
      return (var0, var1) -> {
         if (var0 != null && !var0.isEmpty() && var1 != null) {
            return var0.getCount() == 1
               ? var1.isEmpty()
               : !var1.isEmpty() && ItemStack.areItemsAndComponentsEqual(var0, var1) && var1.getCount() == var0.getCount() - 1;
         } else {
            return false;
         }
      };
   }

   public boolean testItemStack(ItemStack stack, ItemStack stack2);
}
