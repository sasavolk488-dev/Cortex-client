package api;

import java.util.Objects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public interface ClientContract70 {
   public static ClientContract70 resolveClientContract70(Item item) {
      Objects.requireNonNull(item, "item");
      return var1 -> var1 != null && var1.isOf(item);
   }

   public boolean testItemStack2(ItemStack stack);

   public static ClientContract70 resolveClientContract70(ItemStack stack) {
      ItemStack stack2 = Objects.requireNonNull(stack, "expected").copy();
      return var1x -> var1x != null && ItemStack.areEqual(stack2, var1x);
   }

   public static ClientContract70 getClientContract70() {
      return var0 -> var0 != null;
   }

   public static ClientContract70 getClientContract702() {
      return var0 -> var0 != null && !var0.isEmpty();
   }
}
