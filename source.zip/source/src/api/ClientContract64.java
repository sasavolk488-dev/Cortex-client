package api;

import java.util.function.DoubleSupplier;
import model.ClientState128;
import model.ClientState612;
import model.NumericState199;
import net.minecraft.util.math.Vec3d;

public interface ClientContract64 {
   public ClientContract64 clientContract64 = new NumericState199(1);
   public ClientContract64 clientContract642 = new NumericState199(-1);

   public static ClientContract64 resolveClientContract64(DoubleSupplier var0, double value, double value2) {
      return new ClientState612(var0, value, value2);
   }

   public static ClientContract64 resolveClientContract64(DoubleSupplier var0) {
      return new ClientState612(var0);
   }

   public static ClientContract64 resolveClientContract642(DoubleSupplier var0) {
      return new ClientState128(() -> Math.toRadians(var0.getAsDouble()) - (Math.PI / 2));
   }

   public double getDoubleValue(Vec3d position, Vec3d position2, double value);

   public default boolean testPosition(Vec3d position, Vec3d position2, double value, Vec3d position3) {
      return false;
   }
}
