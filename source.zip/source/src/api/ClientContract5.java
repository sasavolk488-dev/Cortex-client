package api;

import events.ClientEvent31;
import settings.ConfigSection;

public interface ClientContract5 {
   public void handleConfigSection(ConfigSection var1, ClientEvent31 var2);

   public static ClientContract5 getClientContract5() {
      return (var0, var1) -> {};
   }
}
