package api;

public interface ClientContract46 {
   public void handleFloat(float value, float value2, float value3, float value4, float value5, float value6, int index);
}
