package api;

import net.minecraft.util.Hand;
import settings.options.OptionGroup51;

public interface ClientContract85 {
   public OptionGroup51 resolveOptionGroup51(Hand var1);
}
