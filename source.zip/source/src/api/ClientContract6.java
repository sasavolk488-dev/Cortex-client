package api;

import java.util.function.Supplier;
import model.ClientState477;
import model.ClientState62;

public interface ClientContract6 {
   public Object resolveWidgetPart3(ClientState62 var1, float value);

   public default Object resolveValue(int index, float value) {
      return this.resolveWidgetPart3(ClientState62.resolveClientState62(index), value);
   }

   public default Object resolveValue(ClientState477 var1, float value) {
      return this.resolveWidgetPart3(ClientState62.resolveClientState62(var1), value);
   }

   public default Object resolveValue(Supplier var1, float value) {
      return this.resolveWidgetPart3(ClientState62.resolveClientState62(var1), value);
   }
}
