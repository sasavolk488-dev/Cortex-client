package api;

import net.minecraft.entity.Entity;

public interface ClientContract47 {
   public boolean testEntity2(Entity entity);

   public boolean testEntity7(Entity entity);
}
