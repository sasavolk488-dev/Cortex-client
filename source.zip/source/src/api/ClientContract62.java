package api;

public interface ClientContract62 extends ClientContract67 {
   public String getText();
}
