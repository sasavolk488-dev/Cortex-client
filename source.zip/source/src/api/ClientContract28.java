package api;

import java.nio.ByteBuffer;
import settings.options.OptionGroup141;

public interface ClientContract28 {
   public ByteBuffer getByteBuffer();

   public boolean testState();

   public OptionGroup141 getOptionGroup141();

   public boolean testState2();

   public boolean testState3();

   public void handleClientContract28(ClientContract28 var1);

   public boolean testState4();

   public boolean testState5();
}
