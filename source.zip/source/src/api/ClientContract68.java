package api;

import java.util.Optional;

public interface ClientContract68 {
   public Optional getOptional();
}
