package api;

import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import settings.options.OptionGroup37;

public interface ClientContract96 {
   public default void handleHand(Hand var1, ItemStack stack) {
   }

   public OptionGroup37 resolveOptionGroup37(Hand var1, ItemStack stack);

   public static ClientContract96 getClientContract96() {
      return (var0, var1) -> OptionGroup37.VALUE_1;
   }
}
