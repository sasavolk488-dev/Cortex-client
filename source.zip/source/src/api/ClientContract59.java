package api;

public interface ClientContract59 {
   public int calculateInt(Object object);

   public Object resolveValue(Object object, int index);

   public void handleTextArray(Object object, int index, Object object2);
}
