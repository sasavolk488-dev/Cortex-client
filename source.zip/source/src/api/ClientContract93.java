package api;

public interface ClientContract93 {
   public Object resolveValue(Object object, Object object2);
}
