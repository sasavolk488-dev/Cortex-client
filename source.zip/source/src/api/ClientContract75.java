package api;

public interface ClientContract75 {
}
