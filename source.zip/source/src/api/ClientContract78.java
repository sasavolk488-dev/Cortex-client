package api;

public interface ClientContract78 {
   public ClientContract3 getClientState516();
}
