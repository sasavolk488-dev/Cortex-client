package api;

public interface ClientContract37 {
   public void updateState4() throws ClassNotFoundException;
}
