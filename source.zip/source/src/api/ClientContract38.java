package api;

import client.MinecraftAccess;
import client.RenderCallback;

public interface ClientContract38 extends MinecraftAccess, RenderCallback {
   public @Override
   default void shutdown() {
   }
}
