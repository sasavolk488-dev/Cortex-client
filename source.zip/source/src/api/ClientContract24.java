package api;

public interface ClientContract24 {
   public boolean testClientContract34(ClientContract34 var1, float value);
}
