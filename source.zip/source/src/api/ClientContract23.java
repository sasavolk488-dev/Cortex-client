package api;

public interface ClientContract23 {
   public Object resolveValue(int index);
}
