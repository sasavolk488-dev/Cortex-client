package api;

import events.ClientEvent10;
import model.ClientState108;
import model.PacketState2;
import java.util.UUID;


public interface ClientContract82 extends ClientContract89 {
   public void handleClientState108(ClientState108 var1);

   public PacketState2 getPacketState2();

   public default void handleClientEvent10(ClientEvent10 var1) {
   }

   public boolean testState3();

   public boolean testState4();

   public boolean testLong(long value);

   public @Override
   default boolean isBooleanValue3() {
      throw new AbstractMethodError("Method あ/ヘベびム.ざら()Z is abstract");
   }

   public @Override
   default UUID getUUID() {
      throw new AbstractMethodError("Method あ/ヘベびム.ペダム()Ljava/util/UUID; is abstract");
   }
}
