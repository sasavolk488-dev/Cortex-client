package api;

import net.minecraft.block.Block;

public interface ClientContract11 {
   public boolean testBlock(Block var1);
}
