package api;

import settings.options.OptionGroup164;
import settings.options.OptionGroup69;

public interface ClientContract3 {
   public OptionGroup164 getOptionGroup164();

   public ClientContract70 getClientContract70();

   public OptionGroup69 getOptionGroup69();

   public ClientContract1 getClientContract1();

   public ClientContract1 getClientContract12();
}
