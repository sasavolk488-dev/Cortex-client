package api;

public interface ClientContract13 {
   public Object resolveValue(Object object, Object object2);
}
