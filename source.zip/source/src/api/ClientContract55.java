package api;

public interface ClientContract55 {
}
