package api;

public interface ClientContract15 {
   public static void handleClientContract15(ClientContract15 var0, Object object) {
      if (var0 == null) {
         throw new IllegalArgumentException("E711");
      }

      if (object == null) {
         throw new IllegalArgumentException("E712");
      }

      var0.handleClientContract19(object);
   }

   public default void handleClientContract19(Object object) {
   }
}
