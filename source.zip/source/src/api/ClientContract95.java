package api;

public interface ClientContract95 {
   public static ClientContract95 getClientContract95() {
      return null;
   }

   public void updateState();

   public void handleClassArray(Class... var1);

   public void handleValue(Object object);
}
