package api;

public interface ClientContract42 {
   public Object resolveValue(Object object);
}
