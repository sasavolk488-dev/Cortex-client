package api;

import java.util.function.Predicate;

public interface ClientContract2 extends Predicate {
}
