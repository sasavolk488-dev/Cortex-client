package api;

import util.ClientUtils111;

public interface ClientContract21 {
   public ClientContract21 clientContract21 = new ClientUtils111();

   public float calculateFloat(String text);

   public float calculateFloat2(String text);
}
