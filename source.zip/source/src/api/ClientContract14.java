package api;

import com.google.gson.JsonObject;
import model.ClientState188;
import util.ClientUtils192;

public interface ClientContract14 {
   public ClientContract14 clientContract14 = new ClientUtils192();

   public default void handleInt(int index) {
   }

   public default void handleClientState188(ClientState188 var1, long value, JsonObject json) {
   }

   public default void handleInt2(int index) {
   }

   public default void handleLong(long value, JsonObject json) {
   }

   public default void handleInt(int index, int index2) {
   }

   public static ClientContract14 getClientContract14() {
      return clientContract14;
   }

   public default void handleInt3(int index) {
   }

   public default void handleText(String text, JsonObject json) {
   }
}
