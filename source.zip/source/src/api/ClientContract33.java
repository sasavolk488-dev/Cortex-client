package api;

public interface ClientContract33 {
   public Object resolveValue(Object object, Object object2, Object object3, Object object4, Object object5, Object object6);
}
