package api;

import model.NumericState126;

public interface ClientContract25 {
   public void handleClientContract28(ClientContract28 var1) throws NumericState126;

   public String getText();

   public void handleClientContract282(ClientContract28 var1) throws NumericState126;

   public boolean testText(String text);

   public boolean testText2(String text);

   public void handleClientContract283(ClientContract28 var1);

   public String getText2();

   public void updateState();

   public ClientContract25 getClientContract25();
}
