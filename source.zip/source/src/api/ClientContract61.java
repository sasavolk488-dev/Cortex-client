package api;

import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

public interface ClientContract61 {
   public Object resolveValue(Object object);

   public Object resolveValue(Identifier var1);

   public default Identifier resolveIdentifier2(Object object) {
      return null;
   }

   public Identifier resolveIdentifier(Object object);

   public ItemStack resolveItemStack(Object object);
}
