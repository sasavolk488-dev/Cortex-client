package api;

import input.MovementInputState;
import model.ClientState374;
import model.NumericState59;
import model.PositionState31;
import net.minecraft.util.math.Vec3d;
import util.ClientUtils105;
import util.ClientUtils65;

public interface ClientContract12 {
   public ClientContract12 clientContract12 = new ClientUtils105();
   public ClientContract12 clientContract122 = new ClientUtils65();

   public default ClientState374 resolveClientState374(PositionState31 var1) {
      return var1 == null
         ? ClientState374.getClientState374()
         : new ClientState374(
            this.resolveMovementInputState(var1.getMovementInputState(), var1.getNumericState59(), var1.getNumericState592(), var1.getPosition()),
            var1.isBooleanValue(),
            var1.isBooleanValue2(),
            var1.isBooleanValue3()
         );
   }

   public MovementInputState resolveMovementInputState(MovementInputState var1, NumericState59 var2, NumericState59 var3, Vec3d position);
}
