package api;

import java.awt.image.BufferedImage;

public interface ClientContract92 extends ClientContract79 {
   public BufferedImage getBufferedImage2();
}
