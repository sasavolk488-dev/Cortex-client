package api;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Stream;
import model.ClientState52;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Formatting;
import settings.options.OptionGroup132;
import settings.options.OptionGroup136;
import settings.options.OptionGroup54;
import settings.options.OptionGroup87;
import settings.options.ServerHelperServer;
import util.MinecraftAccess35;

public interface ClientContract4 {
   public default ItemStack getItemStack() {
      return this.getItemStack2();
   }

   public default int getInt() {
      int index = 0;

      for (ClientContract18 var3 : (java.lang.Iterable<ClientContract18>) (java.lang.Iterable<?>) (ClientState52.clientState525)) {
         ItemStack stack = var3.getItemStack();
         if (this.testItemStack2(stack)) {
            index += stack.getCount();
         }
      }

      return index;
   }

   public String getText();

   public static NbtCompound resolveNbtCompound(ItemStack stack) {
      NbtComponent var1 = (NbtComponent)stack.get(DataComponentTypes.CUSTOM_DATA);
      return var1 == null ? null : var1.copyNbt();
   }

   public default List getList() {
      return List.of(this.getText2(), this.getText());
   }

   public default ClientContract18 getClientContract18() {
      return MinecraftAccess35.resolveClientContract182(ClientState52.clientState525, (argument0) -> this.testItemStack2((net.minecraft.item.ItemStack) argument0));
   }

   public static boolean testText2(String text, String text2) {
      return text != null && text2 != null && !text2.isBlank() ? text.toLowerCase(Locale.ROOT).contains(text2.toLowerCase(Locale.ROOT)) : false;
   }

   public default boolean testText(String text) {
      return this.getList().stream().anyMatch(var1x -> testText2(((java.lang.String) (var1x)), text));
   }

   public default boolean testItemStack(ItemStack stack) {
      String text = Formatting.strip(stack.getName().getString());
      return testText2(text, this.getText()) || testText2(text, this.getText2());
   }

   public ItemStack getItemStack2();

   public ServerHelperServer getServerType();

   public String getText2();

   public static Optional resolveOptional(String text) {
      return text != null && !text.isBlank() ? getStream().filter(var1 -> ((api.ClientContract4) (var1)).testText(text)).findFirst() : Optional.empty();
   }

   public default boolean testItemStack2(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         if (stack.getItem() != this.getItemStack2().getItem()) {
            return false;
         }

         NbtCompound var2 = resolveNbtCompound(stack);
         return this.testNbtCompound(var2) || this.testItemStack(stack);
      } else {
         return false;
      }
   }

   public static Stream getStream() {
      return Stream.of(
            Arrays.stream(OptionGroup132.values()),
            Arrays.stream(OptionGroup136.values()),
            Arrays.stream(OptionGroup87.values()),
            Arrays.stream(OptionGroup54.values())
         )
         .flatMap(var0 -> var0.map(var0x -> (Enum)var0x));
   }

   public static boolean testNbtCompound(NbtCompound var0, String text, String text2) {
      return var0 == null ? false : var0.getString(text).map(var1x -> testText2(var1x, text2)).orElse(false);
   }

   public default boolean testNbtCompound(NbtCompound var1) {
      return false;
   }
}
