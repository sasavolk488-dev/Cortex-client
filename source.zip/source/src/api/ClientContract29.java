package api;

public interface ClientContract29 {
   public boolean testState() throws InterruptedException;
}
