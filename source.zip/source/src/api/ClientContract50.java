package api;

public interface ClientContract50 {
   public boolean testClientContract34(ClientContract34 var1);
}
