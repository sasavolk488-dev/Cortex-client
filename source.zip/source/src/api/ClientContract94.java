package api;
import java.io.InputStream;


public interface ClientContract94 extends ClientContract79 {
   public default int getInt() {
      return 0;
   }

   public @Override
   default Object getValue() {
      throw new AbstractMethodError("Method あ/ルリゆ.ツポりお()Ljava/lang/Object; is abstract");
   }

   public @Override
   default InputStream getInputStream() {
      throw new AbstractMethodError("Method あ/ルリゆ.ツ()Ljava/io/InputStream; is abstract");
   }
}
