package api;

import net.minecraft.client.util.math.MatrixStack;

public interface ClientContract34 {
   public default boolean testFloat3(float value, float value2) {
      return false;
   }

   public default void updateState5() {
      this.handleFloat2(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);
      this.updateState();
   }

   public default boolean testState2() {
      return false;
   }

   public default boolean testState4() {
      return false;
   }

   public default void handleFloat(float value, float value2, float value3, float value4) {
   }

   public default boolean testState5() {
      return false;
   }

   public default boolean testFloat(float value, float value2, int index) {
      return false;
   }

   public default boolean testFloat4(float value, float value2) {
      return false;
   }

   public default boolean testInt(int index, int index2) {
      return false;
   }

   public default boolean testInt2(int index, int index2) {
      return index2 != 1 ? false : this.testInt2(index);
   }

   public default boolean testInt2(int index) {
      return false;
   }

   public default boolean testState3() {
      return false;
   }

   public default boolean testFloat(float value, float value2, double value3) {
      return false;
   }

   public default boolean testState13() {
      return false;
   }

   public default void updateState() {
   }

   public default boolean testFloat5(float value, float value2) {
      return false;
   }

   public default boolean testFloat2(float value, float value2, int index) {
      return this.testFloat4(value, value2);
   }

   public default void handleFloat2(float value, float value2) {
   }

   public default int calculateInt(float value, float value2) {
      return 0;
   }

   public default boolean testState6() {
      return false;
   }

   public default void handleMatrixStack(MatrixStack matrices) {
   }

   public default void handleFloat2(float value, float value2, float value3, float value4) {
   }

   public default void handleBoolean2(boolean flag) {
   }

   public default void handleFloat3(float value, float value2) {
   }
}
