package api;

public interface ClientContract63 {
   public void handleInt(int index);
}
