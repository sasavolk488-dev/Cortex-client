package api;

public interface ClientContract88 {
   public void handleClientContract31(ClientContract31 var1);
}
