package api;

import model.ClientState101;
import model.ClientState11;
import model.ClientState115;
import model.ClientState119;
import model.ClientState167;
import model.ClientState189;
import model.ClientState264;
import model.ClientState341;
import model.ClientState393;
import model.ClientState43;
import model.ClientState432;
import model.ClientState464;
import model.ClientState484;
import model.ClientState580;
import model.ClientState64;
import model.ClientState66;
import model.NumericState12;
import model.NumericState167;
import model.NumericState188;
import model.NumericState95;
import util.ClientUtils31;

public interface ClientContract19 extends ClientContract75 {
   public void handleClientState64(ClientState64 var1);

   public void handleNumericState167(NumericState167 var1);

   public void handleClientState264(ClientState264 var1);

   public void handleClientState484(ClientState484 var1);

   public void handleClientState11(ClientState11 var1);

   public void handleClientState167(ClientState167 var1);

   public void handleNumericState12(NumericState12 var1);

   public void handleClientState66(ClientState66 var1);

   public void handleClientUtils31(ClientUtils31 var1);

   public void handleClientState580(ClientState580 var1);

   public void handleClientState43(ClientState43 var1);

   public void handleClientState432(ClientState432 var1);

   public void handleClientState341(ClientState341 var1);

   public void handleNumericState95(NumericState95 var1);

   public void handleClientState189(ClientState189 var1);

   public void handleClientState115(ClientState115 var1);

   public void handleClientState464(ClientState464 var1);

   public void handleNumericState188(NumericState188 var1);

   public void handleClientState101(ClientState101 var1);

   public void handleClientState119(ClientState119 var1);

   public void handleClientState393(ClientState393 var1);
}
