package api;

public interface ClientContract74 {
}
