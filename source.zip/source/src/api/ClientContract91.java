package api;

import model.ClientState114;

public interface ClientContract91 {
   public ClientState114 resolveClientState114(String text);
}
