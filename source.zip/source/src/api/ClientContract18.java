package api;

import callbacks.Comparator2;
import callbacks.ToIntFunction3;
import java.util.Comparator;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import settings.options.OptionGroup129;
import util.ClientUtils184;
import settings.options.OptionGroup93;


public interface ClientContract18 extends ClientContract32 {
   public Comparator comparator = Comparator2.getComparator2();
   public Comparator comparator2 = Comparator.comparingInt(ToIntFunction3.getToIntFunction3());
   public Comparator comparator3 = comparator2.reversed();

   public @Override
   ItemStack getItemStack();

   public default Integer getInteger() {
      return this.resolveInteger(ClientUtils184.getHandledScreen2());
   }

   public Integer resolveInteger(HandledScreen var1);

   public OptionGroup129 getType();

   public static int calculateInt(ClientContract18 var0, ClientContract18 var1) {
      boolean var2 = var0 instanceof OptionGroup93;
      boolean var3 = var1 instanceof OptionGroup93;
      if (var2 && var3) {
         return OptionGroup93.comparator.compare((OptionGroup93)var0, (OptionGroup93)var1);
      } else if (var2) {
         return -1;
      } else {
         return var3 ? 1 : 0;
      }
   }

   public static int calculateInt(ClientContract18 var0) {
      return var0.getItemStack().getCount();
   }
}
