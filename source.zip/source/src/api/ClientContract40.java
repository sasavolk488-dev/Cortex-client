package api;

import settings.options.OptionGroup13;

public interface ClientContract40 {
   public OptionGroup13 resolveOptionGroup13(ClientContract81 var1);
}
