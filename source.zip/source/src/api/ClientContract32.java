package api;

import net.minecraft.item.ItemStack;

public interface ClientContract32 {
   public ItemStack getItemStack();
}
