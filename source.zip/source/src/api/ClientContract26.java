package api;

public interface ClientContract26 {
   public String getText();
}
