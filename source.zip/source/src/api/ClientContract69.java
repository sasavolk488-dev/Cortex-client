package api;

public interface ClientContract69 {
   public boolean testState();

   public boolean testFloat(float value, float value2);
}
