package api;

import java.io.InputStream;

public interface ClientContract79 {
   public Object getValue();

   public default boolean testState2() {
      return true;
   }

   public InputStream getInputStream();
}
