package api;

import net.minecraft.item.ItemStack;

public interface ClientContract49 {
   public boolean testItemStack(ItemStack stack);
}
