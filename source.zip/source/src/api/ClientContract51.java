package api;

import model.NumericState59;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public interface ClientContract51 {
   public default Vec3d resolvePosition(Vec3d position, Box bounds, double value) {
      Vec3d position2 = this.resolvePosition3(position, bounds, value);
      return bounds.contains(position2) ? position2 : bounds.raycast(position, position2).orElse(position2);
   }

   public static ClientContract51 getClientContract51() {
      return (var0, var1, var2) -> var1.getCenter();
   }

   public static ClientContract51 resolveClientContract51(Vec3d position) {
      return (var1, var2, var3) -> position == null ? var2.getCenter() : position;
   }

   public Vec3d resolvePosition3(Vec3d position, Box bounds, double value);

   public static ClientContract51 resolveClientContract51(NumericState59 var0) {
      return (var1, var2, var3) -> var0 == null ? var2.getCenter() : var1.add(var0.getPosition().multiply(var3));
   }
}
