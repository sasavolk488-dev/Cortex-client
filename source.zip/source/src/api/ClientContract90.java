package api;

import settings.options.OptionGroup51;

public interface ClientContract90 {
   public OptionGroup51 getOptionGroup51();
}
