package api;

import java.util.function.Supplier;
import model.ClientState477;
import model.ClientState62;

public interface ClientContract80 {
   public default Object resolveValue2(Supplier var1) {
      return this.resolveWidgetPart3(ClientState62.resolveClientState62(var1));
   }

   public Object resolveWidgetPart3(ClientState62 var1);

   public default Object resolveValue2(int index) {
      return this.resolveWidgetPart3(ClientState62.resolveClientState62(index));
   }

   public default Object resolveValue2(ClientState477 var1) {
      return this.resolveWidgetPart3(ClientState62.resolveClientState62(var1));
   }
}
