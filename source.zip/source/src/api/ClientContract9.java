package api;

public interface ClientContract9 extends ClientContract43, ClientContract62 {
   public void handleText(String text);
}
