package clickgui.widgets;

import api.ClientContract26;
import clickgui.icons.Icon;
import java.util.Locale;
import java.util.Objects;
import model.ClientState270;
import net.minecraft.client.util.math.MatrixStack;
import settings.EnumSetting;
import settings.TranslationKeyProvider;
import util.ClientUtils195;
import util.ClientUtils213;
import util.ClientUtils61;


public class EnumSettingWidget1 extends WidgetPart31 {
   private static final TranslationKeyProvider translationKeyProvider = ClientUtils195.getClientUtils195();
   private final EnumSetting setting;
   private final TranslationKeyProvider translationKeyProvider2;

   public EnumSettingWidget1(EnumSetting setting) {
      this(setting, translationKeyProvider);
   }

   public EnumSettingWidget1(EnumSetting setting, TranslationKeyProvider var2) {
      super(340.0F);
      this.setting = Objects.requireNonNull(setting, "setting");
      this.translationKeyProvider2 = getTranslationKeyProvider(var2);
   }

   private static TranslationKeyProvider getTranslationKeyProvider(TranslationKeyProvider var0) {
      return var0 == null ? translationKeyProvider : var0;
   }

   private void handleMatrixStack(MatrixStack matrices, ClientState270 var2, float value, float value2) {
      float value3 = value2 + 9.0F;
      ClientUtils61.resolveMatrixStackState5(matrices, Icon.CHECK, value, value3, 12.0F, 12.0F).resolveMatrixStackState5(var2.getClientState4776());
   }

   public EnumSetting getSetting() {
      return this.setting;
   }

   @Override
   public int getItemConvertibleState1Array() {
      return this.setting.getOptions().length;
   }

   @Override
   public boolean testInt(int index, String text) {
      Enum var3 = this.setting.getOptions()[index];
      String text2 = this.resolveText(var3).toLowerCase(Locale.ROOT);
      String text3 = var3 != null && ((ClientContract26)var3).getText() != null ? ((ClientContract26)var3).getText().toLowerCase(Locale.ROOT) : "";
      return text2.contains(text) || text3.contains(text);
   }

   @Override
   public void handleMatrixStack(MatrixStack matrices, ClientState270 var2) {
      float value = this.getX() + 10.0F;
      this.handleMatrixStack2(
         matrices,
         this.resolveText((Enum)this.setting.getValue()),
         value,
         this.getY(),
         this.getFloat7() - value,
         30.0F,
         16.0F,
         var2.getClientState4779(),
         0L,
         this.getX(),
         this.getY(),
         this.getWidth(),
         30.0F
      );
   }

   @Override
   public void handleMatrixStack(MatrixStack matrices, ClientState270 var2, int index, int index2, float value) {
      Enum var6 = this.setting.getOptions()[index];
      boolean flag = this.setting.is(var6);
      float value2 = this.getX() + 10.0F;
      float value3 = this.getFloat4() - 12.0F;
      float value4 = value3 - 8.0F - value2;
      this.handleMatrixStack(matrices, var2, false, !flag && index2 == this.getIntValue2(), value);
      this.handleMatrixStack(
         matrices,
         this.resolveText(var6),
         value2,
         value,
         value4,
         30.0F,
         16.0F,
         flag ? var2.getClientState4779() : var2.getClientState4774(),
         1L + index,
         this.getX() + 6.0F,
         value,
         this.getWidth() - 12.0F,
         30.0F
      );
      if (flag) {
         this.handleMatrixStack(matrices, var2, value3, value);
      }
   }

   private String resolveText(Enum var1) {
      if (var1 == null) {
         return "";
      }

      String text = ((ClientContract26)var1).getText();
      String text2 = this.translationKeyProvider2.getTranslationKey();
      return text != null && !text.isBlank() ? ClientUtils213.resolveText5(text2 + ".values." + text + ".name") : "";
   }

   @Override
   public int getInt() {
      Enum[] var1 = this.setting.getOptions();

      for (int index = 0; index < this.getIntArray(); index++) {
         if (this.setting.is(var1[this.getIntArray(index)])) {
            return index;
         }
      }

      return this.getIntArray() > 0 ? 0 : -1;
   }

   @Override
   public void handleInt(int index) {
      this.setting.setValue2(this.setting.getOptions()[this.getIntArray(index)]);
      this.handleBoolean(false);
   }

   public static String getText() {
      return "";
   }

   @Override
   public boolean testFloat3(float var1, float var2) {
      return super.testFloat3(var1, var2);
   }

   @Override
   public boolean testState2() {
      return super.testState2();
   }

   @Override
   public boolean testState4() {
      return super.testState4();
   }

   @Override
   public void handleFloat(float var1, float var2, float var3, float var4) {
      super.handleFloat(var1, var2, var3, var4);
   }

   @Override
   public boolean testState5() {
      return super.testState5();
   }

   @Override
   public boolean testFloat(float var1, float var2, int var3) {
      return super.testFloat(var1, var2, var3);
   }

   @Override
   public boolean testInt(int var1, int var2) {
      return super.testInt(var1, var2);
   }

   @Override
   public void render(MatrixStack var1) {
      super.render(var1);
   }

   @Override
   public boolean testInt2(int var1, int var2) {
      return super.testInt2(var1, var2);
   }

   @Override
   public boolean testInt2(int var1) {
      return super.testInt2(var1);
   }

   @Override
   public boolean testState3() {
      return super.testState3();
   }

   @Override
   public boolean testFloat(float var1, float var2, double var3) {
      return super.testFloat(var1, var2, var3);
   }

   @Override
   public void updateState() {
      super.updateState();
   }

   @Override
   public boolean testFloat5(float var1, float var2) {
      return super.testFloat5(var1, var2);
   }

   @Override
   public boolean testFloat2(float var1, float var2, int var3) {
      return super.testFloat2(var1, var2, var3);
   }

   @Override
   public void handleFloat2(float var1, float var2) {
      super.handleFloat2(var1, var2);
   }

   @Override
   public int calculateInt(float var1, float var2) {
      return super.calculateInt(var1, var2);
   }

   @Override
   public boolean testState6() {
      return super.testState6();
   }

   @Override
   public void handleMatrixStack(MatrixStack var1) {
      super.handleMatrixStack(var1);
   }

   @Override
   public void handleFloat2(float var1, float var2, float var3, float var4) {
      super.handleFloat2(var1, var2, var3, var4);
   }

   @Override
   public void handleFloat3(float var1, float var2) {
      super.handleFloat3(var1, var2);
   }
}
