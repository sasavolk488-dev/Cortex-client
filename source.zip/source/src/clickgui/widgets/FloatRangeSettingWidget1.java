package clickgui.widgets;

import api.ClientContract34;
import api.ClientContract69;
import api.ClientContract91;
import java.util.Objects;
import java.util.function.Supplier;
import model.ClientState114;
import model.ClientState270;
import model.ClientState477;
import model.TextState8;
import net.minecraft.client.util.math.MatrixStack;
import render.ColorRGBA;
import settings.FloatRangeSetting;
import settings.options.OptionGroup160;
import settings.options.OptionGroup180;
import util.ClientUtils209;
import util.ClientUtils284;
import util.ClientUtils348;
import util.ClientUtils374;
import util.ClientUtils51;
import util.ClientUtils61;

public class FloatRangeSettingWidget1 extends PanelWidget implements ClientContract34, ClientContract69 {
   private static final ColorRGBA colorRGBA = ColorRGBA.resolveColorRGBA8(3.0F);
   private final FloatRangeSetting setting;
   private final StringSettingWidget1 stringSettingWidget1;
   private final StringSettingWidget1 stringSettingWidget12;
   private final ClientUtils209 clientUtils209 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);
   private final ClientUtils209 clientUtils2092 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);
   private final ClientUtils209 clientUtils2093 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);
   private final ClientUtils209 clientUtils2094 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);
   private final ClientUtils209 clientUtils2095 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);
   private final ClientUtils209 clientUtils2096 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);
   private int intValue = 0;
   private int intValue2 = 0;
   private float floatValue = Float.NaN;
   private float floatValue2 = Float.NaN;
   private long longValue;
   private float floatValue3 = 1.0F;
   private float floatValue4 = 1.0F;

   public FloatRangeSettingWidget1(FloatRangeSetting setting) {
      this.setting = Objects.requireNonNull(setting, "setting");
      this.stringSettingWidget1 = this.resolveStringSettingWidget1(this::getText, this::resolveClientState114);
      this.stringSettingWidget12 = this.resolveStringSettingWidget1(this::getText2, this::resolveClientState1142);
      this.clientUtils2095.resolveClientState3483(setting.getFrom());
      this.clientUtils2096.resolveClientState3483(setting.getTo());
      this.getWidget();
      this.resolveWidget6(340.0F);
      this.resolveWidget(32.0F);
      this.addChild(this.stringSettingWidget1);
      this.addChild(this.stringSettingWidget12);
   }

   private void handleFloat(float value) {
      float value2 = this.getFloat3();
      float value3 = this.calculateFloat4(this.calculateFloat2(value));
      if (this.intValue == 1) {
         this.setting.setFrom(value3);
      } else if (this.intValue == 2) {
         this.setting.setTo(value3);
      }

      this.handleFloat(value2, this.getFloat3());
   }

   private void handleFloat(float value, float value2) {
      if (Float.compare(value, value2) != 0) {
         long longValue = System.currentTimeMillis();
         if (longValue - this.longValue >= 80L) {
            this.longValue = longValue;
            OptionGroup160.SLIDER.updateState();
         }
      }
   }

   private static boolean testInt(int index) {
      return Character.isDigit(index) || index == 45 || index == 43 || index == 46 || index == 44;
   }

   private ClientState477 resolveClientState477(ClientState270 var1, float value) {
      return ClientUtils374.resolveClientState477(var1.getClientState4776(), var1.getClientState4777()).resolveClientState4772(0.72F + value * 0.2F);
   }

   private float calculateFloat(float value) {
      float value2 = this.setting.getMaximum() - this.setting.getMinimum();
      float value3;
      if (value2 <= 0.0F) {
         value3 = 0.0F;
      } else {
         value3 = (value - this.setting.getMinimum()) / value2;
         float value4 = 1.0F;
         float value5 = 0.0F;
         float value6 = value3;
         float value7 = Math.max(Math.min(value6, value4), value5);
         value3 = value7;
      }

      float value8 = value3;
      return this.getFloat() + this.getFloat5() * value8;
   }

   private float getFloat() {
      return this.getX() + this.floatValue3 + 12.0F + 6.5F;
   }

   private String getText() {
      return ClientUtils51.resolveText(this.setting.getFrom(), this.setting.getPrecision());
   }

   private boolean testFloat2(float value, float value2) {
      if (Float.isFinite(this.floatValue) && Float.isFinite(this.floatValue2)) {
         float value3 = value2 + 3.0F;
         float value4 = ClientUtils348.getFLOAT_CONSTANT7();
         float value5 = this.floatValue - value;
         float value6 = this.floatValue2 - value3;
         return value5 * value5 + value6 * value6 <= value4 * value4;
      } else {
         return false;
      }
   }

   private Float resolveFloat(String text) {
      if (text == null) {
         return null;
      }

      String text2 = text.trim();
      String text3 = this.setting.getSuffix();
      if (text3 != null && !text3.isBlank() && text2.endsWith(text3)) {
         text2 = text2.substring(0, text2.length() - text3.length()).trim();
      }

      text2 = text2.replace(',', '.');
      if (!text2.isEmpty() && !"-".equals(text2) && !"+".equals(text2) && !".".equals(text2) && !"-.".equals(text2) && !"+.".equals(text2)) {
         try {
            float value = Float.parseFloat(text2);
            return Float.isFinite(value) ? value : null;
         } catch (NumberFormatException var5) {
            return null;
         }
      } else {
         return null;
      }
   }

   private float calculateFloat2(float value) {
      float value2 = (value - this.getFloat()) / Math.max(1.0F, this.getFloat5());
      float value3 = 1.0F;
      float value4 = 0.0F;
      float value5 = value2;
      float value6 = Math.max(Math.min(value5, value3), value4);
      float value7 = value6;
      return this.setting.getMinimum() + (this.setting.getMaximum() - this.setting.getMinimum()) * value7;
   }

   private float getFloat2() {
      return this.getY() + (this.getHeight() - 6.0F) * 0.5F;
   }

   private ClientState477 resolveClientState477(ClientState270 var1, float value, float value2) {
      return var1.getClientState4775().resolveClientState4772(0.22F + value * 0.08F + value2 * 0.08F);
   }

   private float getFloat3() {
      if (this.intValue == 1) {
         return this.setting.getFrom();
      } else {
         return this.intValue == 2 ? this.setting.getTo() : Float.NaN;
      }
   }

   private float calculateFloat3(float value) {
      if (this.getClientState3752().testState2()) {
         return this.getClientState3752().getFloatValue();
      } else {
         return this.getClientState3752().testState() && Float.isFinite(value) ? Math.max(0.0F, value) : 32.0F;
      }
   }

   private float calculateFloat(float value, int index) {
      return TextState8.calculateFloat4(OptionGroup180.SUISSE_INTL_REGULAR, ClientUtils51.resolveText(value, index, this.setting.getSuffix()), 14.0F);
   }

   private double calculateDouble(int index) {
      return this.intValue == index ? 0.08 : 0.16;
   }

   private ClientState114 resolveClientState114(String text) {
      Float value = this.resolveFloat(text);
      if (value == null) {
         return ClientState114.getClientState114();
      }

      this.setting.setFrom(this.calculateFloat4(value));
      return ClientState114.resolveClientState114(this.getText());
   }

   @Override
   public boolean testFloat3(float floatValue, float floatValue2) {
      this.floatValue = floatValue;
      this.floatValue2 = floatValue2;
      if (this.intValue == 0) {
         return false;
      }

      this.handleFloat(floatValue);
      return true;
   }

   @Override
   public boolean testState2() {
      return this.intValue != 0;
   }

   @Override
   public boolean testFloat(float floatValue, float floatValue2, int index) {
      this.floatValue = floatValue;
      this.floatValue2 = floatValue2;
      if (index != 0 || !this.contains(floatValue, floatValue2)) {
         return false;
      }

      if (!this.stringSettingWidget1.contains(floatValue, floatValue2) && !this.stringSettingWidget12.contains(floatValue, floatValue2)) {
         if (this.getFloat5() <= 0.5F) {
            return false;
         }

         this.intValue = this.calculateInt(floatValue);
         this.intValue2 = this.intValue;
         this.handleFloat(floatValue);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean testFloat4(float floatValue, float floatValue2) {
      this.floatValue = floatValue;
      this.floatValue2 = floatValue2;
      if (this.intValue == 0) {
         return false;
      }

      this.intValue = 0;
      return true;
   }

   private float getFloat4() {
      int index = this.setting.getPrecision();
      float value = Math.max(this.calculateFloat(this.setting.getMinimum(), index), this.calculateFloat(this.setting.getMaximum(), index));
      value = Math.max(value, this.calculateFloat(this.setting.getFrom(), index));
      value = Math.max(value, this.calculateFloat(this.setting.getTo(), index));
      return Math.max(1.0F, (float)Math.ceil(value) + 12.0F);
   }

   @Override
   public boolean testState() {
      this.stringSettingWidget1.resolveWidget3(this.floatValue3, 26.0F);
      this.stringSettingWidget12.resolveWidget3(this.floatValue4, 26.0F);
      float value = this.getY() + (this.getHeight() - 26.0F) * 0.5F;
      this.stringSettingWidget1.resolveWidget(this.getX(), value, this.floatValue3, 26.0F);
      this.stringSettingWidget12.resolveWidget(this.getX() + this.getWidth() - this.floatValue4, value, this.floatValue4, 26.0F);
      return true;
   }

   @Override
   public void render(MatrixStack matrices) {
      ClientState270 var2 = ClientUtils374.getClientState270();
      float value = (Float)((ClientUtils209)this.clientUtils209.resolveClientState348(this.contains(this.floatValue, this.floatValue2) ? 1.0F : 0.0F, 0.14))
         .getValue3();
      boolean flag = this.intValue != 0;
      if (flag) {
         this.intValue2 = this.intValue;
      }

      float value2 = (Float)((ClientUtils209)this.clientUtils2092.resolveClientState348(flag ? 1.0F : 0.0F, flag ? 0.12 : 0.26)).getValue3();
      if (!flag && this.clientUtils2092.testState()) {
         this.intValue2 = 0;
      }

      float value3 = (Float)((ClientUtils209)this.clientUtils2095.resolveClientState348(this.setting.getFrom(), this.calculateDouble(1))).getValue3();
      float value4 = (Float)((ClientUtils209)this.clientUtils2096.resolveClientState348(this.setting.getTo(), this.calculateDouble(2))).getValue3();
      float value5 = this.getFloat();
      float value6 = this.getFloat2();
      float value7 = this.getFloat5();
      if (value7 <= 0.5F) {
         this.stringSettingWidget1.render(matrices);
         this.stringSettingWidget12.render(matrices);
      } else {
         float value8 = this.calculateFloat(value3);
         float value9 = this.calculateFloat(value4);
         float value10 = calculateFloat(this.setting.getFrom(), this.setting.getTo(), value8, value9);
         boolean flag2 = this.testFloat2(value8, value6) || this.intValue == 1;
         boolean flag3 = this.testFloat2(value9, value6) || this.intValue == 2;
         float value11 = (Float)((ClientUtils209)this.clientUtils2093.resolveClientState348(flag2 ? 1.0F : 0.0F, flag2 ? 0.14 : 0.26)).getValue3();
         float value12 = (Float)((ClientUtils209)this.clientUtils2094.resolveClientState348(flag3 ? 1.0F : 0.0F, flag3 ? 0.14 : 0.26)).getValue3();
         float value13 = this.calculateFloat(value11, value2, 1);
         float value14 = this.calculateFloat(value12, value2, 2);
         float value15 = value6 + 3.0F;
         ClientUtils61.resolveMatrixStackState4(matrices, value5, value6, value7, 6.0F)
            .withColorRGBA(colorRGBA)
            .resolveMatrixStackState4(this.resolveClientState477(var2, value, value2));
         if (value10 > 0.0F) {
            ClientUtils61.resolveMatrixStackState4(matrices, value8, value6, value10, 6.0F)
               .withColorRGBA(colorRGBA)
               .resolveMatrixStackState4(this.resolveClientState477(var2, value2));
         }

         ClientUtils348.handleMatrixStack(matrices, this.resolveClientState477(var2), this.resolveClientState4772(var2), value9, value15, value14);
         ClientUtils348.handleMatrixStack(matrices, this.resolveClientState477(var2), this.resolveClientState4772(var2), value8, value15, value13);
         this.stringSettingWidget1.render(matrices);
         this.stringSettingWidget12.render(matrices);
      }
   }

   public FloatRangeSetting getSetting() {
      return this.setting;
   }

   @Override
   public boolean testState3() {
      return this.intValue != 0;
   }

   @Override
   public void updateState() {
      this.intValue = 0;
      this.intValue2 = 0;
   }

   private float calculateFloat4(float value) {
      return ClientUtils51.calculateFloat(value, this.setting.getMinimum(), this.setting.getMaximum(), this.setting.getStep(), this.setting.getPrecision());
   }

   @Override
   public void handleFloat2(float floatValue, float floatValue2) {
      this.floatValue = floatValue;
      this.floatValue2 = floatValue2;
   }

   private float calculateFloat5(float value) {
      if (this.getClientState375().testState2()) {
         return this.getClientState375().getFloatValue();
      } else {
         return this.getClientState375().testState() && Float.isFinite(value) ? Math.max(0.0F, value) : 340.0F;
      }
   }

   private float getFloat5() {
      return Math.max(0.0F, this.getWidth() - this.floatValue3 - this.floatValue4 - 24.0F - 13.0F);
   }

   @Override
   public boolean testFloat(float value, float value2) {
      this.floatValue3 = this.getFloat4();
      this.floatValue4 = this.floatValue3;
      this.stringSettingWidget1.resolveWidget3(this.floatValue3, 26.0F);
      this.stringSettingWidget12.resolveWidget3(this.floatValue4, 26.0F);
      this.stringSettingWidget1.resolveWidget2(this.floatValue3, 26.0F);
      this.stringSettingWidget12.resolveWidget2(this.floatValue4, 26.0F);
      this.handleFloat5(this.calculateFloat5(value), this.calculateFloat3(value2));
      return true;
   }

   private float calculateFloat(float value, float value2, int index) {
      float value3 = this.intValue2 == index ? value2 : 0.0F;
      return ClientUtils348.calculateFloat(value, value3);
   }

   private ClientState114 resolveClientState1142(String text) {
      Float value = this.resolveFloat(text);
      if (value == null) {
         return ClientState114.getClientState114();
      }

      this.setting.setTo(this.calculateFloat4(value));
      return ClientState114.resolveClientState114(this.getText2());
   }

   private StringSettingWidget1 resolveStringSettingWidget1(Supplier var1, ClientContract91 var2) {
      StringSettingWidget1 var3 = new StringSettingWidget1(var1, var2);
      var3.resolveWidget3(1.0F, 26.0F);
      var3.resolveStringSettingWidget1(16);
      var3.getStringSettingWidget13();
      var3.withBooleanValue7(false);
      var3.getStringSettingWidget14();
      var3.resolveStringSettingWidget12(this.setting::getSuffix);
      var3.resolveStringSettingWidget1((argument0) -> FloatRangeSettingWidget1.testInt((int) argument0));
      return var3;
   }

   public static float calculateFloat(float value, float value2, float value3, float value4) {
      return !(value < value2) ? 0.0F : Math.max(0.0F, value4 - value3);
   }

   private int calculateInt(float value) {
      float value2 = this.calculateFloat(this.setting.getFrom());
      float value3 = this.calculateFloat(this.setting.getTo());
      if (Math.abs(value - value2) == Math.abs(value - value3)) {
         return value > value2 ? 2 : 1;
      } else {
         return Math.abs(value - value2) < Math.abs(value - value3) ? 1 : 2;
      }
   }

   private ClientState477 resolveClientState477(ClientState270 var1) {
      return ClientUtils374.resolveClientState477(var1.getClientState4776(), var1.getClientState4775()).resolveClientState4772(1.0F);
   }

   private ClientState477 resolveClientState4772(ClientState270 var1) {
      return var1.getClientState477().resolveClientState4772(1.0F);
   }

   private String getText2() {
      return ClientUtils51.resolveText(this.setting.getTo(), this.setting.getPrecision());
   }
}
