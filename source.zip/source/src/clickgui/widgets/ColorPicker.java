package clickgui.widgets;

import clickgui.icons.Icon;
import java.util.Objects;
import model.ClientState114;
import model.ClientState270;
import model.ClientState477;
import net.minecraft.client.util.math.MatrixStack;
import render.ColorRGBA;
import settings.ColorSetting;
import settings.TranslationKeyProvider;
import settings.options.OptionGroup160;
import util.ClientUtils343;
import util.ClientUtils374;
import util.ClientUtils61;

public class ColorPicker extends SettingWidget {
   public static final long LONG_CONSTANT = 80L;
   public static final ColorRGBA colorRGBA = ColorRGBA.resolveColorRGBA9(6.0F);
   public static final ColorRGBA colorRGBA2 = ColorRGBA.resolveColorRGBA9(8.0F);
   public static final ColorRGBA colorRGBA3 = ColorRGBA.resolveColorRGBA8(4.0F);
   public static final ColorRGBA colorRGBA4 = ColorRGBA.resolveColorRGBA9(8.0F);
   public static final ColorRGBA colorRGBA5 = ColorRGBA.resolveColorRGBA8(2.5F);
   public final ColorSetting setting;
   public float floatValue;
   public float floatValue2;
   public float floatValue3;
   public float floatValue4 = 1.0F;
   public boolean booleanValue;
   public int intValue;
   public long longValue;

   public ColorPicker(ColorSetting setting, TranslationKeyProvider var2, WidgetPart9... var3) {
      super(var2, Icon.COLOR);
      this.setting = Objects.requireNonNull(setting, "setting");
      this.updateState3();
      this.resolveSettingWidget2(320.0F);
      this.resolveSettingWidget(420.0F);
      this.resolveSettingWidget(new WidgetPart64(this));
      this.resolveSettingWidget(new WidgetPart62(this));
      if (setting.allowsAlpha()) {
         this.resolveSettingWidget(new WidgetPart19(this));
      }

      this.resolveSettingWidget(this.getPanelWidget());
      this.resolveSettingWidget(var3);
   }

   public String getText() {
      int index = this.getInt2();
      if (this.setting.allowsAlpha()) {
         int index2 = index;
         int index3 = index2 >>> 24;
         if (index3 < 255) {
            return String.format("#%08X", index);
         }
      }

      return String.format("#%06X", index & 16777215);
   }

   public static float[] resolveFloatArray(int index) {
      int index2 = index;
      int index3 = index2 >> 16 & 0xFF;
      float value = index3 / 255.0F;
      int index4 = index;
      int index5 = index4 >> 8 & 0xFF;
      float value2 = index5 / 255.0F;
      int index6 = index;
      int index7 = index6 & 0xFF;
      float value3 = index7 / 255.0F;
      float value4 = Math.max(value, Math.max(value2, value3));
      float value5 = Math.min(value, Math.min(value2, value3));
      float value6 = value4 - value5;
      float value7 = 0.0F;
      if (value6 > 0.0F) {
         if (value4 == value) {
            value7 = ((value2 - value3) / value6 % 6.0F + 6.0F) % 6.0F;
         } else if (value4 == value2) {
            value7 = (value3 - value) / value6 + 2.0F;
         } else {
            value7 = (value - value2) / value6 + 4.0F;
         }

         value7 /= 6.0F;
      }

      float value8 = value4 <= 0.0F ? 0.0F : value6 / value4;
      return new float[]{value7, value8, value4};
   }

   public int getInt() {
      int index = (Integer)this.setting.getValue();
      return this.setting.allowsAlpha() ? index : index | 0xFF000000;
   }

   public void updateState2() {
      int index = this.getInt();
      int intValue = this.getInt2();
      this.booleanValue = true;
      this.intValue = intValue;
      this.setting.setValue(intValue);
      this.handleInt(index, intValue);
   }

   @Override
   public void render(MatrixStack matrices) {
      if (this.isBooleanValue7()) {
         this.updateState3();
         ClientState270 var2 = ClientUtils374.getClientState270();
         int index = this.getInt2();
         int index2 = index;
         int index3 = index2 >>> 24;
         if (index3 < 255) {
            ClientUtils61.resolveMatrixStackState4(matrices, this).withColorRGBA(colorRGBA).resolveMatrixStackState4(var2.getClientState477());
         }

         ClientUtils61.resolveMatrixStackState4(matrices, this)
            .withColorRGBA(colorRGBA)
            .resolveMatrixStackState4(ClientUtils374.resolveClientState477(ClientState477.resolveClientState4774(index)));
         ClientUtils61.resolveMatrixStackState4(matrices, this).withColorRGBA(colorRGBA).resolveMatrixStackState4(this.resolveClientState477(var2), 1.0F);
         float value = this.getX() + (this.getWidth() - 14.0F) * 0.5F;
         float value2 = this.getY() + (this.getHeight() - 14.0F) * 0.5F;
         ClientUtils61.resolveMatrixStackState5(matrices, Icon.COLOR, value, value2, 14.0F, 14.0F)
            .resolveMatrixStackState5(ClientUtils374.resolveClientState477(ClientState477.resolveClientState4774(ClientUtils343.calculateInt(index))));
      }
   }

   public static boolean testFloat(float value, float value2, float value3, float value4) {
      float value5 = value - value3;
      float value6 = value2 - value4;
      return value5 * value5 + value6 * value6 <= 56.25F;
   }

   @Override
   public void handleMatrixStack(MatrixStack matrices) {
      this.updateState3();
      super.handleMatrixStack(matrices);
   }

   public static float calculateFloat(float value) {
      float value2 = 1.0F;
      float value3 = 0.0F;
      float value4 = value;
      return Math.max(Math.min(value4, value2), value3);
   }

   public void updateState3() {
      int intValue = this.getInt();
      if (!this.booleanValue || intValue != this.intValue) {
         this.booleanValue = true;
         this.intValue = intValue;
         float[] var2 = resolveFloatArray(intValue);
         if (var2[1] > 1.0E-5F) {
            this.floatValue = var2[0];
         }

         if (var2[2] > 1.0E-5F) {
            this.floatValue2 = var2[1];
         }

         this.floatValue3 = var2[2];
         int index = intValue;
         int index2 = index >>> 24;
         this.floatValue4 = index2 / 255.0F;
      }
   }

   public static void handleMatrixStack(MatrixStack matrices, int index, float value, float value2) {
      ClientUtils61.resolveMatrixStackState4(matrices, value, value2, 7.5F)
         .resolveMatrixStackState4(ClientUtils374.resolveClientState477(ClientState477.resolveClientState4774(-1)), 2.0F);
      ClientUtils61.resolveMatrixStackState4(matrices, value, value2, 6.5F)
         .resolveMatrixStackState4(ClientUtils374.resolveClientState477(ClientState477.resolveClientState4774(index)));
   }

   public PanelWidget getPanelWidget() {
      PanelWidget var1 = (PanelWidget)((PanelWidget)((PanelWidget)((PanelWidget)((PanelWidget)PanelWidget.getPanelWidget4().getWidget()).getWidget8())
               .getContainer14())
            .getContainer10())
         .resolveContainer2(12.0F);
      StringSettingWidget1 var2 = new StringSettingWidget1(this::getText, this::resolveClientState114);
      var2.resolveStringSettingWidget1(9);
      var2.getStringSettingWidget13();
      var2.withBooleanValue7(false);
      var2.resolveStringSettingWidget1((argument0) -> ColorPicker.testInt((int) argument0));
      ((PanelWidget)var2.getWidget()).resolveWidget(32.0F);
      var1.addChild(var2);
      var1.addChild(new WidgetPart33(this));
      return var1;
   }

   public int getInt2() {
      int index = this.setting.allowsAlpha() ? Math.round(calculateFloat(this.floatValue4) * 255.0F) : 255;
      return index << 24 | calculateInt(this.floatValue, this.floatValue2, this.floatValue3) & 16777215;
   }

   public ClientState477 resolveClientState477(ClientState270 var1) {
      if (this.isBooleanValue()) {
         return var1.getClientState4776().resolveClientState4772(0.62F);
      } else {
         return this.contains(this.getFloatValue11(), this.getFloatValue12())
            ? var1.getClientState4775().resolveClientState4772(0.54F)
            : var1.getClientState4775().resolveClientState4772(0.34F);
      }
   }

   public static int calculateInt(float value) {
      int index = Math.round(value * 255.0F);
      short var3 = 255;
      byte var2 = 0;
      int index2 = index;
      return Math.max(Math.min(index2, var3), var2);
   }

   public static int calculateInt(float value, float value2, float value3) {
      float value4 = (value % 1.0F + 1.0F) % 1.0F * 6.0F;
      int index = (int)value4 % 6;
      float value5 = value4 - (int)value4;
      float value6 = value3 * (1.0F - value2);
      float value7 = value3 * (1.0F - value5 * value2);
      float value8 = value3 * (1.0F - (1.0F - value5) * value2);
      float value9;
      float value10;
      float value11;
      switch (index) {
         case 0:
            value9 = value3;
            value10 = value8;
            value11 = value6;
            break;
         case 1:
            value9 = value7;
            value10 = value3;
            value11 = value6;
            break;
         case 2:
            value9 = value6;
            value10 = value3;
            value11 = value8;
            break;
         case 3:
            value9 = value6;
            value10 = value7;
            value11 = value3;
            break;
         case 4:
            value9 = value8;
            value10 = value6;
            value11 = value3;
            break;
         default:
            value9 = value3;
            value10 = value6;
            value11 = value7;
      }

      int index2 = calculateInt(value9);
      int index3 = calculateInt(value10);
      int index4 = calculateInt(value11);
      int index5 = index3;
      int index6 = index2;
      return 0xFF000000 | index6 << 16 | index5 << 8 | index4;
   }

   public ClientState114 resolveClientState114(String text) {
      Integer index = this.resolveInteger(text);
      if (index == null) {
         return ClientState114.getClientState114();
      }

      this.booleanValue = false;
      this.setting.setValue(index);
      this.updateState3();
      return ClientState114.resolveClientState114(this.getText());
   }

   public ColorSetting getSetting() {
      return this.setting;
   }

   public void handleInt(int index, int index2) {
      if (index != index2) {
         long longValue = System.currentTimeMillis();
         if (longValue - this.longValue >= 80L) {
            this.longValue = longValue;
            OptionGroup160.SLIDER.updateState();
         }
      }
   }

   public Integer resolveInteger(String text) {
      if (text == null) {
         return null;
      }

      String text2 = text.trim();
      if (text2.startsWith("#")) {
         text2 = text2.substring(1);
      }

      if (text2.length() == 3) {
         StringBuilder var3 = new StringBuilder(6);

         for (int index = 0; index < 3; index++) {
            var3.append(text2.charAt(index)).append(text2.charAt(index));
         }

         text2 = var3.toString();
      }

      try {
         if (text2.length() == 6) {
            int index2 = Integer.parseInt(text2, 16);
            int index3 = this.setting.allowsAlpha() ? Math.round(calculateFloat(this.floatValue4) * 255.0F) : 255;
            return index3 << 24 | index2;
         } else if (text2.length() == 8) {
            int index4 = (int)Long.parseLong(text2, 16);
            return this.setting.allowsAlpha() ? index4 : index4 | 0xFF000000;
         } else {
            return null;
         }
      } catch (NumberFormatException var5) {
         return null;
      }
   }

   public static boolean testInt(int index) {
      return index == 35 || index >= 48 && index <= 57 || index >= 97 && index <= 102 || index >= 65 && index <= 70;
   }
}
