package clickgui.widgets;

import api.ClientContract34;
import clickgui.icons.Icon;
import java.util.Objects;
import model.ClientState270;
import model.ClientState477;
import net.minecraft.client.util.math.MatrixStack;
import render.ColorRGBA;
import settings.BooleanSetting;
import settings.options.OptionGroup160;
import settings.options.OptionGroup30;
import util.ClientUtils209;
import util.ClientUtils284;
import util.ClientUtils374;
import util.ClientUtils61;

public class BooleanSettingWidget1 extends PanelWidget implements ClientContract34 {
   private static final ColorRGBA colorRGBA = ColorRGBA.resolveColorRGBA9(6.0F);
   private final BooleanSetting setting;
   private final ClientUtils209 clientUtils209 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);

   public BooleanSettingWidget1(BooleanSetting setting) {
      this.setting = Objects.requireNonNull(setting, "setting");
      this.resolveWidget7(22.0F);
      this.getContainer2();
      this.resolveContainer(4.0F);
      this.resolvePanelWidget(OptionGroup30.VALUE_2);
      this.resolvePanelWidget(colorRGBA);
      this.clientUtils209.resolveClientState3483(this.setting.getValue() ? 1.0F : 0.0F);
   }

   private void handleMatrixStack(MatrixStack matrices, ClientState477 var2, float value) {
      float value2 = Math.min(this.getWidth(), this.getHeight()) * 14.0F / 22.0F;
      float value3 = value2 * (0.78F + 0.22F * value);
      float value4 = this.getX() + (this.getWidth() - value3) * 0.5F;
      float value5 = this.getY() + (this.getHeight() - value3) * 0.5F;
      ClientUtils61.resolveMatrixStackState5(matrices, Icon.CHECK, value4, value5, value3, value3).resolveMatrixStackState5(var2.resolveClientState4772(value));
   }

   public BooleanSetting getSetting() {
      return this.setting;
   }

   @Override
   public boolean testFloat(float value, float value2, int index) {
      if (index == 0 && this.contains(value, value2)) {
         boolean flag = !(Boolean)this.setting.getValue();
         this.setting.setValue(flag);
         (flag ? OptionGroup160.TOGGLE_ON : OptionGroup160.TOGGLE_OFF).updateState();
         return true;
      } else {
         return false;
      }
   }

   @Override
   public void render(MatrixStack matrices) {
      float value = (Float)((ClientUtils209)this.clientUtils209.resolveClientState348(this.setting.getValue() ? 1.0F : 0.0F, 0.16)).getValue3();
      ClientState270 var3 = ClientUtils374.getClientState270();
      ClientUtils61.resolveMatrixStackState4(matrices, this)
         .withColorRGBA(colorRGBA)
         .resolveMatrixStackState4(var3.getClientState4777())
         .resolveMatrixStackState4(var3.getClientState4773(), 1.0F);
      if (value > 0.01F) {
         ClientUtils61.resolveMatrixStackState4(matrices, this)
            .withColorRGBA(colorRGBA)
            .resolveMatrixStackState4(ClientUtils374.resolveClientState477(var3.getClientState4776(), var3.getClientState4777()).resolveClientState4772(value));
         this.handleMatrixStack(matrices, ClientUtils374.resolveClientState477(var3.getClientState47710(), var3.getClientState4775()), value);
      }
   }
}
