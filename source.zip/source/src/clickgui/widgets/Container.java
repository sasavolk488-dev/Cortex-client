package clickgui.widgets;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import model.NumericState134;
import model.NumericState238;
import settings.options.OptionGroup137;
import settings.options.OptionGroup21;
import settings.options.OptionGroup47;

public abstract class Container extends Widget {
   public final List mutableChildren = new ArrayList();
   public final List children = Collections.unmodifiableList(this.mutableChildren);
   public final List list = new ArrayList();
   public final List list2 = new ArrayList();
   public final List list3 = new ArrayList();
   public OptionGroup47 optionGroup47 = OptionGroup47.VALUE_1;
   public NumericState134 numericState134;
   public float floatValue;
   public OptionGroup21 optionGroup21;
   public OptionGroup137 optionGroup137;
   public boolean booleanValue;

   public Container() {
      this.numericState134 = NumericState134.numericState134;
      this.floatValue = 0.0F;
      this.optionGroup21 = OptionGroup21.VALUE_1;
      this.optionGroup137 = OptionGroup137.VALUE_1;
      this.booleanValue = false;
   }

   @Override
   public boolean testState7() {
      if (super.testState7()) {
         return true;
      }

      for (Widget var2 : (java.lang.Iterable<Widget>) (java.lang.Iterable<?>) (this.list2)) {
         if (!var2.testState8()) {
            boolean flag = var2.isBooleanValue2();
            if (var2.testState11()) {
               var2.updateState13();
            }

            if (flag) {
               this.updateState10();
               return true;
            }
         } else {
            if (!var2.isBooleanValue2()) {
               var2.updateState10();
               return true;
            }

            if (var2.testState7()) {
               var2.updateState10();
               return true;
            }
         }
      }

      return false;
   }

   public Container getContainer2() {
      this.handleOptionGroup21(OptionGroup21.VALUE_2);
      this.handleOptionGroup137(OptionGroup137.VALUE_2);
      return (Container)this.getWidget4();
   }

   public Container getContainer3() {
      this.handleOptionGroup137(OptionGroup137.VALUE_3);
      return (Container)this.getWidget4();
   }

   public Container getContainer4() {
      if (this.optionGroup47 == OptionGroup47.VALUE_1) {
         this.handleOptionGroup137(OptionGroup137.VALUE_2);
      } else {
         this.handleOptionGroup21(OptionGroup21.VALUE_2);
      }

      return (Container)this.getWidget4();
   }

   public boolean isBooleanValue3() {
      return this.booleanValue;
   }

   public OptionGroup21 getOptionGroup21() {
      return this.optionGroup21;
   }

   public Container getContainer5() {
      if (this.booleanValue) {
         this.booleanValue = false;
         this.updateState12();
      }

      return (Container)this.getWidget4();
   }

   @Override
   public boolean testState10() {
      return !this.list2.isEmpty();
   }

   @Override
   public void updateState13() {
      super.updateState13();

      for (Widget var2 : (java.lang.Iterable<Widget>) (java.lang.Iterable<?>) (this.mutableChildren)) {
         var2.updateState13();
      }
   }

   public void handleWidget(Widget var1, boolean flag) {
      boolean flag2 = this.testState12();
      if (flag) {
         if (!this.list2.contains(var1)) {
            this.list2.add(var1);
         }
      } else {
         this.list2.remove(var1);
      }

      boolean flag3 = this.testState12();
      if (flag2 != flag3 && this.getContainer() != null) {
         this.getContainer().handleWidget(this, flag3);
      }
   }

   public NumericState134 getNumericState134() {
      return this.numericState134;
   }

   public Container getContainer6() {
      this.handleOptionGroup21(OptionGroup21.VALUE_1);
      return (Container)this.getWidget4();
   }

   public Container getContainer7() {
      if (!this.booleanValue) {
         this.booleanValue = true;
         this.updateState12();
      }

      return (Container)this.getWidget4();
   }

   public OptionGroup47 getOptionGroup47() {
      return this.optionGroup47;
   }

   public Container getContainer8() {
      this.handleOptionGroup137(OptionGroup137.VALUE_4);
      return (Container)this.getWidget4();
   }

   public Container getContainer9() {
      this.handleOptionGroup21(OptionGroup21.VALUE_4);
      return (Container)this.getWidget4();
   }

   public Container getContainer10() {
      if (this.optionGroup47 == OptionGroup47.VALUE_1) {
         this.handleOptionGroup21(OptionGroup21.VALUE_2);
      } else {
         this.handleOptionGroup137(OptionGroup137.VALUE_2);
      }

      return (Container)this.getWidget4();
   }

   public Container resolveContainer(Widget var1) {
      if (var1 == null) {
         return (Container)this.getWidget4();
      }

      if (this.mutableChildren.remove(var1)) {
         if (var1.testState12()) {
            this.handleWidget(var1, false);
         }

         var1.setContainer(null);
         this.updateState12();
      }

      return (Container)this.getWidget4();
   }

   public List getChildren() {
      return this.children;
   }

   public void handleOptionGroup137(OptionGroup137 optionGroup137) {
      if (this.optionGroup137 != optionGroup137) {
         this.optionGroup137 = optionGroup137;
         this.updateState12();
      }
   }

   public Container resolveContainer(float value, float value2) {
      this.handleNumericState134(NumericState134.resolveNumericState134(value, value2));
      return (Container)this.getWidget4();
   }

   public Container resolveContainer(float value, float value2, float value3, float value4) {
      this.handleNumericState134(NumericState134.resolveNumericState134(value, value2, value3, value4));
      return (Container)this.getWidget4();
   }

   public Container resolveContainer(float value) {
      this.handleNumericState134(NumericState134.resolveNumericState134(value));
      return (Container)this.getWidget4();
   }

   public List getList3() {
      List values = this.mutableChildren;
      List values2 = null;

      for (int index = 0; index < values.size(); index++) {
         Widget var4 = (Widget)values.get(index);
         if (var4.testState8()) {
            if (values2 != null) {
               values2.add(var4);
            }
         } else {
            var4.updateState13();
            if (values2 == null) {
               values2 = this.list;
               values2.clear();

               for (int index2 = 0; index2 < index; index2++) {
                  values2.add((Widget)values.get(index2));
               }
            }
         }
      }

      return values2 == null ? values : values2;
   }

   public NumericState238 resolveNumericState238(int index) {
      while (this.list3.size() <= index) {
         this.list3.add(new NumericState238());
      }

      return (NumericState238)this.list3.get(index);
   }

   public List getMutableChildren() {
      return this.mutableChildren;
   }

   public OptionGroup137 getOptionGroup137() {
      return this.optionGroup137;
   }

   public Container getContainer11() {
      this.handleOptionGroup21(OptionGroup21.VALUE_3);
      return (Container)this.getWidget4();
   }

   public void handleOptionGroup21(OptionGroup21 optionGroup21) {
      if (this.optionGroup21 != optionGroup21) {
         this.optionGroup21 = optionGroup21;
         this.updateState12();
      }
   }

   public Container getContainer12() {
      this.handleOptionGroup21(OptionGroup21.VALUE_2);
      return (Container)this.getWidget4();
   }

   public Container addChild(Supplier var1) {
      return this.addChild(var1 == null ? null : (Widget)var1.get());
   }

   public Container addChild(Widget var1) {
      if (var1 == null) {
         return (Container)this.getWidget4();
      }

      Container var2 = var1.getContainer();
      if (var2 == this) {
         this.mutableChildren.remove(var1);
      } else if (var2 != null) {
         var2.resolveContainer(var1);
      }

      var1.setContainer(this);
      this.mutableChildren.add(var1);
      if (var1.testState12()) {
         this.handleWidget(var1, true);
      }

      this.updateState12();
      return (Container)this.getWidget4();
   }

   public float getFloatValue3() {
      return this.floatValue;
   }

   public Container getContainer13() {
      this.handleOptionGroup137(OptionGroup137.VALUE_1);
      return (Container)this.getWidget4();
   }

   public Container getContainer14() {
      if (this.optionGroup47 != OptionGroup47.VALUE_1) {
         this.optionGroup47 = OptionGroup47.VALUE_1;
         this.updateState12();
      }

      return (Container)this.getWidget4();
   }

   public void handleNumericState134(NumericState134 numericState134) {
      if (!this.numericState134.equals(numericState134)) {
         this.numericState134 = numericState134;
         this.updateState12();
      }
   }

   public Container resolveContainer2(float floatValue) {
      if (Float.compare(this.floatValue, floatValue) != 0) {
         this.floatValue = floatValue;
         this.updateState12();
      }

      return (Container)this.getWidget4();
   }

   public Container getContainer15() {
      this.handleOptionGroup137(OptionGroup137.VALUE_2);
      return (Container)this.getWidget4();
   }

   public Container getContainer16() {
      if (this.optionGroup47 != OptionGroup47.VALUE_2) {
         this.optionGroup47 = OptionGroup47.VALUE_2;
         this.updateState12();
      }

      return (Container)this.getWidget4();
   }
}
