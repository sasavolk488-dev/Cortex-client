package clickgui.widgets;

import clickgui.ClickGuiPanel;
import clickgui.icons.Icon;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import modules.CategoryGroup;
import modules.ModuleCategory;
import net.minecraft.client.util.math.MatrixStack;
import render.ColorRGBA;
import settings.options.OptionGroup30;
import util.ClientUtils374;
import util.ClientUtils61;

public class CategorySidebar extends PanelWidget {
   public static final ColorRGBA colorRGBA = ClickGuiPanel.colorRGBA.getColorRGBA3().resolveColorRGBA6(0.0F);
   public final List list = new ArrayList();
   public final List list2 = new ArrayList();
   public final Supplier supplier;
   public final Consumer consumer;
   public final WidgetPart59 widgetPart59 = WidgetPart59.getWidgetPart59();
   public ModuleCategory moduleCategory = ModuleCategory.COMBAT;

   public CategorySidebar() {
      this(null, null);
   }

   public CategorySidebar(Supplier var1, Consumer var2) {
      this.supplier = var1 == null ? () -> this.moduleCategory : var1;
      this.consumer = var2 == null ? var1x -> this.moduleCategory = ((modules.ModuleCategory) (var1x)) : var2;
      this.getContainer16();
      this.getWidget10();
      this.resolveWidget2(72.0F);
      this.resolveContainer(16.0F, 16.0F, 16.0F, 16.0F);
      this.resolveContainer2(16.0F);
      this.getContainer13();
      this.resolvePanelWidget(OptionGroup30.VALUE_2);
      this.resolvePanelWidget(colorRGBA);
      this.resolveValue2(() -> ClientUtils374.getClientState270().getClientState4778());
      this.addChild(
         () -> {
            PanelWidget var0 = (PanelWidget)((PanelWidget)((PanelWidget)new WidgetPart22().getContainer2()).resolveWidget7(42.0F)).resolveContainer(6.0F);
            var0.addChild(
               (Widget)((WidgetPart42)WidgetPart42.resolveWidgetPart42(Icon.LOGO).getWidget6())
                  .resolveValue2(() -> ClientUtils374.getClientState270().getClientState47710())
            );
            return var0;
         }
      );
      PanelWidget var3 = (PanelWidget)((PanelWidget)((PanelWidget)((PanelWidget)PanelWidget.getPanelWidget4().getWidget()).getWidget8()).getContainer16())
         .resolveContainer2(8.0F);
      this.resolveWidgetPart34(CategoryGroup.MODULES, var3);
      if (testCategoryGroup(CategoryGroup.OTHERS)) {
         this.resolveWidgetPart46(CategoryGroup.OTHERS, var3);
      }

      ((WidgetPart59)((WidgetPart59)((WidgetPart59)((WidgetPart59)((WidgetPart59)((WidgetPart59)this.widgetPart59.resolveWidget2(48.0F)).getWidget10())
                     .getContainer16())
                  .getContainer8())
               .resolveContainer2(16.0F))
            .resolveContainer(0.0F, 0.0F, 8.0F, 0.0F))
         .resolveWidgetPart59(38.0F)
         .resolveWidgetPart593(2.0F)
         .resolveWidgetPart592(4.0F);
      this.widgetPart59.addChild(var3);
      this.resolveWidgetPart34(CategoryGroup.CLIENT, this.widgetPart59);
      this.addChild(this.widgetPart59);
   }

   public void updateState() {
      for (WidgetPart46 var2 : (java.lang.Iterable<WidgetPart46>) (java.lang.Iterable<?>) (this.list2)) {
         var2.updateState();
      }
   }

   public static boolean testCategoryGroup(CategoryGroup var0) {
      return ModuleCategory.resolveModuleCategoryArray2(var0).length > 0;
   }

   public WidgetPart46 resolveWidgetPart46(CategoryGroup var1) {
      return this.resolveWidgetPart46(var1, this);
   }

   public WidgetPart46 resolveWidgetPart46(CategoryGroup var1, Container var2) {
      WidgetPart46 var3 = new WidgetPart46(var1, this.supplier, this.consumer);
      this.list2.add(var3);
      var2.addChild(var3);
      return var3;
   }

   public boolean testFloat(float value, float value2, int index) {
      if (!this.widgetPart59.contains(value, value2)) {
         return false;
      }

      if (index == 0) {
         for (WidgetPart34 var5 : (java.lang.Iterable<WidgetPart34>) (java.lang.Iterable<?>) (this.list)) {
            if (var5.testFloat(value, value2, index)) {
               return true;
            }
         }
      }

      for (WidgetPart46 var7 : (java.lang.Iterable<WidgetPart46>) (java.lang.Iterable<?>) (this.list2)) {
         if (var7.testFloat(value, value2, index)) {
            return true;
         }
      }

      return false;
   }

   public void handleMatrixStack(MatrixStack matrices, Widget var2) {
      if (var2 instanceof WidgetPart34 var7) {
         var7.handleMatrixStack(matrices);
      } else if (var2 instanceof WidgetPart46 var6) {
         var6.handleMatrixStack(matrices);
      } else {
         if (var2 instanceof Container var3) {
            for (Widget var5 : (java.lang.Iterable<Widget>) (java.lang.Iterable<?>) (var3.getChildren())) {
               this.handleMatrixStack(matrices, var5);
            }
         }
      }
   }

   public void handleFloat(float value, float value2) {
      boolean flag = this.widgetPart59.contains(value, value2);

      for (WidgetPart34 var5 : (java.lang.Iterable<WidgetPart34>) (java.lang.Iterable<?>) (this.list)) {
         var5.handleFloat(value, value2, flag);
      }

      for (WidgetPart46 var7 : (java.lang.Iterable<WidgetPart46>) (java.lang.Iterable<?>) (this.list2)) {
         var7.handleFloat(value, value2, flag);
      }
   }

   public void handleMatrixStack2(MatrixStack matrices, Widget var2) {
      if (var2 instanceof WidgetPart34 var7) {
         var7.handleMatrixStack2(matrices);
      } else if (var2 instanceof WidgetPart46 var6) {
         var6.handleMatrixStack2(matrices);
      } else {
         if (var2 instanceof Container var3) {
            for (Widget var5 : (java.lang.Iterable<Widget>) (java.lang.Iterable<?>) (var3.getChildren())) {
               this.handleMatrixStack2(matrices, var5);
            }
         }
      }
   }

   @Override
   public void render(MatrixStack matrices) {
      this.updateState();
      this.resolveWidget(this.getX(), this.getY(), this.getWidth(), this.getHeight());
      ClientUtils61.resolveMatrixStackState4(matrices, this.getX(), this.getY(), this.getWidth(), this.getHeight())
         .withColorRGBA(colorRGBA)
         .resolveMatrixStackState4(ClientUtils374.getClientState270().getClientState4778());

      for (Widget var3 : (java.lang.Iterable<Widget>) (java.lang.Iterable<?>) (this.getChildren())) {
         if (var3 == this.widgetPart59) {
            this.handleMatrixStack2(matrices);
         } else {
            var3.render(matrices);
         }
      }
   }

   public WidgetPart34 resolveWidgetPart34(CategoryGroup var1, Container var2) {
      WidgetPart34 var3 = new WidgetPart34(var1, this.supplier, this.consumer);
      this.list.add(var3);
      var2.addChild(var3);
      return var3;
   }

   public WidgetPart34 resolveWidgetPart34(CategoryGroup var1) {
      return this.resolveWidgetPart34(var1, this);
   }

   public void handleMatrixStack2(MatrixStack matrices) {
      this.widgetPart59.handleMatrixStack(matrices, () -> {
         this.handleMatrixStack2(matrices, this.widgetPart59);
         this.handleMatrixStack(matrices, this.widgetPart59);
      });
      this.widgetPart59.handleMatrixStack2(matrices);
   }
}
