package clickgui.widgets;

import clickgui.ClickGuiPanel;
import clickgui.icons.Icon;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import modules.ModuleCategory;
import net.minecraft.client.util.math.MatrixStack;
import settings.options.OptionGroup104;
import settings.options.OptionGroup180;
import settings.options.OptionGroup30;
import util.ClientUtils374;

public class CategoryHeader extends PanelWidget {
   public final Supplier supplier;
   public final WidgetPart42 widgetPart42;
   public ModuleCategory moduleCategory;

   public CategoryHeader(Supplier var1, Supplier var2, Consumer var3, Supplier var4, Consumer var5) {
      this.supplier = var1 == null ? () -> ModuleCategory.COMBAT : var1;
      this.widgetPart42 = (WidgetPart42)WidgetPart42.resolveWidgetPart42(Icon.SWORDS)
         .resolveWidgetPart42(16.0F)
         .resolveValue2(() -> ClientUtils374.getClientState270().getClientState4776());
      this.getWidget();
      this.resolveWidget(74.0F);
      this.getContainer14();
      this.getContainer10();
      this.resolveContainer(16.0F);
      this.resolvePanelWidget(OptionGroup30.VALUE_2);
      this.resolvePanelWidget(ClickGuiPanel.colorRGBA.getColorRGBA3().resolveColorRGBA2(0.0F).withFloatValue(0.0F));
      this.resolveValue2(() -> ClientUtils374.getClientState270().getClientState4778());
      this.addChild(this.getPanelWidget());
      this.addChild(WidgetPart6.getWidgetPart62());
      PanelWidget var6 = (PanelWidget)((PanelWidget)((PanelWidget)((PanelWidget)PanelWidget.getPanelWidget4().getWidget2()).resolveWidget(40.0F))
            .getContainer14())
         .resolveContainer2(8.0F);
      if (var5 != null) {
         var6.addChild(resolvePanelWidget(new WidgetPart27(var4, var5), this::testState));
      }

      var6.addChild(resolvePanelWidget(new WidgetPart29(var2, var3), this::testState));
      this.addChild(var6);
   }

   public CategoryHeader(Supplier var1) {
      this(var1, null);
   }

   public CategoryHeader(Supplier var1, Consumer var2) {
      this(var1, () -> "", var2);
   }

   public CategoryHeader(Supplier var1, Supplier var2, Consumer var3) {
      this(var1, var2, var3, () -> OptionGroup104.VALUE_1, null);
   }

   public CategoryHeader() {
      this(() -> ModuleCategory.COMBAT, null);
   }

   public ModuleCategory getModuleCategory() {
      ModuleCategory var1 = (ModuleCategory)this.supplier.get();
      return var1 == null ? ModuleCategory.COMBAT : var1;
   }

   public static Icon resolveIcon(ModuleCategory var0) {
      Icon var1 = var0.getIcon();
      return var1 == null ? Icon.SWORDS : var1;
   }

   public String getText() {
      return this.getModuleCategory().getText2();
   }

   public static PanelWidget resolvePanelWidget(Widget var0, BooleanSupplier var1) {
      return new WidgetPart51(var0, var1);
   }

   public PanelWidget getPanelWidget() {
      PanelWidget var1 = (PanelWidget)((PanelWidget)((PanelWidget)((PanelWidget)((PanelWidget)((PanelWidget)PanelWidget.getPanelWidget4().getWidget2())
                     .resolveWidget(20.0F))
                  .getContainer14())
               .getContainer10())
            .resolveContainer(16.0F, 0.0F))
         .resolveContainer2(8.0F);
      var1.addChild(this.widgetPart42);
      var1.addChild(
         (Widget)WidgetPart11.resolveWidgetPart11(this::getText)
            .resolveWidgetPart11(OptionGroup180.SUISSE_INTL_REGULAR)
            .resolveWidgetPart11(16.0F)
            .resolveValue2(() -> ClientUtils374.getClientState270().getClientState4779())
      );
      return var1;
   }

   public void updateState() {
      ModuleCategory moduleCategory = this.getModuleCategory();
      if (moduleCategory != this.moduleCategory) {
         this.widgetPart42.withIcon(resolveIcon(moduleCategory));
         this.moduleCategory = moduleCategory;
      }
   }

   public boolean testState() {
      return this.getModuleCategory() != ModuleCategory.SETTINGS;
   }

   @Override
   public void render(MatrixStack matrices) {
      this.updateState();
      super.render(matrices);
   }
}
