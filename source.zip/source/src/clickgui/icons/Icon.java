package clickgui.icons;

import java.nio.charset.StandardCharsets;
import java.util.List;
import model.ClientState535;
import model.ClientState616;
import model.NumericState223;
import util.ClientUtils300;

public enum Icon {
   LOGO("logo"),
   SNAKE("snake"),
   VALUE_3("3dcube"),
   VALUE_4("3d-cube-scan"),
   COLORFILTER("colorfilter"),
   COLOR_SWATCH("color-swatch"),
   DOCUMENT_CODE("document-code"),
   EYE("eye"),
   KEYBOARD_OPEN("keyboard-open"),
   LOCATION("location"),
   PROFILE_2USER("profile-2user"),
   SETTING("setting"),
   USER("user"),
   USER_SQUARE("user-square"),
   WORLD("world"),
   LANG("lang"),
   SWORDS("swords"),
   GAME_PAD("game-pad"),
   FOLDER("folder"),
   CONFIG_FLODER("config-floder"),
   INDICATOR("indicator"),
   CHECK("check"),
   CROSS("cross"),
   SEARCH("search"),
   LOUPE("loupe"),
   MOVER("mover"),
   WIND("wind"),
   DRAGGER("dragger"),
   PEN("pen"),
   TRASH("trash"),
   SHARE("share"),
   REFRASH("refrash"),
   PLUS("plus"),
   PIN("pin"),
   SHIELD("shield"),
   MINECRAFT("minecraft"),
   ARROW_UP2("arrow-up2"),
   ARROW_UP3("arrow-up3"),
   ARROW_UP4("arrow-up4"),
   DIRECT_UP("direct-up"),
   DIRECT_UP_OUTLINE("direct-up-outline"),
   ARROW_UP_OUTLINE("arrow-up-outline"),
   ADD_CIRCLE("add-circle"),
   COLOR("color"),
   VOLUME_HIGH("volume-high"),
   VOLUME_SLASH("volume-slash"),
   MUSIC("music"),
   MUSICNOTE("musicnote"),
   SWAP_HORIZONTAL2("swap-horizontal2"),
   INFO_THORNS("info-thorns"),
   PERFOMANCE("perfomance"),
   REFRESH_ARROW2("refresh-arrow2"),
   COMMAND_SQUARE("command-square"),
   DOCUMENT_COPY("document-copy"),
   HEART_BEAT("heart-beat"),
   ERROR("error"),
   SUCCESS("success");

   public static final ClientState535 clientState535 = new ClientState535(new NumericState223(0.0, 0.0, 24.0, 24.0), List.of());
   public final String text;
   public volatile ClientState616 clientState616 = new ClientState616("", 0L);
   public volatile ClientState535 clientState5352;
   public volatile long longValue = -1L;

   private Icon(String text) {
      this.text = text;
   }

   public static Icon resolveIcon(String text, byte[] var1) {
      Icon var2 = resolveIcon(text);
      if (var2 != null && var1 != null) {
         var2.handleText(new String(var1, StandardCharsets.UTF_8));
         return var2;
      } else {
         return null;
      }
   }

   public static Icon resolveIcon(String text) {
      if (text != null && !text.isBlank()) {
         for (Icon var4 : values()) {
            if (var4.text.equals(text)) {
               return var4;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public synchronized void handleText(String text) {
      ClientState616 var2 = this.clientState616;
      if (!text.equals(var2.getText())) {
         this.clientState616 = new ClientState616(text, var2.getLongValue() + 1L);
         this.clientState5352 = null;
         this.longValue = -1L;
      }
   }

   public String getText() {
      return this.text;
   }

   public static String resolveText(String text) {
      Icon var1 = resolveIcon(text);
      return var1 == null ? "" : var1.getText2();
   }

   public ClientState535 getClientState535() {
      ClientState616 var1 = this.clientState616;
      if (var1.getText().isBlank()) {
         return clientState535;
      }

      ClientState535 var2 = this.clientState5352;
      if (var2 != null && this.longValue == var1.getLongValue()) {
         return var2;
      }

      synchronized (this) {
         var1 = this.clientState616;
         if (var1.getText().isBlank()) {
            return clientState535;
         }

         var2 = this.clientState5352;
         if (var2 != null && this.longValue == var1.getLongValue()) {
            return var2;
         }

         ClientState535 clientState5352 = ClientUtils300.resolveClientState535(var1.getText());
         this.clientState5352 = clientState5352;
         this.longValue = var1.getLongValue();
         return clientState5352;
      }
   }

   public String getText2() {
      return this.clientState616.getText();
   }

   public ClientState616 getClientState616() {
      return this.clientState616;
   }
}
