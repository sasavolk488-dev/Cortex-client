package clickgui;

import api.ClientContract34;
import api.ClientContract45;
import api.ClientContract50;
import clickgui.layout.PanelGeometry;
import clickgui.widgets.CategoryHeader;
import clickgui.widgets.CategorySidebar;
import clickgui.widgets.Container;
import clickgui.widgets.Page;
import clickgui.widgets.PageTransition;
import clickgui.widgets.PanelWidget;
import clickgui.widgets.Widget;
import clickgui.widgets.WidgetPart14;
import clickgui.widgets.WidgetPart32;
import clickgui.widgets.WidgetPart35;
import clickgui.widgets.WidgetPart54;
import clickgui.widgets.WidgetPart59;
import client.Cortex;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import model.ClientState7;
import modules.ModuleCategory;
import net.minecraft.client.util.math.MatrixStack;
import render.ColorRGBA;
import settings.ChangeListenerSource;
import settings.ChangeListeners;
import settings.ClientSettings;
import settings.options.OptionGroup104;
import settings.options.OptionGroup160;
import settings.options.OptionGroup30;
import util.ClientUtils307;
import util.ClientUtils71;

public class ClickGuiPanel extends PanelWidget implements ChangeListenerSource {
   public static final ColorRGBA colorRGBA = ColorRGBA.resolveColorRGBA9(16.0F);
   public static final PanelGeometry panelGeometry = PanelGeometry.resolvePanelGeometry2(42.0F);
   public final CategoryHeader categoryHeader;
   public final CategorySidebar categorySidebar;
   public final PanelWidget panelWidget;
   public final PageTransition pageTransition;
   public final Map map;
   public final WidgetPart54 widgetPart54;
   public final WidgetPart35 widgetPart35;
   public final WidgetPart32 widgetPart32;
   public final ClientState7 clientState7 = new ClientState7();
   public Page page;
   public ModuleCategory moduleCategory = ModuleCategory.COMBAT;
   public OptionGroup104 optionGroup104 = OptionGroup104.VALUE_1;
   public String text = "";
   public ClientContract34 clientContract34;
   public WidgetPart59 widgetPart59;
   public final List list = new ArrayList();
   public final ChangeListeners changeListeners = new ChangeListeners();
   public boolean booleanValue;

   public ClickGuiPanel() {
      this(getClientSettings());
   }

   public ClickGuiPanel(ClientSettings var1) {
      this.categoryHeader = new CategoryHeader(
         () -> this.moduleCategory, () -> this.text, (argument0) -> this.handleText((java.lang.String) argument0), () -> this.optionGroup104, (argument0) -> this.handleOptionGroup104((settings.options.OptionGroup104) argument0)
      );
      this.categorySidebar = new CategorySidebar(() -> this.moduleCategory, (argument0) -> this.handleModuleCategory((modules.ModuleCategory) argument0));
      this.panelWidget = (PanelWidget)((PanelWidget)PanelWidget.getPanelWidget4().getWidget6()).getContainer16();
      this.pageTransition = new PageTransition();
      this.map = getMap2();
      this.widgetPart54 = new WidgetPart54();
      this.widgetPart35 = new WidgetPart35();
      this.widgetPart32 = new WidgetPart32(var1);
      this.resolveWidget3(992.0F, 700.0F);
      this.resolvePanelWidget(OptionGroup30.VALUE_2);
      this.resolvePanelWidget(colorRGBA);
      this.withGeometry(panelGeometry);
      this.addChild(this.categorySidebar);
      this.panelWidget.addChild(this.categoryHeader);
      this.page = this.resolvePage(this.moduleCategory);
      this.pageTransition.handlePage(this.page);
      this.panelWidget.addChild(this.pageTransition);
      this.addChild(this.panelWidget);
   }

   public boolean testClientContract34(ClientContract34 var1, ClientContract34 var2) {
      return !this.testClientContract342(var1) ? var1.testState13() : this.testClientContract342(var1, var2) || !var1.testState2();
   }

   public CategorySidebar getCategorySidebar() {
      return this.categorySidebar;
   }

   public void handleOptionGroup104(OptionGroup104 var1) {
      OptionGroup104 optionGroup104 = var1 == null ? OptionGroup104.VALUE_1 : var1;
      if (optionGroup104 != this.optionGroup104) {
         this.optionGroup104 = optionGroup104;

         for (WidgetPart14 var4 : (java.lang.Iterable<WidgetPart14>) (java.lang.Iterable<?>) (this.map.values())) {
            var4.handleOptionGroup104(optionGroup104);
         }

         this.widgetPart54.handleOptionGroup104(optionGroup104);
         this.widgetPart35.handleOptionGroup104(optionGroup104);
         this.changeListeners.updateState();
      }
   }

   public boolean testInt(int index, int index2) {
      return this.testClientContract50(var2x -> var2x.testState2() && var2x.testInt2(index, index2))
         ? true
         : this.testClientContract50(var2x -> !var2x.testState2() && var2x.testInt2(index, index2));
   }

   public boolean testInt(int index) {
      return this.testInt(index, 1);
   }

   public void updateState() {
      WidgetPart14 var1 = this.page instanceof WidgetPart14 var2 ? var2 : null;

      for (WidgetPart14 var5 : (java.lang.Iterable<WidgetPart14>) (java.lang.Iterable<?>) (this.map.values())) {
         if (var5 != var1) {
            var5.updateState();
         }
      }

      if (var1 != null) {
         var1.updateState();
      }
   }

   public boolean testFloat(float value, float value2, double value3) {
      ClientContract34 var5 = this.getClientContract343();
      boolean flag = false;
      if (var5 != null) {
         float value4 = this.calculateFloat(var5, value2);
         flag = var5.testState2();
         if ((flag || var5.testFloat5(value, value4)) && var5.testFloat(value, value4, value3)) {
            return true;
         }
      }

      if (!flag) {
         ClientContract34 var8 = this.resolveClientContract34(value, value2, var5);
         if (var8 != null && var8.testFloat(value, this.calculateFloat(var8, value2), value3)) {
            return true;
         }
      }

      return this.testClientContract50(var4 -> var4.testState2() && var4.testFloat(value, value2, value3))
         ? true
         : this.testClientContract45(var4 -> var4.testFloat(value, value2, value3));
   }

   public boolean testInt2(int index, int index2) {
      return this.testClientContract50(var2x -> var2x.testState2() && var2x.testInt(index, index2));
   }

   public void handleFloat(float value, float value2) {
      ClientContract34 var3 = this.resolveClientContract34(value, value2, null);
      if (var3 != null) {
         this.handleFloat(this.getX() - 1.0F, this.getY() - 1.0F, true);
         this.handleFloat2(value, value2);
      } else {
         this.handleFloat(value, value2, false);
         this.handleFloat2(value, value2);
      }
   }

   public void handleFloat(float value, float value2, float value3, float value4) {
      this.testClientContract50(var5 -> {
         var5.handleFloat2(value, value2, value3, value4);
         var5.handleFloat(this.getX(), this.getY(), this.getWidth(), this.getHeight());
         return false;
      });
   }

   public boolean testClientContract342(ClientContract34 var1, ClientContract34 var2) {
      return this.testClientContract342(var1) && (var1 == var2 || var1.testState13());
   }

   public ClientContract34 getClientContract34() {
      for (int index = this.list.size() - 1; index >= 0; index--) {
         ClientContract34 var2 = (ClientContract34)this.list.get(index);
         if (this.testClientContract34(var2)) {
            return var2;
         }
      }

      return null;
   }

   public static void handleMatrixStack(MatrixStack matrices, float value, float value2, float value3, float value4, float value5) {
      ClientUtils307.handleMatrixStack(matrices, value, value2, value3, value4, value5);
   }

   public static void handleMatrixStack(MatrixStack matrices, float value, float value2, float value3, float value4) {
      handleMatrixStack(matrices, value, value2, value3, value4, 1.0F);
   }

   public boolean testClientContract34(ClientContract34 var1) {
      return var1.testState5() && this.testClientContract342(var1);
   }

   public static int calculateInt(ModuleCategory var0, ModuleCategory var1) {
      if (var0 != null && var1 != null) {
         return var1.ordinal() >= var0.ordinal() ? 1 : -1;
      } else {
         return 1;
      }
   }

   public ClientContract34 resolveClientContract34(float value, float value2, ClientContract34 var3) {
      this.updateState6();
      ClientContract34 var4 = this.getClientContract34();

      for (int index = this.list.size() - 1; index >= 0; index--) {
         ClientContract34 var6 = (ClientContract34)this.list.get(index);
         if (var6 != var3 && this.testClientContract342(var6, var4) && var6.testFloat5(value, this.calculateFloat(var6, value2))) {
            return var6;
         }
      }

      return null;
   }

   public String getText() {
      return this.text;
   }

   public void handleClientContract34(ClientContract34 var1) {
      if (var1.testState5()) {
         this.handleClientContract343(var1);
         this.booleanValue = false;
      } else {
         this.handleClientContract344(var1);
      }
   }

   public boolean testClientContract342(ClientContract34 var1) {
      if (var1 instanceof Widget var2) {
         for (Container var3 = var2.getContainer(); var3 != null; var3 = var3.getContainer()) {
            if (var3 == this) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   public void updateState2() {
      for (int index = this.list.size() - 1; index >= 0; index--) {
         if (!((ClientContract34)this.list.get(index)).testState5()) {
            this.list.remove(index);
         }
      }
   }

   public void updateState3() {
      this.clientContract34 = null;
      this.widgetPart59 = null;
   }

   public void handleModuleCategory(ModuleCategory var1) {
      if (var1 != null) {
         if (var1 != this.moduleCategory) {
            ModuleCategory var2 = this.moduleCategory;
            this.clientState7.handleModuleCategory(var2);
            this.handleModuleCategory(var1, calculateInt(var2, var1));
         }
      }
   }

   public Map getMap() {
      return this.map;
   }

   public int calculateInt(MatrixStack matrices, ClientContract34 var2) {
      if (var2 instanceof Widget var3) {
         int index = 0;

         for (Container var5 = var3.getContainer(); var5 != null; var5 = var5.getContainer()) {
            if (var5 instanceof WidgetPart59 var6) {
               handleMatrixStack(matrices, var6.getX(), var6.getY(), var6.getWidth(), var6.getHeight());
               index++;
            }
         }

         return index;
      } else {
         return 0;
      }
   }

   public void updateState4() {
      for (int index = 0; index < this.list.size(); index++) {
         ClientContract34 var2 = (ClientContract34)this.list.get(index);
         var2.handleBoolean2(this.testClientContract342(var2));
      }
   }

   public boolean testWidget(Widget var1, ClientContract45 var2) {
      return ClientUtils71.testWidget(var1, var2);
   }

   public boolean testClientContract45(ClientContract45 var1) {
      return ClientUtils71.testWidget(this, var1);
   }

   public boolean testWidgetPart59(WidgetPart59 widgetPart59, float value, float value2) {
      if (!widgetPart59.testFloat4(value, value2)) {
         return false;
      }

      if (widgetPart59.isBooleanValue()) {
         this.widgetPart59 = widgetPart59;
      }

      return true;
   }

   public float calculateFloat(ClientContract34 var1, float value) {
      return value - this.calculateFloat2(var1);
   }

   public void handleClientContract342(ClientContract34 var1) {
      for (int index = 0; index < this.list.size(); index++) {
         ClientContract34 var3 = (ClientContract34)this.list.get(index);
         if (var3 != var1 && !var3.testState13()) {
            var3.updateState();
         }
      }

      this.updateState2();
   }

   public void updateState5() {
      this.updateState3();

      for (int index = this.list.size() - 1; index >= 0; index--) {
         ClientContract34 var2 = (ClientContract34)this.list.get(index);
         if (!var2.testState5()) {
            this.list.remove(index);
         } else {
            var2.handleBoolean2(false);
            var2.updateState();
            if (!var2.testState13()) {
               this.list.remove(index);
            }
         }
      }

      this.booleanValue = true;
   }

   public List getList() {
      return this.list;
   }

   public ModuleCategory getModuleCategory() {
      return this.moduleCategory;
   }

   public CategoryHeader getCategoryHeader() {
      return this.categoryHeader;
   }

   public static void handleClientContract34(ClientContract34 var0, float value, float value2, List values) {
      if (!values.contains(var0)) {
         values.add(var0);
         var0.handleFloat3(value, value2);
      }
   }

   public WidgetPart54 getWidgetPart54() {
      return this.widgetPart54;
   }

   public void handleFloat(float value, float value2, boolean flag) {
      this.testWidget(this.categorySidebar, (api.ClientContract45) var2x -> {
         var2x.handleFloat(value, value2);
         return false;
      });
      this.testWidget(this.categoryHeader, (api.ClientContract50) var2x -> {
         var2x.handleFloat2(value, value2);
         return false;
      });
      if (this.page != null) {
         this.page.handleFloat(value, value2);
         if (flag) {
            ClientUtils71.testWidget3(this.page, var2x -> {
               var2x.handleFloat2(value, value2);
               return false;
            });
         }
      }

      this.categorySidebar.handleFloat(value, value2);
   }

   public WidgetPart59 getWidgetPart59() {
      return this.widgetPart59;
   }

   public ChangeListeners getChangeListeners() {
      return this.changeListeners;
   }

   public WidgetPart35 getWidgetPart35() {
      return this.widgetPart35;
   }

   public void handleClientContract50(ClientContract50 var1) {
      this.testClientContract50(var1);

      for (WidgetPart14 var3 : (java.lang.Iterable<WidgetPart14>) (java.lang.Iterable<?>) (this.map.values())) {
         this.testWidget(var3, var1);
      }

      this.testWidget(this.widgetPart54, var1);
      this.testWidget(this.widgetPart35, var1);
      this.testWidget(this.widgetPart32, var1);
   }

   public static ClientSettings getClientSettings() {
      ClientSettings var0 = Cortex.instance.getClientSettings();
      return var0 == null ? new ClientSettings() : var0;
   }

   @Override
   public boolean testState7() {
      return super.testState7() ? true : this.page != null && this.page.testState7();
   }

   public boolean testFloat(float value, float value2) {
      return this.resolveClientContract34(value, value2, null) != null;
   }

   public int calculateInt(float value, float value2) {
      this.updateState6();
      ClientContract34 var3 = this.getClientContract34();

      for (int index = this.list.size() - 1; index >= 0; index--) {
         ClientContract34 var5 = (ClientContract34)this.list.get(index);
         if (this.testClientContract342(var5, var3)) {
            int index2 = var5.calculateInt(value, this.calculateFloat(var5, value2));
            if (index2 != 0) {
               return index2;
            }
         }
      }

      int[] var7 = new int[]{0};
      this.testClientContract50(var3x -> {
         var7[0] = var3x.calculateInt(value, value2);
         return var7[0] != 0;
      });
      return var7[0];
   }

   public boolean testFloat2(float value, float value2) {
      if (this.clientContract34 != null) {
         if (this.clientContract34.testFloat3(value, value2 - this.calculateFloat2(this.clientContract34))) {
            return true;
         }

         if (!this.clientContract34.testState2()) {
            this.clientContract34 = null;
         }
      }

      if (this.widgetPart59 != null) {
         if (this.widgetPart59.testFloat5(value, value2)) {
            return true;
         }

         if (!this.widgetPart59.isBooleanValue()) {
            this.widgetPart59 = null;
         }
      }

      return false;
   }

   public void updateState6() {
      this.updateState2();
      if (!this.booleanValue) {
         this.updateState4();
      } else {
         this.booleanValue = false;
         ArrayList values = new ArrayList();
         this.testClientContract50(var2x -> {
            if (!var2x.testState5()) {
               return false;
            }

            if (!this.list.contains(var2x)) {
               values.add(var2x);
            }

            return false;
         });

         for (int index = values.size() - 1; index >= 0; index--) {
            this.handleClientContract343((ClientContract34)values.get(index));
         }

         this.updateState2();
         this.updateState4();
      }
   }

   public float calculateFloat(ClientContract34 var1) {
      if (var1 instanceof Widget var2) {
         float value = 0.0F;

         for (Container var4 = var2.getContainer(); var4 != null; var4 = var4.getContainer()) {
            if (var4 instanceof WidgetPart59 var5) {
               value += var5.getFloat10();
            }
         }

         return value;
      } else {
         return 0.0F;
      }
   }

   public void handleText(String text) {
      String text2 = text == null ? "" : text;
      if (!text2.equals(this.text)) {
         this.text = text2;
         this.handlePage(this.page);
      }
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public Page resolvePage(ModuleCategory var1) {
      WidgetPart14 var2 = (WidgetPart14)this.map.get(var1);
      if (var2 != null) {
         var2.handleText(this.text);
         var2.updateState();
         return var2;
      }

      return switch (var1) {
         case FRIENDS -> this.widgetPart54;
         case CONFIGS -> this.widgetPart35;
         case SETTINGS -> this.widgetPart32;
         default -> null;
      };
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public static boolean testModuleCategory(ModuleCategory var0) {
      return switch (var0) {
         case FRIENDS, CONFIGS, SETTINGS -> true;
         default -> false;
      };
   }

   public float calculateFloat2(ClientContract34 var1) {
      return var1 != null && var1.testState6() ? this.calculateFloat(var1) : 0.0F;
   }

   public boolean testClientContract34(ClientContract34 clientContract34, float value, float value2, int index) {
      if (!clientContract34.testFloat(value, value2, index)) {
         return false;
      }

      if (index == 0 && clientContract34.testState3()) {
         this.clientContract34 = clientContract34;
      }

      this.handleClientContract34(clientContract34);
      this.booleanValue = true;
      return true;
   }

   public void handleClientContract343(ClientContract34 var1) {
      this.handleClientContract342(var1);
      this.list.remove(var1);
      this.list.add(var1);
   }

   public boolean testClientContract50(ClientContract50 var1) {
      return ClientUtils71.testWidget3(this, var1);
   }

   public boolean testWidget(Widget var1, ClientContract50 var2) {
      return ClientUtils71.testWidget3(var1, var2);
   }

   public void handleMatrixStack(MatrixStack matrices, ClientContract34 var2) {
      int index = var2.testState4() ? this.calculateInt(matrices, var2) : 0;

      try {
         float value = this.calculateFloat2(var2);
         if (!(Math.abs(value) <= 0.01F)) {
            matrices.push();

            try {
               matrices.translate(0.0F, value, 0.0F);
               var2.handleMatrixStack(matrices);
               return;
            } finally {
               matrices.pop();
            }
         }

         var2.handleMatrixStack(matrices);
      } finally {
         handleInt(index);
      }
   }

   public boolean isBooleanValue() {
      return this.booleanValue;
   }

   public Page getPage() {
      return this.page;
   }

   public static void handleInt(int index) {
      for (int index2 = 0; index2 < index; index2++) {
         ClientUtils307.updateState2();
      }
   }

   public ClientContract34 getClientContract342() {
      return this.clientContract34;
   }

   public void handlePage(Page var1) {
      if (var1 instanceof WidgetPart14 var2) {
         var2.handleText(this.text);
      }
   }

   public boolean testInt2(int index) {
      if (index == 3) {
         this.testState();
         return true;
      } else if (index == 4) {
         this.testState2();
         return true;
      } else {
         return false;
      }
   }

   public boolean testState() {
      ModuleCategory var1 = this.clientState7.resolveModuleCategory(this.moduleCategory);
      if (var1 == null) {
         return false;
      }

      this.handleModuleCategory(var1, -1);
      return true;
   }

   public PageTransition getPageTransition() {
      return this.pageTransition;
   }

   public void handleFloat2(float value, float value2) {
      this.updateState6();
      ClientContract34 var3 = this.getClientContract34();

      for (int index = this.list.size() - 1; index >= 0; index--) {
         ClientContract34 var5 = (ClientContract34)this.list.get(index);
         if (this.testClientContract342(var5, var3)) {
            var5.handleFloat2(value, this.calculateFloat(var5, value2));
         }
      }
   }

   public PanelWidget getPanelWidget() {
      return this.panelWidget;
   }

   public void updateState7() {
      this.updateState3();
      this.list.clear();
      this.booleanValue = false;
      this.testClientContract50(var0 -> {
         var0.updateState();
         return false;
      });
      this.booleanValue = true;
      if (this.page != null) {
         this.page.testFloat(Float.NaN, Float.NaN);
      }
   }

   public ClientContract34 getClientContract343() {
      this.updateState6();

      for (int index = this.list.size() - 1; index >= 0; index--) {
         ClientContract34 var2 = (ClientContract34)this.list.get(index);
         if (this.testClientContract34(var2)) {
            return var2;
         }
      }

      return null;
   }

   public OptionGroup104 getOptionGroup1042() {
      return this.optionGroup104;
   }

   @Override
   public void render(MatrixStack matrices) {
      this.handleMatrixStack2(matrices);
      this.handleMatrixStack(matrices);
   }

   public void handleClientContract344(ClientContract34 var1) {
      this.list.remove(var1);
   }

   @Override
   public void addChangeListener(Runnable var1) {
      this.changeListeners.addChangeListener(var1);
   }

   public boolean testState2() {
      ModuleCategory var1 = this.clientState7.resolveModuleCategory2(this.moduleCategory);
      if (var1 == null) {
         return false;
      }

      this.handleModuleCategory(var1, 1);
      return true;
   }

   public boolean testState3() {
      this.updateState6();

      for (int index = this.list.size() - 1; index >= 0; index--) {
         ClientContract34 var2 = (ClientContract34)this.list.get(index);
         if (this.testClientContract34(var2) && var2.testState2()) {
            return true;
         }
      }

      return this.testClientContract50(ClientContract34::testState2);
   }

   public boolean testFloat(float value, float value2, int index) {
      if (index == 0) {
         this.updateState3();
      }

      ClientContract34 var4 = this.getClientContract343();
      boolean flag = false;
      if (var4 != null) {
         float value3 = this.calculateFloat(var4, value2);
         flag = var4.testState2();
         if ((flag || var4.testFloat5(value, value3)) && this.testClientContract34(var4, value, value3, index)) {
            return true;
         }
      }

      if (!flag) {
         ClientContract34 var7 = this.resolveClientContract34(value, value2, var4);
         if (var7 != null && this.testClientContract34(var7, value, this.calculateFloat(var7, value2), index)) {
            return true;
         }
      }

      if (this.testClientContract50(var4x -> var4x.testState2() && this.testClientContract34(var4x, value, value2, index))) {
         return true;
      }

      if (this.testInt2(index)) {
         return true;
      }

      if (this.testClientContract50(var4x -> !var4x.testState2() && this.testClientContract34(var4x, value, value2, index))) {
         return true;
      }

      if (index == 0 && this.testClientContract45(var3x -> this.testWidgetPart59(var3x, value, value2))) {
         return true;
      }

      if (this.page != null && this.page.testFloat(value, value2, index)) {
         this.booleanValue = true;
         return true;
      }

      boolean flag2 = this.categorySidebar.testFloat(value, value2, index);
      if (flag2) {
         this.booleanValue = true;
      }

      return flag2;
   }

   public void handlePage(Page page, int index) {
      if (page != null && page != this.page) {
         this.page = page;
         this.pageTransition.handlePage(page, index);
         this.handlePage(page);
         this.booleanValue = true;
      } else {
         this.pageTransition.handleInt(index);
      }
   }

   public WidgetPart32 getWidgetPart32() {
      return this.widgetPart32;
   }

   public static Map getMap2() {
      EnumMap var0 = new EnumMap<>(ModuleCategory.class);

      for (ModuleCategory var4 : ModuleCategory.values()) {
         if (var4.testState() && !testModuleCategory(var4)) {
            var0.put(var4, new WidgetPart14(var4));
         }
      }

      return var0;
   }

   public void handleModuleCategory(ModuleCategory moduleCategory, int index) {
      this.moduleCategory = moduleCategory;
      OptionGroup160.SWITCHCATEGORY.updateState();
      this.handleText("");
      this.updateState5();
      this.handlePage(this.resolvePage(moduleCategory), index);
   }

   public void handleMatrixStack(MatrixStack matrices) {
      this.updateState6();
      ClientContract34 var2 = this.getClientContract34();

      for (int index = 0; index < this.list.size(); index++) {
         ClientContract34 var4 = (ClientContract34)this.list.get(index);
         if (var4.testState5() && this.testClientContract34(var4, var2)) {
            this.handleMatrixStack(matrices, var4);
         }
      }

      this.updateState2();
   }

   public void handleFloat3(float value, float value2) {
      if (value != 0.0F || value2 != 0.0F) {
         this.updateState6();
         ArrayList values = new ArrayList();
         this.handleClientContract50(var3x -> {
            if (var3x.testState5()) {
               handleClientContract34(var3x, value, value2, values);
            }

            return false;
         });
      }
   }

   public void handleMatrixStack2(MatrixStack matrices) {
      super.render(matrices);
   }

   public boolean testFloat2(float value, float value2, int index) {
      if (index == 0 && this.clientContract34 != null) {
         ClientContract34 var4 = this.clientContract34;
         this.clientContract34 = null;
         if (var4.testFloat2(value, value2 - this.calculateFloat2(var4), index)) {
            return true;
         }
      }

      if (index == 0 && this.widgetPart59 != null) {
         WidgetPart59 var5 = this.widgetPart59;
         this.widgetPart59 = null;
         if (var5.testFloat7(value, value2)) {
            return true;
         }
      }

      if (this.testClientContract50(var3x -> var3x.testState2() && var3x.testFloat2(value, value2, index))) {
         return true;
      } else if (index != 0) {
         return false;
      } else {
         return this.testClientContract45(var2x -> var2x.testFloat7(value, value2)) ? true : this.page != null && this.page.testFloat(value, value2);
      }
   }

   public boolean testFloat3(float value, float value2) {
      return this.testFloat2(value, value2, 0);
   }
}
