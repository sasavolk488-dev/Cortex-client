package clickgui.layout;

import model.ClientState477;

public final class PanelGeometry {
   private float floatValue;
   private float floatValue2;
   private float floatValue3;
   private float floatValue4;
   private ClientState477 clientState477;

   private PanelGeometry(float value, float value2, float value3, ClientState477 var4) {
      this.floatValue = Math.max(0.0F, value);
      this.floatValue2 = Math.max(0.0F, value2);
      this.floatValue3 = Math.max(0.0F, value3);
      this.floatValue4 = 1.92F;
      this.clientState477 = var4 == null ? getClientState4772() : var4;
   }

   public float getFloatValue() {
      return this.floatValue;
   }

   public ClientState477 getClientState477() {
      return this.clientState477;
   }

   public float getFloatValue2() {
      return this.floatValue2;
   }

   public float getFloatValue3() {
      return this.floatValue3;
   }

   public boolean testState() {
      return this.floatValue > 0.0F && this.floatValue2 > 0.0F && this.clientState477 != null && this.clientState477.getIntValue5() > 0;
   }

   public PanelGeometry resolvePanelGeometry(float value) {
      this.floatValue2 = Math.max(0.0F, value);
      return this;
   }

   private static ClientState477 getClientState4772() {
      return ClientState477.resolveClientState4774(855638016);
   }

   public static PanelGeometry resolvePanelGeometry2(float value) {
      return new PanelGeometry(value, 1.0F, 0.0F, getClientState4772());
   }

   public static PanelGeometry getPanelGeometry() {
      return resolvePanelGeometry2(40.0F);
   }

   public float getFloatValue4() {
      return this.floatValue4;
   }

   public PanelGeometry resolvePanelGeometry3(float value) {
      this.floatValue = Math.max(0.0F, value);
      return this;
   }

   public PanelGeometry resolvePanelGeometry4(float value) {
      this.floatValue3 = Math.max(0.0F, value);
      return this;
   }

   public PanelGeometry resolvePanelGeometry5(float value) {
      this.floatValue4 = Math.max(0.01F, value);
      return this;
   }

   public PanelGeometry resolvePanelGeometry(ClientState477 var1) {
      this.clientState477 = var1 == null ? getClientState4772() : var1;
      return this;
   }
}
