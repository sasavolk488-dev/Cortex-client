package clickgui.layout;

public abstract class Bounds {
   private float x;
   private float y;
   private float width;
   private float height;

   public Bounds setY(float y) {
      this.y = y;
      return this;
   }

   public float getHeight() {
      return this.height;
   }

   public float getX() {
      return this.x;
   }

   public float getWidth() {
      return this.width;
   }

   public Bounds setPosition(float x, float y) {
      this.x = x;
      this.y = y;
      return this;
   }

   public float getY() {
      return this.y;
   }

   public Bounds setWidth(float width) {
      this.width = width;
      return this;
   }

   public boolean contains(float value, float value2) {
      return value >= this.x && value < this.x + this.width && value2 >= this.y && value2 < this.y + this.height;
   }

   public Bounds setSize(float width, float height) {
      this.width = width;
      this.height = height;
      return this;
   }

   public Bounds setX(float x) {
      this.x = x;
      return this;
   }

   public Bounds setHeight(float height) {
      this.height = height;
      return this;
   }
}
