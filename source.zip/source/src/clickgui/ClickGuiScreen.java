package clickgui;

import api.ClientContract54;
import clickgui.widgets.WidgetPart54;
import client.Cortex;
import client.RenderCallback;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import events.CharInputEvent;
import events.KeyEvent;
import events.MinecraftClientEvent3;
import events.MouseButtonEvent;
import events.MouseDragEvent;
import events.MouseScrollEvent;
import events.Render2DEvent;
import events.Subscribe;
import java.util.ArrayList;
import model.ClientState280;
import model.NumericState147;
import model.WindowState1;
import modules.CategoryGroup;
import modules.Module;
import modules.ModuleCategory;
import modules.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import render.ColorRGBA;
import render.MatrixTransforms;
import runtime.RecoveredMouseControl;
import settings.ChangeListenerSource;
import settings.ChangeListeners;
import settings.ClientSettings;
import settings.JsonSerializable;
import settings.options.OptionGroup104;
import settings.options.OptionGroup160;
import util.ClientUtils209;
import util.ClientUtils284;
import util.ClientUtils306;


public class ClickGuiScreen extends Screen implements JsonSerializable, ChangeListenerSource, RenderCallback {
   public static String text = "moduleOrder";
   public static String text2 = "layoutMode";
   public static String text3 = "left";
   public static String text4 = "right";
   public static final long LONG_CONSTANT = 420L;
   public final ClickGuiPanel panel = new ClickGuiPanel();
   public float floatValue = 100.0F;
   public float floatValue2 = 100.0F;
   public float floatValue3 = 992.0F;
   public float floatValue4 = 700.0F;
   public boolean booleanValue;
   public int intValue = 0;
   public float floatValue5;
   public float floatValue6;
   public float floatValue7;
   public float floatValue8;
   public float floatValue9;
   public float floatValue10;
   public long longValue = Long.MIN_VALUE;
   public long longValue2;
   public long longValue3;
   public long longValue4;
   public long longValue5;
   public long longValue6;
   public long longValue7;
   public boolean booleanValue2 = true;
   public boolean booleanValue3 = true;
   public float floatValue11 = Float.NaN;
   public float floatValue12 = Float.NaN;
   public float floatValue13 = Float.NaN;
   public float floatValue14 = Float.NaN;
   public float floatValue15 = Float.NaN;
   public float floatValue16 = Float.NaN;
   public float floatValue17 = Float.NaN;
   public float floatValue18 = Float.NaN;
   public long longValue8;
   public float floatValue19 = Float.NaN;
   public float floatValue20 = Float.NaN;
   public int intValue2 = 0;
   public boolean booleanValue4 = true;
   public final ClientUtils209 clientUtils209 = ClientUtils209.resolveClientUtils209(ClientUtils284.clientContract5412);
   public final ChangeListeners changeListeners = new ChangeListeners();

   public ClickGuiScreen() {
      super(Text.empty());
      this.panel.addChangeListener(this.changeListeners::updateState);
      ModuleManager var1 = Cortex.getInstance().getModuleManager();
      if (var1 != null) {
         var1.moduleOrderMutationSource().addChangeListener(this.changeListeners::updateState);
      }
   }

   public boolean testFloat(float value, float value2) {
      return !this.booleanValue2
         && Float.compare(value, this.floatValue11) == 0
         && Float.compare(value2, this.floatValue12) == 0
         && Float.compare(this.floatValue3, this.floatValue15) == 0
         && Float.compare(this.floatValue4, this.floatValue16) == 0;
   }

   public boolean testState() {
      float floatValue11 = this.getFloat2();
      float floatValue12 = this.getFloat5();
      float value = calculateFloat(floatValue11, 720.0F);
      float value2 = calculateFloat(floatValue12, 480.0F);
      float value3 = calculateFloat(floatValue11, value, 720.0F, 1400.0F);
      float value4 = calculateFloat(floatValue12, value2, 480.0F, 900.0F);
      float floatValue3 = this.calculateFloat3(this.floatValue3, 720.0F, value3);
      float floatValue4 = this.calculateFloat3(this.floatValue4, 480.0F, value4);
      float floatValue = this.calculateFloat3(this.floatValue, value, Math.max(value, floatValue11 - value - floatValue3));
      float floatValue2 = this.calculateFloat3(this.floatValue2, value2, Math.max(value2, floatValue12 - value2 - floatValue4));
      boolean flag = Float.compare(this.floatValue, floatValue) != 0
         || Float.compare(this.floatValue2, floatValue2) != 0
         || Float.compare(this.floatValue3, floatValue3) != 0
         || Float.compare(this.floatValue4, floatValue4) != 0;
      float value5 = this.floatValue13;
      float value6 = this.floatValue14;
      boolean flag2 = this.testState3();
      boolean flag3 = this.booleanValue2
         || Float.compare(floatValue11, this.floatValue11) != 0
         || Float.compare(floatValue12, this.floatValue12) != 0
         || !flag2 && Float.compare(floatValue, this.floatValue13) != 0
         || !flag2 && Float.compare(floatValue2, this.floatValue14) != 0
         || Float.compare(floatValue3, this.floatValue15) != 0
         || Float.compare(floatValue4, this.floatValue16) != 0
         || this.panel.testState7();
      this.floatValue3 = floatValue3;
      this.floatValue4 = floatValue4;
      this.floatValue = floatValue;
      this.floatValue2 = floatValue2;
      if (!this.booleanValue && flag) {
         this.changeListeners.updateState();
      }

      if (!flag3) {
         return false;
      }

      this.panel.resolveWidget3(this.floatValue3, this.floatValue4);
      this.panel.resolveWidget(this.floatValue, this.floatValue2);
      this.panel.handleFloat(0.0F, 0.0F, floatValue11, floatValue12);
      if (testFloat(value5, value6, this.floatValue, this.floatValue2)) {
         this.panel.handleFloat3(this.floatValue - value5, this.floatValue2 - value6);
      }

      this.floatValue11 = floatValue11;
      this.floatValue12 = floatValue12;
      this.floatValue13 = this.floatValue;
      this.floatValue14 = this.floatValue2;
      this.floatValue15 = this.floatValue3;
      this.floatValue16 = this.floatValue4;
      this.booleanValue2 = false;
      return true;
   }

   public static Float resolveFloat(JsonElement element) {
      return element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber() ? element.getAsFloat() : null;
   }

   public float calculateFloat(float value) {
      return value / this.getFloat4();
   }

   public void handleJson(JsonElement element) {
      if (element instanceof JsonObject json) {
         ModuleManager var3 = Cortex.getInstance().getModuleManager();
         if (var3 != null) {
            boolean flag = false;

            for (ModuleCategory var8 : ModuleCategory.resolveModuleCategoryArray(CategoryGroup.MODULES)) {
               JsonElement element2 = json.get(var8.getTranslationKey());
               if (element2 instanceof JsonObject json2) {
                  JsonElement element3 = json2.get("left");
                  JsonElement element4 = json2.get("right");
                  if (element3 instanceof JsonArray && element4 instanceof JsonArray) {
                     flag |= var3.applyCategoryColumns(var8, resolveArrayList(element3), resolveArrayList(element4));
                  }
               } else if (element2 instanceof JsonArray array) {
                  flag |= var3.applyCategoryOrder(var8, resolveArrayList(array));
               }
            }

            if (flag) {
               this.panel.updateState();
            }
         }
      }
   }

   public void handleMatrixStack(MatrixStack matrices, float value) {
      float value2 = Math.max(0.0F, value);
      MatrixTransforms.handleMatrixStack(matrices, () -> {
         MatrixTransforms.handleMatrixStack(matrices, this.panel, value2);
         this.handleMatrixStack(matrices);
         this.panel.handleMatrixStack2(matrices);
         this.panel.handleMatrixStack(matrices);
      });
   }

   public boolean testKeyEvent(KeyEvent event) {
      ClientSettings var2 = Cortex.getInstance().getClientSettings();
      return var2 != null && var2.getClickGuiBind().testInt(event.getKey(), ClientUtils306.getInt());
   }

   public void updateState() {
      boolean flag = this.booleanValue
         && (
            Float.compare(this.floatValue, this.floatValue7) != 0
               || Float.compare(this.floatValue2, this.floatValue8) != 0
               || Float.compare(this.floatValue3, this.floatValue9) != 0
               || Float.compare(this.floatValue4, this.floatValue10) != 0
         );
      this.booleanValue = false;
      this.intValue = 0;
      if (flag) {
         this.changeListeners.updateState();
      }
   }

   public boolean testState2() {
      return MinecraftClient.getInstance().currentScreen == this;
   }

   public boolean testFloat(float value, float value2, float value3, float value4, float value5, float value6, float value7) {
      if (!(value5 <= 0.0F) && !(value6 <= 0.0F)) {
         ColorRGBA var8 = ClickGuiPanel.colorRGBA.getColorRGBA();
         float value8 = value5 * 0.5F;
         float value9 = value6 * 0.5F;
         float value10 = value - value3 - value8;
         float value11 = value2 - value4 - value9;
         float value12 = Math.max(0.0F, calculateFloat(value10, value11, var8) + value7);
         float value13 = Math.abs(value10) - value8 + value12;
         float value14 = Math.abs(value11) - value9 + value12;
         float value15 = Math.max(value13, 0.0F);
         float value16 = Math.max(value14, 0.0F);
         float value17 = Math.min(Math.max(value13, value14), 0.0F);
         float value18 = calculateFloat(value15, value16, ClickGuiPanel.colorRGBA.getFloatValue6());
         return value17 + value18 - value12 <= 0.0F;
      } else {
         return false;
      }
   }

   @Subscribe
   public void onMouseDragEvent(MouseDragEvent event) {
      if (this.testState2() && event.testInt(0)) {
         float value = (float)event.getMouseX();
         float value2 = (float)event.getMouseY();
         if (this.booleanValue) {
            if (this.intValue == 0) {
               this.handleFloat3(value, value2);
            } else {
               this.handleFloat(value, value2);
            }
         } else {
            this.panel.testFloat2(value, value2);
         }
      }
   }

   public void handleMatrixStack(MatrixStack matrices) {
      float value = this.floatValue - this.floatValue13;
      float value2 = this.floatValue2 - this.floatValue14;
      if (value != 0.0F || value2 != 0.0F) {
         matrices.translate(value, value2, 0.0F);
      }
   }

   public static float calculateFloat(float value, float value2, float value3) {
      return (float)Math.pow(Math.pow(Math.abs(value), value3) + Math.pow(Math.abs(value2), value3), 1.0 / value3);
   }

   public void updateState2() {
      this.booleanValue2 = true;
      this.booleanValue3 = true;
   }

   public static float calculateFloat(ColorRGBA var0) {
      return Math.max(Math.max(var0.getFloatValue(), var0.getFloatValue2()), Math.max(var0.getFloatValue3(), var0.getFloatValue4()));
   }

   public void updateState3() {
      NumericState147 var1 = this.getNumericState147();
      this.booleanValue = false;
      this.intValue = 0;
      this.floatValue3 = 992.0F;
      this.floatValue4 = 700.0F;
      this.handleNumericState147(var1);
      this.updateState2();
      this.testState();
   }

   public static ArrayList resolveArrayList(JsonElement element) {
      if (element instanceof JsonArray array) {
         ArrayList values = new ArrayList(array.size());

         for (JsonElement element2 : (java.lang.Iterable<JsonElement>) (java.lang.Iterable<?>) (array)) {
            if (element2 != null && element2.isJsonPrimitive() && element2.getAsJsonPrimitive().isString()) {
               values.add(element2.getAsString());
            }
         }

         return values;
      } else {
         return new ArrayList();
      }
   }

   public boolean testState3() {
      return this.booleanValue && this.intValue == 0;
   }

   public static boolean testFloat(float value, float value2, float value3, float value4) {
      return Float.isFinite(value)
         && Float.isFinite(value2)
         && Float.isFinite(value3)
         && Float.isFinite(value4)
         && (Float.compare(value3, value) != 0 || Float.compare(value4, value2) != 0);
   }

   public boolean testInt(int index) {
      return (this.intValue & index) != 0;
   }

   public void handleFloat(float value, float value2) {
      float value3 = this.getFloat2();
      float value4 = this.getFloat5();
      float value5 = 720.0F;
      float value6 = 480.0F;
      float value7 = calculateFloat(value3, value5);
      float value8 = calculateFloat(value4, value6);
      float value9 = calculateFloat(value3, value7, value5, 1400.0F);
      float value10 = calculateFloat(value4, value8, value6, 900.0F);
      float value11 = value - this.floatValue5;
      float value12 = value2 - this.floatValue6;
      float value13 = this.floatValue7;
      float value14 = this.floatValue8;
      float value15 = value13 + this.floatValue9;
      float value16 = value14 + this.floatValue10;
      float floatValue = value13;
      float floatValue2 = value14;
      float value17 = value15;
      float value18 = value16;
      if (this.testInt(1)) {
         floatValue = calculateFloat2(value13 + value11, Math.max(value7, value15 - value9), value15 - value5);
         floatValue = calculateFloat2(this.calculateFloat2(floatValue), Math.max(value7, value15 - value9), value15 - value5);
      }

      if (this.testInt(2)) {
         value17 = calculateFloat2(value15 + value11, value13 + value5, Math.min(value3 - value7, value13 + value9));
         value17 = calculateFloat2(this.calculateFloat2(value17), value13 + value5, Math.min(value3 - value7, value13 + value9));
      }

      if (this.testInt(4)) {
         floatValue2 = calculateFloat2(value14 + value12, Math.max(value8, value16 - value10), value16 - value6);
         floatValue2 = calculateFloat2(this.calculateFloat2(floatValue2), Math.max(value8, value16 - value10), value16 - value6);
      }

      if (this.testInt(8)) {
         value18 = calculateFloat2(value16 + value12, value14 + value6, Math.min(value4 - value8, value14 + value10));
         value18 = calculateFloat2(this.calculateFloat2(value18), value14 + value6, Math.min(value4 - value8, value14 + value10));
      }

      this.floatValue = floatValue;
      this.floatValue2 = floatValue2;
      this.floatValue3 = value17 - floatValue;
      this.floatValue4 = value18 - floatValue2;
      this.testState();
   }

   public float getFloat() {
      Window window = MinecraftClient.getInstance().getWindow();
      if (window != null && window.getHeight() > 0) {
         float value = (float)(MinecraftClient.getInstance().mouse.getY() * window.getFramebufferHeight() / window.getHeight());
         return this.calculateFloat3(value);
      } else {
         return Float.NaN;
      }
   }

   public void handleNumericState147(NumericState147 var1) {
      if (!this.getNumericState147().equals(var1)) {
         this.changeListeners.updateState();
      }
   }

   public void init() {
      super.init();
      this.booleanValue = false;
      this.intValue = 0;
      this.updateState4();
      this.updateState2();
   }

   public void close() {
      this.updateState5();
      super.close();
   }

   public void renderBackground(DrawContext var1, int index, int index2, float value) {
   }

   public boolean hasUsageText() {
      return false;
   }

   public boolean shouldPause() {
      return false;
   }

   @Override
   public JsonElement toJson() {
      return ClientState280.resolveJson(var1 -> {
         var1.handleText("x", this.floatValue);
         var1.handleText("y", this.floatValue2);
         var1.handleText("width", this.floatValue3);
         var1.handleText("height", this.floatValue4);
         var1.handleText("layoutMode", this.panel.getOptionGroup1042());
         ModuleManager var2 = Cortex.getInstance().getModuleManager();
         if (var2 != null) {
            var1.handleText("moduleOrder", resolveJson(var2));
         }
      });
   }

   @Subscribe
   public void onRender2DEvent(Render2DEvent event) {
      RecoveredMouseControl.maintainMenuCursor(this);
      boolean flag = this.testState2();
      if (flag) {
         this.updateState4();
      } else {
         this.updateState5();
         this.handleLong(0L);
      }

      float value = calculateFloat(
         this.clientUtils209, flag ? 1.0F : 0.0F, flag ? ClientUtils284.clientContract5427 : ClientUtils284.clientContract5426, flag ? 0.3 : 0.22
      );
      if (flag || !this.clientUtils209.testState() && !(value <= 0.12F)) {
         MatrixStack matrices = event.getMatrixStack();
         boolean flag2 = this.testState();
         boolean flag3 = this.testState3();
         if (flag) {
            float floatValue17 = this.getFloat3();
            float floatValue18 = this.getFloat();
            if (flag2 || this.booleanValue3 || this.testFloat2(floatValue17, floatValue18)) {
               if (!flag3) {
                  this.panel.handleFloat(floatValue17, floatValue18);
                  this.handleFloat2(floatValue17, floatValue18);
               }

               this.floatValue17 = floatValue17;
               this.floatValue18 = floatValue18;
               this.booleanValue3 = false;
            }
         }

         this.handleMatrixStack(matrices, value);
      } else {
         this.updateState6();
      }
   }

   public float calculateFloat2(float value) {
      float value2 = this.getFloat4();
      return Float.isFinite(value) && !(value2 <= 0.0F) ? Math.round(value * value2) / value2 : value;
   }

   public void handleFloat(float floatValue5, float floatValue6, int intValue) {
      this.booleanValue = true;
      this.intValue = intValue;
      this.floatValue5 = floatValue5;
      this.floatValue6 = floatValue6;
      this.floatValue7 = this.floatValue;
      this.floatValue8 = this.floatValue2;
      this.floatValue9 = this.floatValue3;
      this.floatValue10 = this.floatValue4;
   }

   public void updateState4() {
      if (this.booleanValue4) {
         this.booleanValue4 = false;
         this.booleanValue3 = true;
         OptionGroup160.TRANSITION_DOWN.updateState();
      }
   }

   public void updateState5() {
      if (!this.booleanValue4) {
         this.booleanValue4 = true;
         this.updateState();
         this.panel.updateState7();
         this.booleanValue3 = true;
         this.handleLong(0L);
         OptionGroup160.TRANSITION_UP.updateState();
      }
   }

   @Subscribe
   public void onMinecraftClientEvent3(MinecraftClientEvent3 var1) {
      WidgetPart54.updateState();
   }

   public boolean testFloat2(float value, float value2) {
      return Float.compare(value, this.floatValue17) != 0 || Float.compare(value2, this.floatValue18) != 0;
   }

   public static float calculateFloat2(float value, float value2, float value3) {
      return Math.max(value2, Math.min(value, value3));
   }

   public void deserialize(JsonObject json) {
      if (json != null) {
         NumericState147 var2 = this.getNumericState147();
         ClientState280.handleJson(json, "x", ClickGuiScreen::resolveFloat, var1x -> this.floatValue = Math.max(0.0F, var1x));
         ClientState280.handleJson(json, "y", ClickGuiScreen::resolveFloat, var1x -> this.floatValue2 = Math.max(0.0F, var1x));
         ClientState280.handleJson(json, "width", ClickGuiScreen::resolveFloat, var1x -> this.floatValue3 = calculateFloat2(var1x, 720.0F, 1400.0F));
         ClientState280.handleJson(json, "height", ClickGuiScreen::resolveFloat, var1x -> this.floatValue4 = calculateFloat2(var1x, 480.0F, 900.0F));
         JsonElement element = json.get("layoutMode");
         if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            this.panel.handleOptionGroup104(OptionGroup104.resolveOptionGroup104(element.getAsString()));
         }

         this.handleJson(json.get("moduleOrder"));
         this.handleNumericState147(var2);
         this.updateState2();
      }
   }

   public ClickGuiPanel getPanel() {
      return this.panel;
   }

   @Subscribe
   public void onMouseButtonEvent(MouseButtonEvent event) {
      if (this.testState2()) {
         float value = this.calculateFloat(event.getMouseX());
         float value2 = this.calculateFloat3(event.getMouseY());
         this.testState();
         if (!testInt4(event.getButton())) {
            if (event.testState4() && this.panel.testFloat(value, value2, event.getButton())) {
               this.updateState2();
               event.cancel();
            }

            if (event.testState3() && this.panel.testState3() && this.panel.testFloat2(value, value2, event.getButton())) {
               this.updateState2();
               event.cancel();
            }
         } else if (event.testState3()) {
            boolean flag = this.testState3();
            if (event.getButton() == 0 && this.panel.testFloat2(value, value2, event.getButton())) {
               this.updateState2();
               event.cancel();
            }

            if (event.getButton() == 0) {
               this.updateState();
               if (flag) {
                  this.updateState2();
               }

               this.booleanValue3 = true;
            }
         } else if (event.testState4()) {
            if (event.getButton() == 1) {
               if (this.panel.testFloat(value, value2, event.getButton())) {
                  this.updateState2();
                  event.cancel();
               }
            } else {
               int index = this.calculateInt(value, value2);
               if (index != 0) {
                  if (testInt2(index) && this.testFloat(value, value2, index)) {
                     event.cancel();
                  } else {
                     this.handleFloat(value, value2, index);
                     this.booleanValue3 = true;
                     event.cancel();
                  }
               } else if (this.panel.testFloat(value, value2, event.getButton())) {
                  this.updateState2();
                  event.cancel();
               } else {
                  if (this.panel.contains(value, value2)) {
                     this.handleFloat(value, value2, 0);
                     this.booleanValue3 = true;
                     event.cancel();
                  }
               }
            }
         }
      }
   }

   public static boolean testInt2(int index) {
      return (index & 3) != 0 && (index & 12) != 0;
   }

   public float getFloat2() {
      Window window = MinecraftClient.getInstance().getWindow();
      return window == null ? this.width : window.getFramebufferWidth() / this.calculateFloat(window);
   }

   public static JsonObject resolveJson(ModuleManager var0) {
      JsonObject json = new JsonObject();

      for (ModuleCategory var5 : ModuleCategory.resolveModuleCategoryArray(CategoryGroup.MODULES)) {
         JsonArray array = new JsonArray();

         for (Module var8 : var0.getByCategory(var5)) {
            array.add(var8.getName());
         }

         json.add(var5.getTranslationKey(), array);
      }

      return json;
   }

   @Subscribe
   public void onMouseScrollEvent(MouseScrollEvent event) {
      if (this.testState2()) {
         this.testState();
         if (this.panel.testFloat(this.getFloat3(), this.getFloat(), event.getVertical())) {
            this.updateState2();
            event.cancel();
         }
      }
   }

   public static float calculateFloat(float value, float value2, ColorRGBA var2) {
      boolean flag = value > 0.0F;
      boolean flag2 = value2 > 0.0F;
      if (flag && flag2) {
         return var2.getFloatValue3();
      } else if (flag) {
         return var2.getFloatValue2();
      } else {
         return flag2 ? var2.getFloatValue4() : var2.getFloatValue();
      }
   }

   public void handleFloat2(float value, float value2) {
      int index = this.panel.calculateInt(value, value2);
      if (index != 0) {
         this.handleLong(this.calculateLong(index));
      } else {
         int index2 = this.booleanValue && this.intValue != 0 ? this.intValue : this.calculateInt(value, value2);
         if (this.booleanValue && this.intValue == 0) {
            index2 = 0;
         }

         boolean flag = (index2 & 3) != 0;
         boolean flag2 = (index2 & 12) != 0;
         if (flag && flag2) {
            boolean flag3 = index2 == 5 || index2 == 10;
            this.handleLong(this.calculateLong(flag3 ? 221191 : 221192));
         } else if (flag) {
            this.handleLong(this.calculateLong(221189));
         } else if (flag2) {
            this.handleLong(this.calculateLong(221190));
         } else {
            this.handleLong(0L);
         }
      }
   }

   public void updateState6() {
      this.clientUtils209.resolveClientState3483(0.0F);
      this.booleanValue4 = true;
      this.booleanValue = false;
      this.intValue = 0;
      this.handleLong(0L);
   }

   public static float calculateFloat(float value, float value2) {
      return Math.min(0.0F, Math.max(0.0F, (value - value2) * 0.5F));
   }

   public float calculateFloat3(float value, float value2, float value3) {
      return calculateFloat2(this.calculateFloat2(calculateFloat2(value, value2, value3)), value2, value3);
   }

   public static float calculateFloat(float value, float value2, float value3, float value4) {
      float value5 = Math.max(value3, value - value2 * 2.0F);
      return Math.min(value4, value5);
   }

   @Subscribe
   public void onCharInputEvent(CharInputEvent event) {
      if (this.testState2()) {
         this.testState();
         if (this.panel.testInt2(event.getCodepoint(), event.getModifiers())) {
            this.updateState2();
            event.cancel();
         }
      }
   }

   public int calculateInt(float value, float value2) {
      if (!this.panel.testFloat(value, value2) && this.testFloat3(value, value2)) {
         float value3 = this.floatValue;
         float value4 = this.floatValue2;
         float value5 = value3 + this.floatValue3;
         float value6 = value4 + this.floatValue4;
         float value7 = calculateFloat(ClickGuiPanel.colorRGBA.getColorRGBA()) + 4.0F;
         boolean flag = value < value3 + value7;
         boolean flag2 = value > value5 - value7;
         boolean flag3 = value2 < value4 + value7;
         boolean flag4 = value2 > value6 - value7;
         int index = 0;
         if (flag && flag3) {
            return 5;
         }

         if (flag2 && flag3) {
            return 6;
         }

         if (flag2 && flag4) {
            return 10;
         }

         if (flag && flag4) {
            return 9;
         }

         float value8 = Math.abs(value - value3);
         float value9 = Math.abs(value - value5);
         float value10 = Math.abs(value2 - value4);
         float value11 = Math.abs(value2 - value6);
         float value12 = Math.min(value8, value9);
         float value13 = Math.min(value10, value11);
         if (value12 < value13) {
            index = value8 < value9 ? 1 : 2;
         } else {
            index = value10 < value11 ? 4 : 8;
         }

         return index;
      } else {
         return 0;
      }
   }

   public long calculateLong(int index) {
      if (index == 221185) {
         if (this.longValue7 == 0L) {
            this.longValue7 = GLFW.glfwCreateStandardCursor(index);
         }

         return this.longValue7;
      } else if (index == 221186) {
         if (this.longValue6 == 0L) {
            this.longValue6 = GLFW.glfwCreateStandardCursor(index);
         }

         return this.longValue6;
      } else if (index == 221189) {
         if (this.longValue2 == 0L) {
            this.longValue2 = GLFW.glfwCreateStandardCursor(index);
         }

         return this.longValue2;
      } else if (index == 221190) {
         if (this.longValue3 == 0L) {
            this.longValue3 = GLFW.glfwCreateStandardCursor(index);
         }

         return this.longValue3;
      } else if (index == 221191) {
         if (this.longValue4 == 0L) {
            this.longValue4 = GLFW.glfwCreateStandardCursor(index);
         }

         return this.longValue4;
      } else if (index == 221192) {
         if (this.longValue5 == 0L) {
            this.longValue5 = GLFW.glfwCreateStandardCursor(index);
         }

         return this.longValue5;
      } else {
         return 0L;
      }
   }

   @Subscribe
   public void onKeyEvent(KeyEvent event) {
      int index = event.getAction();
      if (this.testState2() && testInt3(index)) {
         this.testState();
         boolean flag = this.panel.testState3();
         if ((flag || index != 0) && this.panel.testInt(event.getKey(), index)) {
            this.updateState2();
            event.cancel();
         } else if (index != 0) {
            if (!flag && index == 1 && this.testKeyEvent(event)) {
               this.updateState5();
               MinecraftClient.getInstance().setScreen(null);
               event.cancel();
            }
         }
      }
   }

   public NumericState147 getNumericState147() {
      return new NumericState147(this.floatValue, this.floatValue2, this.floatValue3, this.floatValue4);
   }

   @Override
   public void addChangeListener(Runnable var1) {
      this.changeListeners.addChangeListener(var1);
   }

   public void handleFloat3(float value, float value2) {
      float value3 = this.getFloat2();
      float value4 = this.getFloat5();
      float value5 = calculateFloat(value3, 720.0F);
      float value6 = calculateFloat(value4, 480.0F);
      float floatValue = this.calculateFloat3(this.floatValue7 + value - this.floatValue5, value5, Math.max(value5, value3 - value5 - this.floatValue3));
      float floatValue2 = this.calculateFloat3(this.floatValue8 + value2 - this.floatValue6, value6, Math.max(value6, value4 - value6 - this.floatValue4));
      float value7 = floatValue - this.floatValue;
      float value8 = floatValue2 - this.floatValue2;
      this.floatValue = floatValue;
      this.floatValue2 = floatValue2;
      if (value7 != 0.0F || value8 != 0.0F) {
         if (!this.testFloat(value3, value4)) {
            this.testState();
         } else {
            this.booleanValue3 = true;
         }
      }
   }

   public boolean testFloat3(float value, float value2) {
      boolean flag = this.testFloat(value, value2, this.floatValue - 4.0F, this.floatValue2 - 4.0F, this.floatValue3 + 8.0F, this.floatValue4 + 8.0F, 4.0F);
      boolean flag2 = this.testFloat(value, value2, this.floatValue + 4.0F, this.floatValue2 + 4.0F, this.floatValue3 - 8.0F, this.floatValue4 - 8.0F, -4.0F);
      return flag && !flag2;
   }

   @Override
   public void shutdown() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.currentScreen == this) {
         client.setScreen(null);
      }

      WidgetPart54.updateState5();
   }

   public float calculateFloat3(float value) {
      return value / this.getFloat4();
   }

   public boolean testState4() {
      return this.panel.testState3();
   }

   public float getFloat3() {
      Window window = MinecraftClient.getInstance().getWindow();
      if (window != null && window.getWidth() > 0) {
         float value = (float)(MinecraftClient.getInstance().mouse.getX() * window.getFramebufferWidth() / window.getWidth());
         return this.calculateFloat(value);
      } else {
         return Float.NaN;
      }
   }

   public static boolean testInt3(int index) {
      return index == 1 || index == 2 || index == 0;
   }

   public void handleLong(long longValue) {
      Window window = MinecraftClient.getInstance().getWindow();
      if (window != null && this.longValue != longValue) {
         GLFW.glfwSetCursor(window.getHandle(), longValue);
         this.longValue = longValue;
      }
   }

   public static boolean testInt4(int index) {
      return index == 0 || index == 1;
   }

   public boolean testFloat(float floatValue19, float floatValue20, int intValue2) {
      long longValue8 = System.currentTimeMillis();
      boolean flag = intValue2 == this.intValue2 && longValue8 - this.longValue8 <= 420L && calculateFloat2(floatValue19, floatValue20, this.floatValue19, this.floatValue20) <= 64.0F;
      this.longValue8 = longValue8;
      this.floatValue19 = floatValue19;
      this.floatValue20 = floatValue20;
      this.intValue2 = intValue2;
      if (!flag) {
         return false;
      }

      this.updateState3();
      this.longValue8 = 0L;
      this.intValue2 = 0;
      return true;
   }

   public static float calculateFloat(ClientUtils209 var0, float value, ClientContract54 var2, double value2) {
      if (var0.getClientContract54() != var2) {
         float value3 = (Float)((ClientUtils209)var0.getClientState348()).getValue3();
         ((ClientUtils209)var0.resolveClientState3483(value3)).resolveClientState348(var2);
      }

      return (Float)((ClientUtils209)var0.resolveClientState348(value, value2)).getValue3();
   }

   public float calculateFloat(Window window) {
      if (window == null) {
         return 1.0F;
      }

      float value = (float)WindowState1.calculateDouble(window.getFramebufferWidth(), window.getFramebufferHeight());
      return Float.isFinite(value) && value > 0.0F ? value : 1.0F;
   }

   public float getFloat4() {
      Window window = MinecraftClient.getInstance().getWindow();
      return this.calculateFloat(window);
   }

   public static float calculateFloat2(float value, float value2, float value3, float value4) {
      float value5 = value - value3;
      float value6 = value2 - value4;
      return value5 * value5 + value6 * value6;
   }

   public float getFloat5() {
      Window window = MinecraftClient.getInstance().getWindow();
      return window == null ? this.height : window.getFramebufferHeight() / this.calculateFloat(window);
   }

   @Override
   public void deserialize(JsonElement var1) {
      this.deserialize((JsonObject)var1);
   }
}
